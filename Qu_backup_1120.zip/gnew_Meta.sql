 
/* table 조회 */
select  
  'SELECT * ' || chr(13) || 'FROM ' || schemaname || '.' || tablename 
  || chr(13) || 'WHERE 1=1' || chr(13) || ';' || chr(13)
, schemaname 
, tablename 
, tableowner 
from pg_catalog.pg_tables 
where 1=1
and tablename like '%_mgt%'
-- LIMIT 5
;

SELECT *
FROM pg_catalog.pg_index pi2 
;
									
/* 테이블 퀄럼 조회 메타 쿼리 */
SELECT 
        CHR(124) || CHR(124) || ' ' || CHR(39) || CHR(44) || column_name  || ' ' || CHR(39)  AS  COL_INSERT
      , CHR(124) || CHR(124) || ' ' || CHR(39) || ' ' || CHR(124) || CHR(124) || ' ' ||  column_name || ' '  || CHR(124) || CHR(124) || ' ' ||  'CHR(39)' || ' ' || CHR(124) || CHR(124) || ' ' || CHR(39) || CHR(44) || CHR(39)   AS  COL_DATA_INSERT
     ,     CHR(44) || column_name ||  '       ' || CHR(45) || CHR(45) || 'c.comments'   AS  COL
         '+ "' || CHR(44) || ' ' || COLUMN_NAME || ' ' || CHR(34)    AS  COL_NM
     ,  CHR(44) || ':NEW.' || COLUMN_NAME AS TRG_COL
     ,  B.COLUMN_NAME 
       , c.comments   AS  COL
--       , B.DATA_TYPE || '(' || DATA_LENGTH || ')' AS DATA_TYPE
--*
  FROM INFORMATION_SCHEMA.COLUMNS
 WHERE 1=1 
-- AND TABLE_CATALOG = 'lightTA'
--   and table_SCHEMA = 'pubilc'
   AND TABLE_NAME    = 'tb_ca_api_log'
 ORDER BY ORDINAL_POSITION
;

/* 테이블 코멘트 조회 */
SELECT PS.SCHEMANAME as OWNER
	  ,PS.RELNAME    AS TABLE_NAME
	  ,PD.DESCRIPTION AS TABLE_COMMENT
  FROM PG_STAT_USER_TABLES PS
      ,PG_DESCRIPTION      PD
 WHERE 1=1
   and PS.RELNAME  like '%mgt%'
--  AND PS.relname  = 'tbta_aly_keyword'
   AND PS.RELID  = PD.OBJOID
   AND PD.OBJSUBID  = 0
--   and PD.DESCRIPTION like '%키워드%'
 order by PD.DESCRIPTION
 ;
   

SELECT PS.RELNAME    AS TABLE_NAME
      ,PA.ATTNAME     AS COLUMN_NAME
      ,PD.description  AS COMMENT
FROM  PG_STAT_ALL_TABLES PS
      ,PG_DESCRIPTION     PD
      ,PG_ATTRIBUTE       PA
WHERE PS.SCHEMANAME = (SELECT SCHEMANAME
                        FROM PG_STAT_USER_TABLES
                      WHERE RELNAME = 'tb_ca_keyword_day')
 AND PS.RELNAME  = 'tb_ca_keyword_day'
 AND PS.RELID   = PD.OBJOID
 AND PD.OBJSUBID <> 0  -- 컬럼인 애들 추출
 AND PD.OBJOID    = PA.ATTRELID
 AND PD.OBJSUBID  = PA.ATTNUM
ORDER BY PS.RELNAME, PD.OBJSUBID
;

/* 테이블 조회 */
SELECT * 
FROM PG_STAT_ALL_TABLES PS
WHERE 1=1
--AND PS.relname = 'tbta_aly_keyword%'
AND PS.relname LIKE '%tbta_aly_keyword%'
--AND schemaname = 'public'
;

SELECT *
FROM PG_DESCRIPTION     PD
WHERE 1=1 
--AND PD.OBJOID = 39005
AND PD.OBJSUBID <> 0
;

SELECT 
FROM PG_ATTRIBUTE    PA
WHERE 1=1
;


SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
 WHERE 1=1
--   AND TABLE_CATALOG = 'lightTA'
   AND TABLE_NAME    = 'tbta_aly_keyword'
   ORDER BY ORDINAL_POSITION
;

select oid , typname
from PG_TYPE 
;
 
SELECT *
  FROM PG_STAT_ALL_TABLES ps
WHERE PS.RELNAME = 'tb_stt_master'
       ;            
  
 /* 테이블 조회 */
 select * 
 from PG_STAT_USER_TABLES PS
 where 1=1
 and relname like '%tb_stt_master%'
 ;
 
select * 
from pg_catalog.pg_tables 
where 1=1
and tablename like '%keyword%'
;

select * 
FROM INFORMATION_SCHEMA.columns
;
      

      
---------------------------------------------------------------------------------------------------- 
----------------------------------------------------------------------------------------------------
/* 코멘트 정보 포함 버전 */
 /* 컬럼  코드 생성 - 코멘트 있을때*/
  SELECT PS.RELNAME    AS TABLE_NAME
--      ,PD.DESCRIPTION AS COLUMN_COMMENT
	   , ', ' || PA.ATTNAME || '       --' || PD.DESCRIPTION   AS  DB_COL
	   , ', ' || PA.ATTNAME  AS  DB_COL2
	   , (SELECT typname FROM pg_type WHERE oid = PA.atttypid) AS data_TYPE
	   , '       --' || PD.DESCRIPTION 
	  , '+ "' || CHR(44) || ' ' || PA.ATTNAME   || ' ' || CHR(34) || '       //' || PD.DESCRIPTION   AS  COL_NM
	  , ('mRst.put("' 
	     || ( CASE WHEN substr(PA.ATTNAME, 0, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
			            THEN PA.ATTNAME
		            ELSE 
		            	   substr(PA.ATTNAME, 0, POSITION('_' IN PA.ATTNAME )-1) 
		            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
		            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
		            END )
	     || '",' || '  '  
	     || (CASE WHEN PA.atttypid IN (1043, 1009)
	     		THEN 'rs.getString("'
	     		ELSE 
	     			'rs.getInt("'
	     		END )
	     || PA.ATTNAME || '"));' 
	     || '       //' || PD.DESCRIPTION  
	  	)	  AS RESUTL_SET
	  	, ('tb_ca_keyword_day_VO.set' 
	     || ( CASE WHEN substr(PA.ATTNAME, 1, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
			            THEN UPPER(substr(PA.ATTNAME, 1, 1)) || substr(PA.ATTNAME, 2)  
			        ELSE 
			        	   UPPER(substr(PA.ATTNAME, 1, 1)) 
		            	|| substr(PA.ATTNAME, 2, POSITION('_' IN PA.ATTNAME )-2)
		            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
		            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
		            END )
	     || '('  
	      || (CASE WHEN PA.atttypid IN (1043, 1009)
	     		THEN 'rs.getString("'
	     		ELSE 
	     			'rs.getInt("'
	     		END )
	     || PA.ATTNAME || '"));' 
	     || '       //' || PD.DESCRIPTION  
	    )	  AS RESUTL_SET_VO	  
	  	, ('+ "\t' 
	     || ( CASE WHEN substr(PA.ATTNAME, 0, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
            THEN PA.ATTNAME
            ELSE 
            	   substr(PA.ATTNAME, 0, POSITION('_' IN PA.ATTNAME )-1) 
            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
            END )
	     || ' :"+' || ' '    
	     || (CASE WHEN PA.atttypid IN (1043, 1009)
	     		THEN 'rs.getString("'
	     		ELSE 
	     			'rs.getInt("'
	     		END )
	     || PA.ATTNAME || '") + "\n"' 
	     || '       //' || PD.DESCRIPTION  
	  	)	  AS LOG_INFO
	  	, ('pstmt.' 
	  	 || (CASE WHEN PA.atttypid IN (1043, 1009)
	     		THEN 'setString( 0, (String)params.get("'
	     		ELSE 
	     			'setInt( 0, (int)params.get("'
	     		END )	     		
	     || ( CASE WHEN substr(PA.ATTNAME, 0, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
            THEN PA.ATTNAME
            ELSE 
            	   substr(PA.ATTNAME, 0, POSITION('_' IN PA.ATTNAME )-1) 
            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
            END )
	     || '"));'  
	     || '       //' || PD.DESCRIPTION  
	  	)	  AS pstmt_in_map
	  	  , 'i++;' || CHR(13)
	     || ('pstmt.' 
	  	 || (CASE WHEN PA.atttypid IN (1043, 1009)
	     		THEN 'setString(i, (String)paramVo.get'
	     		ELSE 
	     			'setInt(i, (int)paramVo.get'
	     		END )	     		
	     || ( CASE WHEN substr(PA.ATTNAME, 1, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
			            THEN UPPER(substr(PA.ATTNAME, 1, 1)) || substr(PA.ATTNAME, 2)  
			        ELSE 
			        	   UPPER(substr(PA.ATTNAME, 1, 1)) 
		            	|| substr(PA.ATTNAME, 2, POSITION('_' IN PA.ATTNAME )-2)
		            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
		            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
		            END )
	     || '());'  
	    )	  AS pstmt_in_vo
 FROM  PG_STAT_ALL_TABLES PS
      ,PG_DESCRIPTION     PD
      ,PG_ATTRIBUTE       PA
 WHERE PS.SCHEMANAME = (SELECT SCHEMANAME
                            FROM PG_STAT_USER_TABLES
                           WHERE RELNAME = 'tb_biz_master')
   AND PS.RELNAME  = 'tb_biz_master'
   AND PS.RELID   = PD.OBJOID
   AND PD.OBJSUBID <> 0
   AND PD.OBJOID    = PA.ATTRELID
   AND PD.OBJSUBID  = PA.ATTNUM
 ORDER BY PS.RELNAME, PD.OBJSUBID
 ;

SELECT 
/* -- 일단 컬럼명 에 대한 키원드 조합 필요*/
 ('    private    ' 
    || (CASE WHEN PA.atttypid IN (1043, 1009)
	 		THEN 'String    '
	 		ELSE 
				 'int        '
	 		END )
	 || ( CASE WHEN substr(PA.ATTNAME, 0, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
			            THEN PA.ATTNAME
		            ELSE 
		            	   substr(PA.ATTNAME, 0, POSITION('_' IN PA.ATTNAME )-1) 
		            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
		            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
		            END )
	  || (CASE WHEN PA.atttypid IN (1043, 1009)
	 		THEN ' = "";'
	 		ELSE 
				 ' = 0;'
	 		END )
	 || '       //' || PD.DESCRIPTION  
	)  AS member_var, 
	--------------------------------------------------------------------------
	  ('    public ' 
    || (CASE WHEN PA.atttypid IN (1043, 1009)
	 		THEN 'String '
	 		ELSE 
				 'int '
	 		END )
	 || 'get' 
	 || ( CASE WHEN substr(PA.ATTNAME, 1, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
			   THEN UPPER(substr(PA.ATTNAME, 1, 1)) || substr(PA.ATTNAME, 2)  
	        ELSE 
	        	   UPPER(substr(PA.ATTNAME, 1, 1)) 
            	|| substr(PA.ATTNAME, 2, POSITION('_' IN PA.ATTNAME )-2)
            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
            END ) 
	 || '()'
	 || ' {' || CHR(13) 
	 || (CASE WHEN PA.atttypid IN (1043, 1009)
	 		THEN '        String rVal ='
	 		ELSE 
				 '        int rVal ='
	 		END )
	 || ' this.' 
	  || ( CASE WHEN substr(PA.ATTNAME, 1, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
			            THEN PA.ATTNAME
		            ELSE 
		            	   substr(PA.ATTNAME, 1, POSITION('_' IN PA.ATTNAME )-1) 
		            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
		            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
		            END ) 
	 || ';' || CHR(13)
	 || '        return rVal;' || CHR(13)  
	 || '    }' || CHR(13)
	)	  AS GET_method
	--------------------------------------------------------------------------
	,  ('    public ' 
     || 'void '
     || 'set'
	 || ( CASE WHEN substr(PA.ATTNAME, 1, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
	           THEN UPPER(substr(PA.ATTNAME, 1, 1)) || substr(PA.ATTNAME, 2)  
	        ELSE 
	        	   UPPER(substr(PA.ATTNAME, 1, 1)) 
            	|| substr(PA.ATTNAME, 2, POSITION('_' IN PA.ATTNAME )-2)
            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
            END ) 
	 || (CASE WHEN PA.atttypid IN (1043, 1009)
	 		THEN '(String pStr)'
	 		ELSE 
				 '(int nNum)'
	 		END )
	 || ' {' ||  CHR(13) 
	 || '        ' || 'this.'
	 || ( CASE WHEN substr(PA.ATTNAME, 1, POSITION('_' IN PA.ATTNAME )-1) ISNULL 
			            THEN PA.ATTNAME
		            ELSE 
		            	   substr(PA.ATTNAME, 1, POSITION('_' IN PA.ATTNAME )-1) 
		            	|| UPPER(substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 1, 1))
		            	|| substr(PA.ATTNAME, POSITION('_' IN PA.ATTNAME )+ 2)
		            END ) 
	 || ' = '
	 || (CASE WHEN PA.atttypid IN (1043, 1009)
	 		THEN 'pStr;'
	 		ELSE 
				 'nNum;'
	 		END )
	 ||  CHR(13)  
	 || '    }' || CHR(13)
	)	  AS SET_method
FROM  PG_STAT_ALL_TABLES PS
      ,PG_DESCRIPTION     PD
      ,PG_ATTRIBUTE       PA
 WHERE PS.SCHEMANAME = (SELECT SCHEMANAME
                            FROM PG_STAT_USER_TABLES
                           WHERE RELNAME = 'tb_ca_keyword_day')
   AND PS.RELNAME  = 'tb_ca_keyword_day'
   AND PS.RELID   = PD.OBJOID
   AND PD.OBJSUBID <> 0
   AND PD.OBJOID    = PA.ATTRELID
   AND PD.OBJSUBID  = PA.ATTNUM
 ORDER BY PS.RELNAME, PD.OBJSUBID
 ;
---------------------------------------------------------------------------------------------------- 
----------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------- 
----------------------------------------------------------------------------------------------------
/* 코멘트 가 없을 경우 조회 */
/* 컬럼 코드 샐성 */
SELECT 
        PA.udt_name 
--        ,PA.*
--      ,PD.DESCRIPTION AS COLUMN_COMMENT
	   , ', SM.' || PA.column_name AS  DB_COL
	   , ', ' || PA.column_name AS  DB_COL2
	  , '+ "' || CHR(44) || ' ' || PA.column_name   || ' ' || CHR(34) AS  COL_NM
	  , ('mRst.put("' 
	     || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
			            THEN PA.column_name
		            ELSE 
		            	   substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) 
		            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
		            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
		            END )
	     || '",' || '  '  
	     || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	     		THEN 'rs.getString("'
	     		ELSE 
	     			'rs.getInt("'
	     		END )
	     || PA.column_name || '"));' 
	     )	  AS RESUTL_SET
	  	  , ('tb_ca_keyword_day_VO.set' 
	     || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
			            THEN UPPER(substr(PA.column_name, 1, 1)) || substr(PA.column_name, 2)  
			        ELSE 
			        	   UPPER(substr(PA.column_name, 1, 1)) 
		            	|| substr(PA.column_name, 2, POSITION('_' IN PA.column_name )-2)
		            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
		            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
		            END )
	     || '('  
	     || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	     		THEN 'rs.getString("'
	     		ELSE 
	     			'rs.getInt("'
	     		END )
	     || PA.column_name || '"));' 
	    )	  AS RESUTL_SET_VO	  	
	  	, ('+ "\t' 
	     || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
            THEN PA.column_name
            ELSE 
            	   substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) 
            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
            END )
	     || ' :"+' || ' '  
	     || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	     		THEN 'rs.getString("'
	     		ELSE 
	     			'rs.getInt("'
	     		END )
	     || PA.column_name || '") + "\n"' 
	    )	  AS LOG_INFO
	  	, ('pstmt.' 
	  	 || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	     		THEN 'setString( 0, (String)params.get("'
	     		ELSE 
	     			'setInt( 0, (int)params.get("'
	     		END )	     		
	     || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
            THEN PA.column_name
            ELSE 
            	   substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) 
            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
            END )
	     || '"));'  
	    )	  AS pstmt_in_map
	    , 'i++;' || CHR(13)
	     || ('pstmt.' 
	  	 || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	     		THEN 'setString(i, (String)paramVo.get'
	     		ELSE 
	     			'setInt(i, (int)paramVo.get'
	     		END )	     		
	     || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
			            THEN UPPER(substr(PA.column_name, 1, 1)) || substr(PA.column_name, 2)  
			        ELSE 
			        	   UPPER(substr(PA.column_name, 1, 1)) 
		            	|| substr(PA.column_name, 2, POSITION('_' IN PA.column_name )-2)
		            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
		            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
		            END )
	     || '());'  
	    )	  AS pstmt_in_vo
 FROM INFORMATION_SCHEMA.COLUMNS PA
 WHERE 1=1
--   AND TABLE_CATALOG = 'lightTA'
   AND TABLE_NAME    = 'tb_ca_user_stopword_mgt'
   ORDER BY ORDINAL_POSITION
;	  	

--TbCaKeywordDay
/* 멤버 변수 및 메쏘드 만들기  */
/*  vo 클래스 생성 및 VO작성 */
SELECT 
/* -- 일단 컬럼명 에 대한 키원드 조합 필요*/
 ('    private    ' 
    || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	 		THEN 'String    '
	 		ELSE 
				 'int        '
	 		END )
	 || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
			            THEN PA.column_name
		            ELSE 
		            	   substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) 
		            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
		            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
		            END )
	  || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	 		THEN ' = "";'
	 		ELSE 
				 ' = 0;'
	 		END )
	)  AS member_var, 
------------------------------------------------------------------------
	  ('    public ' 
    || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	 		THEN 'String '
	 		ELSE 
				 'int '
	 		END )
	 || 'get' 
	 || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
			   THEN UPPER(substr(PA.column_name, 1, 1)) || substr(PA.column_name, 2)  
	        ELSE 
	        	   UPPER(substr(PA.column_name, 1, 1)) 
            	|| substr(PA.column_name, 2, POSITION('_' IN PA.column_name )-2)
            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
            END ) 
	 || '()'
	 || ' {' || CHR(13) 
	 || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	 		THEN '        String rVal ='
	 		ELSE 
				 '        int rVal ='
	 		END )
	 || ' this.' 
	 || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
			            THEN PA.column_name
		            ELSE 
		            	   substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) 
		            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
		            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
		            END ) 
	 || ';' || CHR(13)
	 || '        return rVal;' || CHR(13)  
	 || '    }' || CHR(13)
	)	  AS GET_method
	--------------------------------------------------------------------------
	,  ('    public ' 
     || 'void '
	 || 'set'
	 || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
	           THEN UPPER(substr(PA.column_name, 1, 1)) || substr(PA.column_name, 2)  
	        ELSE 
	        	   UPPER(substr(PA.column_name, 1, 1)) 
            	|| substr(PA.column_name, 2, POSITION('_' IN PA.column_name )-2)
            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
            END ) 
	 || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	 		THEN '(String pStr)'
	 		ELSE 
				 '(int nNum)'
	 		END )
	 || ' {' ||  CHR(13) 
	 || '        ' || 'this.'
	 || ( CASE WHEN substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) ISNULL 
			            THEN PA.column_name
		            ELSE 
		            	   substr(PA.column_name, 1, POSITION('_' IN PA.column_name )-1) 
		            	|| UPPER(substr(PA.column_name, POSITION('_' IN PA.column_name )+ 1, 1))
		            	|| substr(PA.column_name, POSITION('_' IN PA.column_name )+ 2)
		            END ) 
	 || ' = '
	 || (CASE WHEN PA.udt_name IN ('varchar', 'text')
	 		THEN 'pStr;'
	 		ELSE 
				 'nNum;'
	 		END )
	 ||  CHR(13)  
	 || '    }' || CHR(13)
	)	  AS SET_method
  FROM INFORMATION_SCHEMA.COLUMNS PA
 WHERE 1=1
--   AND TABLE_CATALOG = 'lightTA'
   AND TABLE_NAME    = 'tb_ca_keyword_day'
   ORDER BY ORDINAL_POSITION
;


