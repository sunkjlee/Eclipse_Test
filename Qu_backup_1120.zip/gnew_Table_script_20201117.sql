
/* 유위어 치환용 -표준어 테이블 */
DROP TABLE public.tb_ca_user_stdkeyword_mgt CASCADE;
CREATE TABLE tb_ca_user_stdkeyword_mgt(
	 custnb		 varchar(255) NOT NULL,
     seq 			serial 	NOT NULL,
	 std_keyword	varchar NOT NULL,
	 use_yn			char(1)	NOT NULL DEFAULT 'Y',
	 reg_user		varchar(255) NULL,
	 reg_date		TIMESTAMP NULL DEFAULT current_timestamp,
	 mod_date		TIMESTAMP NULL DEFAULT current_timestamp,
     CONSTRAINT tb_ca_user_stdkeyword_mgt_pk PRIMARY KEY (custnb,seq)
);

CREATE INDEX tb_ca_user_stdkeyword_mgt_idx ON public.tb_ca_user_stdkeyword_mgt USING btree (seq);

COMMENT ON TABLE public.tb_ca_user_stdkeyword_mgt  IS '고객별_유의어치환용_표준키워드';

COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.custnb		   IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.seq 			IS '키워드식별번호';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.std_keyword IS '표준키워드';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.use_yn  IS '사용유무';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.reg_date IS '등록일자';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.mod_date IS '수정일자';


/* 유의어 치환용-유의어 테이블 */
DROP TABLE public.tb_ca_user_synoymkeyword_mgt CASCADE;
CREATE TABLE tb_ca_user_synoymkeyword_mgt(
	 seq serial 	NOT NULL,
     custnb		       varchar(255) NOT NULL,
     std_keyword_seq	int NOT NULL,
     synonym_keyword    varchar NOT NULL,
	 use_yn			char(1)	NOT NULL DEFAULT 'Y',
	 reg_user		varchar(255) NULL,
	 reg_date		TIMESTAMP NULL DEFAULT current_timestamp,
	 mod_date		TIMESTAMP NULL DEFAULT current_timestamp,
     CONSTRAINT tb_ca_user_synoymkeyword_mgt_pk PRIMARY KEY (custnb,std_keyword_seq,synonym_keyword),
     CONSTRAINT tb_ca_user_synoymkeyword_mgt_fk FOREIGN KEY (custnb, std_keyword_seq) REFERENCES tb_ca_user_stdkeyword_mgt(custnb, seq)
);

--ALTER TABLE tb_ca_user_synoymkeyword_mgt ADD CONSTRAINT tb_ca_user_synoymkeyword_mgt_fk FOREIGN KEY (custnb, std_keyword) 
--	REFERENCES  public.tb_ca_user_stdkeyword_mgt (custnb, std_keyword);

CREATE INDEX tb_ca_user_synoymkeyword_mgt_idx ON public.tb_ca_user_synoymkeyword_mgt USING btree (seq);

COMMENT ON TABLE public.tb_ca_user_synoymkeyword_mgt  IS '고객별_유의어치환용_유의어키워드';

COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.custnb		IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.std_keyword_seq IS '표준키워드코드';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.synonym_keyword IS '유의어키워드';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.use_yn  IS '사용유무';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.reg_date IS '등록일자';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.mod_date IS '수정일자';


/*
 *  테이블 생성 script 
 */
/* 1-1 일통계 - 업체 - 회선별 */
DROP TABLE public.tb_ca_keyword_svcnb_day;
CREATE TABLE public.tb_ca_keyword_svcnb_day (
	seq serial 	NOT NULL,
	custnb		 varchar(255) NOT NULL, 
	stat_date 	varchar(255) NOT NULL,
	svcnb 		 varchar NOT NULL,
	speaker 	int4 NOT NULL DEFAULT 1,
	keyword 	varchar NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	mon_nb		int4  NULL , 
	week_nb		int4  NULL , 
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_keyword_svcnb_day_pk PRIMARY KEY (custnb,stat_date,svcnb,keyword)
);

CREATE INDEX tb_ca_keyword_svcnb_day_idx ON public.tb_ca_keyword_svcnb_day USING btree (seq);

COMMENT ON TABLE public.tb_ca_keyword_svcnb_day  IS '업체_회선별_키워드_일집계';
--COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.custnb_type IS '고객식별번호 타입(A:사업자번호, B:법인번호, C:가상주민번호, D:전화번호 )';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.custnb		IS '고객식별번호';/
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.svcnb 		IS '가입자번호(회선번호)';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.stat_date IS '배치일자';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.speaker  IS '화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.keyword IS '키워드';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.keyword_cnt IS '키워드카운트';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.mon_nb IS '통계월';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.week_nb IS '통계주';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.reg_date IS '등록일자';

/* 컬럼 추가 : (불만-만족 키워드, 불용어 키워드)테이블 고객식별번호 컬럼 추가  */
ALTER TABLE public.tb_ca_user_key_mgt ADD COLUMN custnb varchar(255) NOT NULL;
ALTER TABLE public.tb_ca_user_stopword_mgt ADD COLUMN custnb varchar(255) NOT NULL;

ALTER TABLE public.tb_ca_user_key_mgt ALTER COLUMN custnb SET NOT NULL ;
ALTER TABLE public.tb_ca_user_stopword_mgt ALTER COLUMN custnb SET NOT NULL ;
/* 
CREATE TABLE public.tb_ca_keyword_svcnb_day (
	seq serial 	NOT NULL,
	custnb		 varchar(255) NOT NULL, 
	stat_date 	varchar(255) NOT NULL,
	svcnb 		 varchar NOT NULL,
	speaker 	int4 NOT NULL DEFAULT 3,
	keyword 	varchar NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_keyword_svcnb_day_pk PRIMARY KEY (custnb,stat_date,svcnb,speaker,keyword)
);

CREATE INDEX tb_ca_keyword_svcnb_day_idx ON public.tb_ca_keyword_svcnb_day USING btree (seq);




-- 일단 DEFAULT TEST 1탱..
DELETE  FROM tb_ca_keyword_svcnb_day 
WHERE 1=1 ;

INSERT INTO tb_ca_keyword_svcnb_day (
	  custnb       --고객식별번호
	, stat_date       --배치일자
	, svcnb       --가입자번호(회선번호)
	, keyword       --키워드
	, keyword_cnt       --키워드카운트
	, reg_user       --등록자
)VALUES ( '1234512456',  TO_CHAR(NOW()-1, 'YYYY-MM-DD'), '158811111', '개통', '20', 'BAT');
	
SELECT * FROM tb_ca_keyword_svcnb_day
;



