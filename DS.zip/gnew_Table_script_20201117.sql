
/* 유위어 치환용 -표준어 테이블 */
DROP TABLE public.tb_ca_user_stdkeyword_mgt;
CREATE TABLE tb_ca_user_stdkeyword_mgt(
	 custnb		 varchar(255) NOT NULL,
     seq 			serial 	NOT NULL,
	 std_keyword	varchar NOT NULL,
	 use_yn			char(1)	NOT NULL DEFAULT 'Y',
	 reg_user		varchar(255) NULL,
	 reg_date		TIMESTAMP NULL DEFAULT current_timestamp,
	 mod_date		TIMESTAMP NULL DEFAULT current_timestamp,
     CONSTRAINT tb_ca_user_stdkeyword_mgt_pk PRIMARY KEY (custnb,seq)
);

CREATE INDEX tb_ca_user_stdkeyword_mgt_idx ON public.tb_ca_user_stdkeyword_mgt USING btree (seq);

COMMENT ON TABLE public.tb_ca_user_stdkeyword_mgt  IS '고객별_유의어치환용_표준키워드';

COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.custnb		   IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.seq 			IS '키워드식별번호';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.std_keyword IS '표준키워드';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.use_yn  IS '사용유무';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.reg_date IS '등록일자';
COMMENT ON COLUMN public.tb_ca_user_stdkeyword_mgt.mod_date IS '수정일자';


/* 유의어 치환용-유의어 테이블 */
DROP TABLE public.tb_ca_user_synoymkeyword_mgt CASCADE;
CREATE TABLE tb_ca_user_synoymkeyword_mgt(
	 seq serial 	NOT NULL,
     custnb		       varchar(255) NOT NULL,
     std_keyword_seq	int NOT NULL,
     synonym_keyword    varchar NOT NULL,
	 use_yn			char(1)	NOT NULL DEFAULT 'Y',
	 reg_user		varchar(255) NULL,
	 reg_date		TIMESTAMP NULL DEFAULT current_timestamp,
	 mod_date		TIMESTAMP NULL DEFAULT current_timestamp,
     CONSTRAINT tb_ca_user_synoymkeyword_mgt_pk PRIMARY KEY (custnb,std_keyword_seq,synonym_keyword),
     CONSTRAINT tb_ca_user_synoymkeyword_mgt_fk FOREIGN KEY (custnb, std_keyword_seq) REFERENCES tb_ca_user_stdkeyword_mgt(custnb, seq)
);

--ALTER TABLE tb_ca_user_synoymkeyword_mgt ADD CONSTRAINT tb_ca_user_synoymkeyword_mgt_fk FOREIGN KEY (custnb, std_keyword) 
--	REFERENCES  public.tb_ca_user_stdkeyword_mgt (custnb, std_keyword);

CREATE INDEX tb_ca_user_synoymkeyword_mgt_idx ON public.tb_ca_user_synoymkeyword_mgt USING btree (seq);

COMMENT ON TABLE public.tb_ca_user_synoymkeyword_mgt  IS '고객별_유의어치환용_유의어키워드';

COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.custnb		IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.std_keyword_seq IS '표준키워드코드';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.synonym_keyword IS '유의어키워드';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.use_yn  IS '사용유무';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.reg_date IS '등록일자';
COMMENT ON COLUMN public.tb_ca_user_synoymkeyword_mgt.mod_date IS '수정일자';

/* 컬럼 추가 : (불만-만족 키워드, 불용어 키워드)테이블 고객식별번호 컬럼 추가  */
ALTER TABLE public.tb_ca_user_key_mgt ADD COLUMN custnb varchar(255) NOT NULL;
ALTER TABLE public.tb_ca_user_stopword_mgt ADD COLUMN custnb varchar(255) NOT NULL;

ALTER TABLE public.tb_ca_user_key_mgt ALTER COLUMN custnb SET NOT NULL ;
ALTER TABLE public.tb_ca_user_stopword_mgt ALTER COLUMN custnb SET NOT NULL ;

/*
 *  테이블 생성 script 
 */
/* 1-1 일통계 - 업체 - 회선별 */
DROP TABLE public.tb_ca_keyword_svcnb_day;
CREATE TABLE public.tb_ca_keyword_svcnb_day (
	custnb		 varchar(255) NOT NULL, 
	stat_date 	varchar(255) NOT NULL,
	svcnb 		 varchar NOT NULL,
	speaker 	int4 NOT NULL DEFAULT 1,
	keyword 	varchar NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	mon_nb		int4  NULL , 
	week_nb		int4  NULL , 
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_keyword_svcnb_day_pk PRIMARY KEY (custnb,stat_date,svcnb,keyword)
);

--CREATE INDEX tb_ca_keyword_svcnb_day_idx ON public.tb_ca_keyword_svcnb_day USING btree (seq);

COMMENT ON TABLE public.tb_ca_keyword_svcnb_day  IS '업체_회선별_키워드_일집계';
--COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.custnb_type IS '고객식별번호 타입(A:사업자번호, B:법인번호, C:가상주민번호, D:전화번호 )';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.custnb		IS '고객식별번호';/
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.svcnb 		IS '가입자번호(회선번호)';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.stat_date IS '배치일자';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.speaker  IS '화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.keyword IS '키워드';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.keyword_cnt IS '키워드카운트';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.mon_nb IS '통계월';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.week_nb IS '통계주';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_keyword_svcnb_day.reg_date IS '등록일자';

/* 1-2 일통계 - 성별 - 연령대별 */
DROP TABLE public.tb_ca_keyword_genage_day;
CREATE TABLE public.tb_ca_keyword_genage_day (
	custnb		 varchar(255) NOT NULL, 
	stat_date 		varchar(255) NOT NULL, 
	custom_gender 	varchar(255)  NOT NULL DEFAULT 'M',  
	custom_age		varchar(255)  NOT NULL DEFAULT 0,
	speaker 	int4 NOT NULL DEFAULT 1,
	keyword 	varchar NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	mon_nb		int4  NULL , 
	week_nb		int4  NULL , 
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_keyword_genage_day_pk PRIMARY KEY (custnb,stat_date,custom_gender,custom_age,keyword)
);

--CREATE INDEX tb_ca_keyword_genage_day_idx ON public.tb_ca_keyword_genage_day USING btree (seq);

COMMENT ON TABLE public.tb_ca_keyword_genage_day  IS '업체_성별_연령대별_키워드_일집계';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.custnb		IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.stat_date IS '배치일자';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.custom_gender IS '성별 M(남)/F(여)';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.custom_age 	IS '연령대(0/10/20/../100)';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.speaker  IS '화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.keyword IS '키워드';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.keyword_cnt IS '키워드카운트';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.mon_nb IS '통계월';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.week_nb IS '통계주';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_keyword_genage_day.reg_date IS '등록일자';


/* 1-3 일통계 - 지역별 */
DROP TABLE public.tb_ca_keyword_area_day;
CREATE TABLE public.tb_ca_keyword_area_day (
	custnb		 varchar(255) NOT NULL, 
	stat_date 	varchar(255) NOT NULL, 
 	zone_l1 	varchar(255)  NOT NULL DEFAULT 'N/A',
	zone_l2		varchar(255)  NOT NULL DEFAULT 'N/A',
	keyword 	varchar NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	speaker 	int4 NOT NULL DEFAULT 1,
	mon_nb		int4  NULL , 
	week_nb		int4  NULL , 
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_keyword_area_day_pk PRIMARY KEY (custnb,stat_date,zone_l1,zone_l2,keyword)
);

--CREATE INDEX tb_ca_keyword_area_day_idx ON public.tb_ca_keyword_area_day USING btree (seq);

COMMENT ON TABLE public.tb_ca_keyword_area_day  IS '업체_지역별_키워드_일집계';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.custnb		IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.stat_date IS '배치일자';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.zone_l1 IS '지역_시_도';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.zone_l2 	IS '지역_시_군';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.speaker  IS '화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.keyword IS '키워드';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.keyword_cnt IS '키워드카운트';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.mon_nb IS '통계월';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.week_nb IS '통계주';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_keyword_area_day.reg_date IS '등록일자';


/* 1-4 일통계 - 업종별 */
DROP TABLE public.tb_ca_keyword_biz_day;
CREATE TABLE public.tb_ca_keyword_biz_day (
	custnb		 varchar(255) NOT NULL, 
	stat_date 	varchar(255) NOT NULL, 
	biz_nm	 	varchar(255)  NOT NULL DEFAULT 'N/A',
	keyword 	varchar NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	speaker 	int4 NOT NULL DEFAULT 1,
	mon_nb		int4  NULL , 
	week_nb		int4  NULL , 
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_keyword_biz_day_pk PRIMARY KEY (custnb,stat_date,biz_nm, keyword)
);

--CREATE INDEX tb_ca_keyword_biz_day_idx ON public.tb_ca_keyword_biz_day USING btree (seq);

COMMENT ON TABLE public.tb_ca_keyword_biz_day  IS '업체_업종별_키워드_일집계';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.custnb		IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.stat_date IS '배치일자';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.biz_nm IS '업체구분명';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.speaker  IS '화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.keyword IS '키워드';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.keyword_cnt IS '키워드카운트';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.mon_nb IS '통계월';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.week_nb IS '통계주';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_keyword_biz_day.reg_date IS '등록일자';



/* 2-1 일통계 - 업체 - 회선별 - 관심불만 */
DROP TABLE public.tb_ca_user_stat_keyword_svcnb_day;
CREATE TABLE public.tb_ca_user_stat_keyword_svcnb_day (
	custnb		 varchar(255) NOT NULL, 
	stat_date 		varchar(255) NOT NULL, 
	svcnb		 varchar(255) NOT NULL,
	keyword_type 	char(1)  NOT NULL DEFAULT '1',
	u_keyword 	varchar(255) NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	speaker 	int4 NOT NULL DEFAULT 1,
	mon_nb		int4  NULL , 
	week_nb		int4  NULL , 
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_user_stat_keyword_svcnb_day_pk PRIMARY KEY (custnb,stat_date,svcnb,keyword_type,u_keyword)
);

--CREATE INDEX tb_ca_user_stat_keyword_svcnb_day_idx ON public.tb_ca_user_stat_keyword_svcnb_day USING btree (seq);

COMMENT ON TABLE public.tb_ca_user_stat_keyword_svcnb_day  IS '업체_회선별_관심불만_키워드_일집계';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.custnb		IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.stat_date IS '배치일자';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.svcnb		IS '회선번호';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.keyword_type IS '키워드타입(관심/불만)';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.u_keyword 	IS '관심불만키워드';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.speaker  IS '화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.keyword_cnt IS '키워드카운트';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.mon_nb IS '통계월';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.week_nb IS '통계주';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_svcnb_day.reg_date IS '등록일자';


/* 2-2 관심불말 일통계 - 성별 - 연령대별 */
DROP TABLE public.tb_ca_user_stat_keyword_genage_day;
CREATE TABLE public.tb_ca_user_stat_keyword_genage_day (
	custnb		 varchar(255) NOT NULL, 
	stat_date 		varchar(255) NOT NULL, 
	custom_gender 	varchar(255)  NOT NULL DEFAULT 'M',
	custom_age		varchar(255)  NOT NULL DEFAULT 0,
	keyword_type 	char(1)  NOT NULL DEFAULT '1',
	u_keyword 	varchar(255) NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,	
	speaker 	int4 NOT NULL DEFAULT 1,
	mon_nb		int4  NULL , 
	week_nb		int4  NULL , 
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_user_stat_keyword_genage_day_pk PRIMARY KEY (custnb,stat_date,custom_gender,custom_age,keyword_type, u_keyword)
);

--CREATE INDEX tb_ca_user_stat_keyword_genage_day_idx ON public.tb_ca_user_stat_keyword_genage_day USING btree (seq);

COMMENT ON TABLE public.tb_ca_user_stat_keyword_genage_day  IS '업체_성별_연령대별_관심불만키워드_일집계';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.custnb		IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.stat_date IS '배치일자';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.custom_gender IS '성별 M(남)/F(여)';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.custom_age 	IS '연령대(0/10/20/../100)';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.keyword_type IS '키워드타입';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.u_keyword IS '불만관심키워드';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.keyword_cnt IS '키워드카운트';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.speaker  IS '화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.mon_nb IS '통계월';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.week_nb IS '통계주';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_genage_day.reg_date IS '등록일자';



/* 2-3 관심불말  일통계 - 지역별 */
DROP TABLE public.tb_ca_user_stat_keyword_area_day;
CREATE TABLE public.tb_ca_user_stat_keyword_area_day (
	custnb		 varchar(255) NOT NULL, 
	stat_date 	varchar(255) NOT NULL, 
 	zone_l1 	varchar(255)  NOT NULL DEFAULT 'N/A',
	zone_l2		varchar(255)  NOT NULL DEFAULT 'N/A',
	keyword_type 	char(1)  NOT NULL DEFAULT '1',
	u_keyword 	varchar(255) NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	speaker 	int4 NOT NULL DEFAULT 1,
	mon_nb		int4  NULL , 
	week_nb		int4  NULL , 
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_user_stat_keyword_area_day_pk PRIMARY KEY (custnb, stat_date, zone_l1, zone_l2, keyword_type, u_keyword)
); 

--CREATE INDEX tb_ca_user_stat_keyword_area_day_idx ON public.tb_ca_user_stat_keyword_area_day USING btree (seq);

COMMENT ON TABLE public.tb_ca_user_stat_keyword_area_day  IS '업체_지역별_관심불만키워드_일집계';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.custnb		IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.stat_date IS '배치일자';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.zone_l1 IS '지역_시_도';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.zone_l2 	IS '지역_시_군';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.keyword_type IS '키워드타입';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.u_keyword IS '불만관심키워드';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.speaker  IS '화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.keyword_cnt IS '키워드카운트';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.mon_nb IS '통계월';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.week_nb IS '통계주';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_area_day.reg_date IS '등록일자';


/* 2-4 관심불만 - 일통계 - 업종별 */
DROP TABLE public.tb_ca_user_stat_keyword_biz_day;
CREATE TABLE public.tb_ca_user_stat_keyword_biz_day (
	custnb		 varchar(255) NOT NULL, 
	stat_date 	varchar(255) NOT NULL, 
	biz_nm	 	varchar(255)  NOT NULL DEFAULT 'N/A',
	keyword_type 	char(1)  NOT NULL DEFAULT '1',
	u_keyword 	varchar(255) NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	speaker 	int4 NOT NULL DEFAULT 1,
	mon_nb		int4  NULL , 
	week_nb		int4  NULL , 
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_user_stat_keyword_biz_day_pk PRIMARY KEY (custnb,stat_date,biz_nm, keyword_type, u_keyword)
);

--CREATE INDEX tb_ca_user_stat_keyword_biz_day_idx ON public.tb_ca_user_stat_keyword_biz_day USING btree (seq);

COMMENT ON TABLE public.tb_ca_user_stat_keyword_biz_day  IS '업체_업종별_관심불만키워드_일집계';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.custnb		IS '고객식별번호';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.stat_date IS '배치일자';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.biz_nm IS '업체구분명';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.speaker  IS '화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.keyword_type IS '키워드타입';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.u_keyword IS '불만관심키워드';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.keyword_cnt IS '키워드카운트';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.mon_nb IS '통계월';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.week_nb IS '통계주';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.reg_user IS '등록자';
COMMENT ON COLUMN public.tb_ca_user_stat_keyword_biz_day.reg_date IS '등록일자';

/* 
CREATE TABLE public.tb_ca_keyword_svcnb_day (
	seq serial 	NOT NULL,
	custnb		 varchar(255) NOT NULL, 
	stat_date 	varchar(255) NOT NULL,
	svcnb 		 varchar NOT NULL,
	speaker 	int4 NOT NULL DEFAULT 3,
	keyword 	varchar NOT NULL,
	keyword_cnt int4  NOT NULL DEFAULT 0 ,
	reg_user 	varchar(255) NULL,
	reg_date 	TIMESTAMP NULL DEFAULT current_timestamp, 
	CONSTRAINT tb_ca_keyword_svcnb_day_pk PRIMARY KEY (custnb,stat_date,svcnb,speaker,keyword)
);

CREATE INDEX tb_ca_keyword_svcnb_day_idx ON public.tb_ca_keyword_svcnb_day USING btree (seq);


-- 일단 DEFAULT TEST 1탱..
DELETE  FROM tb_ca_keyword_svcnb_day 
WHERE 1=1 ;

INSERT INTO tb_ca_keyword_svcnb_day (
	  custnb       --고객식별번호
	, stat_date       --배치일자
	, svcnb       --가입자번호(회선번호)
	, keyword       --키워드
	, keyword_cnt       --키워드카운트
	, reg_user       --등록자
)VALUES ( '1234512456',  TO_CHAR(NOW()-1, 'YYYY-MM-DD'), '158811111', '개통', '20', 'BAT');
	
SELECT * FROM tb_ca_keyword_svcnb_day
;



