select  * 
from tb_ca_api_log
WHERE 1=1 
--and   
;


select * from public.tb_ca_biz_master 
;


--1 : n  - 
select call_id             --callID
, seq             	-- seq
, call_dt_ymd		--녹취생성 일자
, call_dt_hms 		--"	// 녹취생성 시간
, csr_id 		--"		// 상담사id
, csr_nm	--"		// 상담사명
, custom_id -- " 	// 고객 id
, ib_ob 	-- " 		// 콜타입 정보 
, duration_time	-- " 	// 녹취 시간
, voc_file_path	 -- "  //음원경로
, voc_file_nm 	-- "   //음원 파일명
, enc_file_size	-- " 	//암호화 파일 크기 
, dec_file_size	-- " 	//복호화 파일 크기
, subscrpt_id 	-- " 	//청약id
, goods_id	-- " 		//상품ID
, dec_flag	-- " 		//복호화 상태 : 0 : enc , ing .. 1:dec
from  tb_ca_api_log
where 1=1
and dec_flag = 2
;

SELECT 
  SEQ
 , duration_time
 , dec_flag
FROM public.tb_ca_api_log 


update tb_ca_api_log
set dec_flag = 0
,   voc_file_path  = '/root/Gnew/file/enc'
where 1=1
and call_id in ( 10001,10002,10003,10004, 10005)
--and call_id in ( 10005)
;


select * 
from tb_stt_master 
where 1=1 
AND CALL_id = '100000006'
--and call_id in ( 10001,10002,10003,10004,10005)
--and
;

delete  
from tb_stt_master 
where 1=1
and call_id in ( 10001,10002,10003,10004,10005)
--and
;

-----------------------------------------------------------------
--tb_ca_biz_master
--tb_ca_keyword_day
--tb_ca_keyword_month
--tb_ca_keyword_week
--tb_ca_keyword_week2

--tb_ca_user_stat_keyword_svcnb_day
--tb_ca_user_stat_keyword_month
--tb_ca_user_stat_keyword_week2
--tb_ca_user_stat_keyword_week


/* 고객 업체 정보 */
SELECT  * 
FROM tb_ca_biz_master
WHERE 1=1
;

/* 1.일통계_키어드 : aicc_ta.tbta_aly_keyword tak  
 *   : 얘는 유저가 public 가 아니라 aicc_ta 다.. 확인필요
 * 업체, 회선정보를 포함하는 일 키워드 통계 테이블 부터 만들어 보자 ( 1/32)
 * */
-- 가입업체구분
-- 가입업체 
-- 배치일자 
-- 키워드명
-- 화자구분

-- 가입업체구분
-- 가입업체 
-- 배치일자 
-- 키워드명
-- 화자구분
select *
--from aicc_ta.tbta_aly_keyword
from tb_ca_keyword_svcnb
where 1=1
;

/* 2.주통계_키어드 : tb_ca_keyword_week */
select *
from tb_ca_keyword_week
where 1=1
;

/* 3.월통계_키어드 : tb_ca_keyword_month */
select *
from tb_ca_keyword_month
where 1=1
;

/* 4. 2주 통계_키어드 : tb_ca_keyword_week2 */
select *
from tb_ca_keyword_week2
where 1=1
;
---------------------------------------------------------
/* 배치 일통계_키워드 INSERT 
 *  1 배치는 일배치 인가? 
 * */
SELECT 
	/* 일통계_키워드 insert용 data */
	 now()			AS stat_date      --배치일자
	, SUM(AK.count)		AS keyword_cnt    --카운트(default '0')
	, AK.keyword	AS keyword       --키워드 명
	, AL.ib_ob		AS speaker       --화자구분 -->default '1'  ( 1 = MixAS 2 = TxAS 4 = Rx)
	, AL.custnb		AS custnb       --고객실별 번호
	, AL.svcnb		AS svcnb		-- 가입자번호(회선번호)
	, 'BAT'	 		AS reg_user       --등록자
	, BM.custnb 	AS curtnb			--고객업체식별번호
    /* aicc_ta.tbta_aly_keyword : TA_연관어 분석 */
--  	, AK.ucid
--	, AK.keyword
--	, AK.speaker
--	, AK.count
--	, AK.rel_list
--	, AK.rdg_dtm
--	, AK.chg_dtm
--	/*tb_ca_api_log : 녹취메타 LOG */
--	, AL.seq       --인입순서
--	, AL.call_id       --녹취 콜 ID - 업체코드_날짜 조합   ( 타 업체 코드와 중복 불가)
--	, AL.call_dt_ymd       --녹취 생성 일자 - yyyyMMDD
--	, AL.call_dt_hms       --녹취 생성시간 - HHmmsss
--	, AL.csr_id       --상담원 ID - Default = Y
--	, AL.csr_nm       --상담사 명
--	, AL.custom_id       --고객 ID
--	, AL.ib_ob       --콜타입 정보 - default: 3   ( Rx:1, Tx:2, Mono:3 )
--	, AL.duration_time       --녹취 시간(sec)
--	, AL.voc_file_path       --음원 경로 - /NAS/SRC/${청약ID}/yyyyMMDD/
--	, AL.voc_file_nm       --음원 파일명 - 암호화된_파일명.mp3
--	, AL.enc_file_size       --암호화 파일 크기 - 원본 파일 체크용 byte
--	, AL.dec_file_size       --복호화 파일 크기 - 복호화시 체크용 byte
--	, AL.enckey       -- 암호화 키 
--	, AL.enc_alg       --암호 알고리즘 - default : 'SEED 128 CBC'
--	, AL.subscrpt_id       --청약ID
--	, AL.goods_id       --상품ID
--	, AL.dec_flag       --복호와여부
--	, AL.customer_number       --가입자번호
--	/* tb_ca_biz_master : 고객_업체_정보*/
--	, BM.seq       --순번
--	, BM.subscrpt_id       --청약ID
--	, BM.subscrpt_ty       --청약유형
--	, BM.goods_id       --상품id
--	, BM.ctgry_id       --상품카테고리id
--	, BM.opcmct_bgnde       --개통시작일
--	, BM.cmpnm       --상호명(회사명, 법인명)
--	, BM.mngr_id       --고객(회사 소속) 관리자 id
--	, BM.mngr_nm       --고객(회사 소속) 관리자명
--	, BM.mngr_telno       --고객(회사 소속) 관리자전화번호
--	, BM.mngr_moblphon_no       --고객(회사 소속) 관리자휴대전화번호
--	, BM.mngr_email_adres       --고객(회사 소속) 관리자이메일주소
--	, BM.cstmr_bizrno       --사업자등록번호
--	, BM.cstmr_telno       --고객전화번호
--	, BM.cstmr_moblphon_no       --고객휴대전화번호
--	, BM.cstmr_email_adres       --고객이메일주소
FROM aicc_ta.tbta_aly_keyword  AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
  INNER JOIN public.tb_ca_biz_master  BM 
    ON BM.custnb_type  = AL.custnb_type 
    AND BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.call_dt_ymd = '20201101'
--AND AL.csr_id  = ''
--AND AL.csr_nm  LIKE '%%'

/* 1-1. 업체-회선별-키워드 일통계 sum Count data */
SELECT 
	/* 업체-회선별-키워드  일통계 insert용 data */
	   to_char(now(), 'YYYY-MM-DD')	AS stat_date      --배치일자
	 , al.custnb    AS subtnb		--업체식별번호
	 , al.svcnb 	AS svcnb
--	 , '15882424'   AS svcnb 		--동적 --- 회선가입번호
--     , AL.ib_ob		AS speaker       --화자구분 -->mono=3
	 , AK.keyword	AS keyword       --키워드 명
	 , SUM(AK.count)		AS keyword_cnt    --카운트(default '0')	
--	, AL.custnb		AS custnb       --고객별 번호
--	, AL.svcnb		AS svcnb		-- 가입자번호(회선번호)
	, 'BAT'	 		AS reg_user       --등록자
FROM aicc_ta.tbta_aly_keyword  AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
  INNER JOIN public.tb_ca_biz_master  BM 
    ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.call_dt_ymd = '20201101'		-- 통계 일자
/* 유동조건절 */
--AND AL.custnb = '1231231'   -- 로그인 업체식별번호
AND AL.svcnb  = '15882424'		-- 가입회선번호
GROUP BY al.custnb
 /* 동적 groub by */
 , al.svcnb		--동적
-- , al.ib_ob 	--고민???
 , ak.keyword	--필수 
ORDER BY stat_date
	, subtnb 
	, svcnb
	, keyword
;


SELECT * FROM tb_ca_api_log
WHERE 1=1
AND custnb  = '1234598765'
--AND custnb  = '8232574125'
;
								
/*
* 일-업체-회선별 키워드 집계 v01
* --키워드 사전(관심,불만)
* --불용어 사전
*/
INSERT INTO tb_ca_keyword_svcnb_day (
	  custnb       --고객식별번호
	, stat_date       --배치일자 = 녹취생성일자
	, svcnb       --가입자번호(회선번호)
	, speaker       --화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )
	, keyword       --키워드
	, keyword_cnt       --키워드카운트
	, mon_nb
	, week_nb
	, reg_user       --등록자
)
;

SELECT 
	/* 업체-회선별-키워드  일통계 insert용 data */
	   al.custnb    AS cubtnb		--업체식별번호
	 , AL.call_dt_ymd	AS stat_date      --배치일자
--	   TO_CHAR(NOW(), 'YYYY-MM-DD') AS stat_date
  	 , al.svcnb 	AS svcnb
  	 , '1'			AS speaker
--	 , '15882424'   AS svcnb 		--동적 --- 회선가입번호
--     , AL.ib_ob		AS speaker       --화자구분 -->mono=3
	 , COALESCE(AK.keyword,'N/A') AS keyword
	 , count(AK.keyword)		AS keyword_cnt    --카운트(default '0')	
--	 , sum(ak.count)  AS keyword_cnt
--	, AL.custnb		AS custnb       --고객별 번호
--	, AL.svcnb		AS svcnb		-- 가입자번호(회선번호)
	, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
	, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
	, 'BAT'	 		AS reg_user       --등록자
FROM ( /* keyword filter */
		 SELECT 
				/* 유의어 치환 */
			     UK.ucid 
			   , UK.custnb
			   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
			   		   ELSE UK.keyword  
			   		   END 
			   	 ) AS keyword
			   , UK.speaker 
			   , UK.count
			--count (*)
			FROM (
				/* 불용어 제거  */
				SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
				FROM aicc_ta.tbta_aly_keyword A
				INNER JOIN public.tb_ca_api_log B 
				 ON A.ucid  = B.call_id 
				WHERE A.keyword NOT IN (
							SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
							WHERE C.custnb = B.custnb)
			) UK
			LEFT OUTER JOIN (
							SELECT a.custnb , a.std_keyword , b.synonym_keyword
							FROM tb_ca_user_stdkeyword_mgt A
			  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
							   ON  A.custnb = b.custnb 
							   AND a.seq  = b.std_keyword_seq
							WHERE 1=1
							AND a.use_yn  = 'Y'
							AND b.use_yn = 'Y'
		) SK
		ON UK.custnb = SK.custnb
		AND UK.keyword = SK.synonym_keyword 
		WHERE 1=1
	) AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
 INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.call_dt_ymd = '20201105'		-- 통계 일자
/* 유동조건절 */
--AND AL.custnb = '8232574125'   -- 로그인 업체식별번호
--AND AL.svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
--AND AL.svcnb  = '15882424'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
GROUP BY  AL.custnb, call_dt_ymd, al.svcnb, ak.keyword	 
ORDER BY  AL.custnb, call_dt_ymd, al.svcnb, ak.keyword	
;
/*1-1-1 업체 회선별 통계 */
SELECT 
*
--count(*)
FROM tb_ca_keyword_svcnb_day
WHERE 1=1
--AND custnb = '8232574125'   -- 로그인 업체식별번호
--AND svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
AND custnb = '1234598765'   -- 로그인 업체식별번호 :
--AND svcnb  = '15882489'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
/* 기간 검색 조건*/
AND	stat_date BETWEEN '20201105' AND '20201105'				--검색 기간 조건
--AND  	week_nb = 45						--1주 검색
--AND  week_nb BETWEEN 42 AND 44
--AND  mon_nb BETWEEN 10 AND 10
--AND	svcnb 
--AND	keyword 
--AND reg_date > '2020-11-20'
;


/* 1-2
 * * 
 * 성별 - 연령대별 통계 
 * */
INSERT INTO tb_ca_keyword_genage_day (
	  custnb       --고객식별번호
	, stat_date       --배치일자
	, custom_gender       --성별 M(남)/F(여)
	, custom_age       --연령대(0/10/20/../100)
	, speaker       --화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )
	, keyword       --키워드
	, keyword_cnt       --키워드카운트
	, mon_nb       --통계월
	, week_nb       --통계주
	, reg_user       --등록자
)
;

/* 성별 - 연령대별 통계 */
SELECT 
	/* 업체-회선별-키워드  일통계 insert용 data */
	   al.custnb    AS cubtnb		--업체식별번호
	 , AL.call_dt_ymd	AS stat_date      --배치일자
	 , SI.custom_gender AS custom_gender
	 , SI.custom_age    AS custom_age
  	 , '1'			AS speaker
	 , COALESCE(AK.keyword,'N/A') AS keyword
	 , count(AK.keyword)		AS keyword_cnt    --카운트(default '0')	
	, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
	, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
	, 'BAT'	 		AS reg_user       --등록자
FROM ( /* keyword filter */
		 SELECT 
				/* 유의어 치환 */
			     UK.ucid 
			   , UK.custnb
			   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
			   		   ELSE UK.keyword  
			   		   END 
			   	 ) AS keyword
			   , UK.speaker 
			   , UK.count
			--count (*)
			FROM (
				/* 불용어 제거  */
				SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
				FROM aicc_ta.tbta_aly_keyword A
				INNER JOIN public.tb_ca_api_log B 
				 ON A.ucid  = B.call_id 
				WHERE A.keyword NOT IN (
							SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
							WHERE C.custnb = B.custnb)
			) UK
			LEFT OUTER JOIN (
							SELECT a.custnb , a.std_keyword , b.synonym_keyword
							FROM tb_ca_user_stdkeyword_mgt A
			  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
							   ON  A.custnb = b.custnb 
							   AND a.seq  = b.std_keyword_seq
							WHERE 1=1
							AND a.use_yn  = 'Y'
							AND b.use_yn = 'Y'
		) SK
		ON UK.custnb = SK.custnb
		AND UK.keyword = SK.synonym_keyword 
		WHERE 1=1
	) AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
 INNER JOIN tb_ca_api_subinfo SI
   ON AL.call_id  = SI.call_id 
 INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.call_dt_ymd = '20201105'		-- 통계 일자
/* 유동조건절 */
--AND AL.custnb = '8232574125'   -- 로그인 업체식별번호
--AND AL.svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
--AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
--AND AL.svcnb  = '15882424'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
GROUP BY 
	call_dt_ymd
  ,  al.custnb
 /* 동적 groub by */
 , SI.custom_gender 
 , SI.custom_age 
 , ak.keyword	--필수 
ORDER BY 
	  AL.custnb
	, stat_date
	, custom_gender
	, custom_age
	, keyword
;

SELECT * FROM tb_ca_api_subinfo tcas 
;

SELECT 
*
FROM tb_ca_keyword_genage_day
WHERE 1=1
;

/*1-2-1 업체 성별 연령대별 통계 
 *업체별, 일자별- 성별, 연령대별로 keyword를 insert 했으니
 * 성별로 gropy by 하면됨 
 * */
SELECT 
--*
CUSTNB, stat_date , custom_gender , custom_age
--, keyword 
, SUM(keyword_cnt)
--count(*)
FROM tb_ca_keyword_genage_day
WHERE 1=1
--AND custnb = '8232574125'   -- 로그인 업체식별번호
AND custnb = '1234598765'   -- 로그인 업체식별번호 :
/* 기간 검색 조건*/
AND	stat_date BETWEEN '20201001' AND '20201120'				--검색 기간 조건
--AND custom_gender  = 'F'
--AND custom_age = '60'
/* 성병, 연령대별 sum */
GROUP BY CUSTNB, stat_date , custom_gender , custom_age 
ORDER BY CUSTNB, stat_date , custom_gender , custom_age
/* 성병, 연령대별, 키워드별 */
--GROUP BY CUSTNB, stat_date , custom_gender , custom_age, keyword 
--ORDER BY CUSTNB, stat_date , custom_gender , custom_age, keyword
--AND  	week_nb = 45						--1주 검색
--AND  week_nb BETWEEN 42 AND 44
--AND  mon_nb BETWEEN 10 AND 10
 
--AND	keyword 
--AND reg_date > '2020-11-20'
;

/* 1-3
 * * 
 * 지역별 - 통계 
 * */
INSERT INTO tb_ca_keyword_area_day (
		custnb
	, stat_date
	, zone_l1
	, zone_l2
	, keyword
	, keyword_cnt
	, speaker
	, mon_nb
	, week_nb
	, reg_user
)
;
SELECT 
	   al.custnb    AS custnb
	 , AL.call_dt_ymd	AS stat_date
	 , SI.zone_l1  AS zone_l1
	 , SI.zone_l2     AS zone_l2
	 , COALESCE(AK.keyword,'N/A') AS keyword
	 , count(AK.keyword) AS keyword_cnt	
	 , '1'			AS speaker
 	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb
	 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb
	, 'BAT'	AS reg_user
FROM ( SELECT 
			     UK.ucid 
			   , UK.custnb
			   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
			   		   ELSE UK.keyword  
			   		   END 
			   	 ) AS keyword
			   , UK.speaker 
			   , UK.count
			FROM (		
				SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
				FROM aicc_ta.tbta_aly_keyword A
				INNER JOIN public.tb_ca_api_log B 
				 ON A.ucid  = B.call_id 
				WHERE A.keyword NOT IN (
							SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
							WHERE C.custnb = B.custnb)
			) UK
			LEFT OUTER JOIN (
							SELECT a.custnb , a.std_keyword , b.synonym_keyword
							FROM tb_ca_user_stdkeyword_mgt A
			  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
							   ON  A.custnb = b.custnb 
							   AND a.seq  = b.std_keyword_seq
							WHERE 1=1
							AND a.use_yn  = 'Y'
							AND b.use_yn = 'Y'
		) SK
		ON UK.custnb = SK.custnb
		AND UK.keyword = SK.synonym_keyword 
		WHERE 1=1
	) AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
 INNER JOIN tb_ca_api_subinfo SI
   ON AL.call_id  = SI.call_id 
 INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.call_dt_ymd = '20201108'		-- 통계 일자
/* 유동조건절 */
--AND AL.custnb = '8232574125'   -- 로그인 업체식별번호
GROUP BY call_dt_ymd,  AL.custnb, SI.zone_l1 , SI.zone_l2 , AK.keyword 
ORDER BY AL.custnb, stat_date, SI.zone_l1 , SI.zone_l2, keyword
;

/*1-3-1 업체 지역별 통계  
 * 
 * */
SELECT 
--*
CUSTNB, stat_date , zone_l1 , zone_l2
, keyword 
--, SUM(keyword_cnt)
--count(*)
FROM tb_ca_keyword_area_day
WHERE 1=1
--AND custnb = '8232574125'   -- 로그인 업체식별번호
AND custnb = '1234598765'   -- 로그인 업체식별번호 :
/* 기간 검색 조건*/
AND	stat_date BETWEEN '20201108' AND '20201108'				--검색 기간 조건
--AND  	week_nb = 45						--1주 검색
--AND  week_nb BETWEEN 42 AND 44
--AND  mon_nb BETWEEN 10 AND 10
 --AND	keyword 
--AND reg_date > '2020-11-20'

GROUP BY CUSTNB, stat_date , zone_l1 , zone_l2, keyword 
ORDER BY CUSTNB, stat_date , zone_l1 , zone_l2, keyword 
/* 성병, 연령대별, 키워드별 */
;





/* 1-4
 * * 
 * 업종멸 - 통계 
 * */
INSERT INTO tb_ca_keyword_biz_day (
	  custnb
	, stat_date
	, biz_nm
	, keyword
	, keyword_cnt
	, speaker
	, mon_nb
	, week_nb
	, reg_user
)
;

/* 1-4 업체별 일별  업종별 키워드 일집계 */ 
SELECT 
	   al.custnb    AS custnb
	 , AL.call_dt_ymd	AS stat_date
	 , SI.custom_bizname  AS custom_bizname
 	 , COALESCE(AK.keyword,'N/A') AS keyword
	 , count(AK.keyword) AS keyword_cnt	
	 , '1'			AS speaker
 	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb
	 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb
	, 'BAT'	AS reg_user
FROM ( SELECT 
			     UK.ucid 
			   , UK.custnb
			   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
			   		   ELSE UK.keyword  
			   		   END 
			   	 ) AS keyword
			   , UK.speaker 
			   , UK.count
			FROM (		
				SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
				FROM aicc_ta.tbta_aly_keyword A
				INNER JOIN public.tb_ca_api_log B 
				 ON A.ucid  = B.call_id 
				WHERE A.keyword NOT IN (
							SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
							WHERE C.custnb = B.custnb)
			) UK
			LEFT OUTER JOIN (
							SELECT a.custnb , a.std_keyword , b.synonym_keyword
							FROM tb_ca_user_stdkeyword_mgt A
			  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
							   ON  A.custnb = b.custnb 
							   AND a.seq  = b.std_keyword_seq
							WHERE 1=1
							AND a.use_yn  = 'Y'
							AND b.use_yn = 'Y'
		) SK
		ON UK.custnb = SK.custnb
		AND UK.keyword = SK.synonym_keyword 
		WHERE 1=1
	) AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
 INNER JOIN tb_ca_api_subinfo SI
   ON AL.call_id  = SI.call_id 
 INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
--AND AL.call_dt_ymd = '20201105'		-- 통계 일자
--AND AL.custnb = '8232574125'   -- 로그인 업체식별번호
GROUP BY AL.custnb, call_dt_ymd, SI.custom_bizname, AK.keyword 
ORDER BY AL.custnb, stat_date, SI.custom_bizname, AK.keyword



/* 2-1
 * * 
 * 업체-회선별-불만만족 키워드  
 * */
INSERT INTO tb_ca_user_stat_keyword_svcnb_day (
	  custnb       --고객식별번호
	, stat_date       --배치일자
	, svcnb			-- 회선번호
	, keyword_type       --키워드타입(관심/불만)
	, u_keyword       --관심불만키워드
	, keyword_cnt       --키워드카운트
	, speaker       --화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )
	, mon_nb       --통계월
	, week_nb       --통계주
	, reg_user       --등록자
)
;

/* 업체 - 회선별  관심or불만 - 키워드별 일통계 
 * 
 * */
SELECT 
	/* 업체-회선별-키워드  일통계 insert용 data */
	   al.custnb    AS cubtnb		--업체식별번호
	 , AL.call_dt_ymd	AS stat_date      --배치일자
	 , al.svcnb 	AS svcnb
	 , UKM.keyword_type AS keyword_type --관심,불만구분
	 , COALESCE(UKM.u_keyword,'N/A') AS u_keyword 	
	 , '1'			AS speaker
	, count(UKM.u_keyword)		AS keyword_cnt    --카운트(default '0')	
	, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
	, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
	, 'BAT'	 		AS reg_user       --등록자
FROM ( /* keyword filter */
		 SELECT 
				/* 유의어 치환 */
			     UK.ucid 
			   , UK.custnb
			   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
			   		   ELSE UK.keyword  
			   		   END 
			   	 ) AS keyword
			   , UK.speaker 
			   , UK.count
			--count (*)
			FROM (
				/* 불용어 제거  */
				SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
				FROM aicc_ta.tbta_aly_keyword A
				INNER JOIN public.tb_ca_api_log B 
				 ON A.ucid  = B.call_id 
				WHERE A.keyword NOT IN (
							SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
							WHERE C.custnb = B.custnb)
			) UK
			LEFT OUTER JOIN (
							SELECT a.custnb , a.std_keyword , b.synonym_keyword
							FROM tb_ca_user_stdkeyword_mgt A
			  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
							   ON  A.custnb = b.custnb 
							   AND a.seq  = b.std_keyword_seq
							WHERE 1=1
							AND a.use_yn  = 'Y'
							AND b.use_yn = 'Y'
		) SK
		ON UK.custnb = SK.custnb
		AND UK.keyword = SK.synonym_keyword 
		WHERE 1=1
	) AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
 INNER JOIN tb_ca_user_key_mgt  UKM
   ON AL.custnb  = UKM.custnb 
   AND trim(AK.keyword) = trim(UKM.u_keyword) 
   AND ukm.use_yn  = 'Y'
 INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.call_dt_ymd = '20201008'		-- 통계 일자
/* 유동조건절 */
--AND AL.custnb = '8232574125'   -- 로그인 업체식별번호
--AND AL.svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
--		AND AL.svcnb  = '15882424'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
GROUP BY 
	   AL.custnb
	 , call_dt_ymd
	 , AL.svcnb		
	 , UKM.keyword_type 
	 , UKM.u_keyword 	 
ORDER BY
	  AL.custnb 
	, stat_date
	, svcnb
	 , UKM.keyword_type 
	 , UKM.u_keyword 
;

/*2-1-1 업체 회선별 관심불만  통계 
 *업체별, 일자별- 회선별로 , 관심불만 keyword를 insert 했으니
 * 필요한 data별로  gropy by 하면됨 
 * */
SELECT 
*
--custnb, stat_date, svcnb
--, keyword_type, u_key
----, keyword 
--, SUM(keyword_cnt)
--count(*)
FROM tb_ca_user_stat_keyword_svcnb_day
WHERE 1=1
--AND custnb = '8232574125'   -- 로그인 업체식별번호
AND custnb = '1234598765'   -- 로그인 업체식별번호 :
/* 기간 검색 조건*/
--AND	stat_date BETWEEN '20201001' AND '20201120'				--검색 기간 조건
--AND custom_gender  = 'F'
--AND custom_age = '60'
/* 성병, 연령대별 sum */
GROUP BY custnb, stat_date , svcnb, keyword_type, u_keyword 
ORDER BY custnb, stat_date , svcnb, keyword_type, u_keyword
/* 성병, 연령대별, 키워드별 */
--GROUP BY CUSTNB, stat_date , custom_gender , custom_age, keyword 
--ORDER BY CUSTNB, stat_date , custom_gender , custom_age, keyword
--AND  	week_nb = 45						--1주 검색
--AND  week_nb BETWEEN 42 AND 44
--AND  mon_nb BETWEEN 10 AND 10
 
--AND	keyword 
--AND reg_date > '2020-11-20'
;


/* 2-2
 * * 
 * 성별 - 연령대별-불만만조 통계 
 * */
INSERT INTO tb_ca_user_stat_keyword_genage_day (
	   custnb
	, stat_date
	, custom_gender
	, custom_age
	, keyword_type
	, u_keyword
	, keyword_cnt
	, speaker
	, mon_nb
	, week_nb
	, reg_user
)
;
/* 2-2 업체-일자별 성별-연령대 일집계 */
SELECT 
	   AL.custnb    AS custnb
	 , AL.call_dt_ymd	AS stat_date
	 , SI.custom_gender AS custom_gender
	 , SI.custom_age    AS custom_age
	 , UKM.keyword_type	AS keyword_type
	 , COALESCE(UKM.u_keyword,'N/A') AS u_keyword  
 	 , count(UKM.u_keyword) AS keyword_cnt
	 , '1'			AS speaker
	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb
 	 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb
	 , 'BAT'	 		AS reg_user
FROM (  SELECT 
			     UK.ucid 
			   , UK.custnb
			   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
			   		   ELSE UK.keyword  
			   		   END 
			   	 ) AS keyword
			   , UK.speaker 
			   , UK.count
			FROM (
				SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
				FROM aicc_ta.tbta_aly_keyword A
				INNER JOIN public.tb_ca_api_log B 
				 ON A.ucid  = B.call_id 
				WHERE A.keyword NOT IN (
							SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
							WHERE C.custnb = B.custnb)
			) UK
			LEFT OUTER JOIN (
							SELECT a.custnb , a.std_keyword , b.synonym_keyword
							FROM tb_ca_user_stdkeyword_mgt A
			  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
							   ON  A.custnb = b.custnb 
							   AND a.seq  = b.std_keyword_seq
							WHERE 1=1
							AND a.use_yn  = 'Y'
							AND b.use_yn = 'Y'
		) SK
		ON UK.custnb = SK.custnb
		AND UK.keyword = SK.synonym_keyword 
		WHERE 1=1
	) AK
INNER JOIN public.tb_ca_api_log  AL 
   ON AK.ucid =  AL.call_id 
INNER JOIN tb_ca_user_key_mgt  UKM
   ON AL.custnb  = UKM.custnb 
   AND trim(AK.keyword) = trim(UKM.u_keyword) 
   AND ukm.use_yn  = 'Y'
INNER JOIN tb_ca_api_subinfo SI
   ON AL.call_id  = SI.call_id 
INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.call_dt_ymd = '20201001'
/* 유동조건절 */
--AND AL.custnb = '8232574125'   -- 로그인 업체식별번호
--AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
GROUP BY 
     AL.custnb
  , call_dt_ymd
  , SI.custom_gender 
  , SI.custom_age 
  , UKM.keyword_type 
  , UKM.u_keyword  
ORDER BY 
	  AL.custnb
	, stat_date
	, custom_gender
	, custom_age
	, UKM.keyword_type 
	, UKM.u_keyword  
;


/* 2-3
 * * 
 * 불만만족 - 지역별 - 통계 
 * */
INSERT INTO tb_ca_user_stat_keyword_area_day (
				   custnb
				, stat_date
				, zone_l1
				, zone_l2
				, keyword_type
				, u_keyword
				, keyword_cnt
				, speaker
				, mon_nb
				, week_nb
				, reg_user
		)
;

SELECT 
	   al.custnb    AS custnb
	 , AL.call_dt_ymd	AS stat_date
	 , SI.zone_l1 AS zone_l1
	 , SI.zone_l2    AS zone_l2
	 , UKM.keyword_type	AS keyword_type
     , COALESCE(UKM.u_keyword,'N/A') AS u_keyword  
 	 , count(UKM.u_keyword) AS keyword_cnt
 	 , '1'			AS speaker
 	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb
	 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb
	, 'BAT'	AS reg_user
FROM ( SELECT 
			     UK.ucid 
			   , UK.custnb
			   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
			   		   ELSE UK.keyword  
			   		   END 
			   	 ) AS keyword
			   , UK.speaker 
			   , UK.count
			FROM (		
				SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
				FROM aicc_ta.tbta_aly_keyword A
				INNER JOIN public.tb_ca_api_log B 
				 ON A.ucid  = B.call_id 
				WHERE A.keyword NOT IN (
							SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
							WHERE C.custnb = B.custnb)
			) UK
			LEFT OUTER JOIN (
							SELECT a.custnb , a.std_keyword , b.synonym_keyword
							FROM tb_ca_user_stdkeyword_mgt A
			  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
							   ON  A.custnb = b.custnb 
							   AND a.seq  = b.std_keyword_seq
							WHERE 1=1
							AND a.use_yn  = 'Y'
							AND b.use_yn = 'Y'
		) SK
		ON UK.custnb = SK.custnb
		AND UK.keyword = SK.synonym_keyword 
		WHERE 1=1
	) AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
INNER JOIN tb_ca_user_key_mgt  UKM
   ON AL.custnb  = UKM.custnb 
   AND trim(AK.keyword) = trim(UKM.u_keyword) 
   AND ukm.use_yn  = 'Y'
INNER JOIN tb_ca_api_subinfo SI
   ON AL.call_id  = SI.call_id 
INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
--AND AL.call_dt_ymd = '20201001'
/* 유동조건절 */
--AND AL.custnb = '8232574125'   -- 로그인 업체식별번호
--AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 : 
GROUP BY call_dt_ymd,  AL.custnb, SI.zone_l1 , SI.zone_l2 , UKM.keyword_type, UKM.u_keyword 
ORDER BY AL.custnb, stat_date, SI.zone_l1 , SI.zone_l2, UKM.keyword_type, UKM.u_keyword 
;



/* 2-4
 * * 
 * 불만만족 - 업종별- 통계 
 * */
INSERT INTO tb_ca_user_stat_keyword_biz_day (
	 custnb
	, stat_date
	, biz_nm
	, keyword_type
	, u_keyword
	, keyword_cnt
	, speaker
	, mon_nb
	, week_nb
	, reg_user
)
;
/* 2-4 업체-일자별 불만만족 키워드 업종별 일집계 */
SELECT 
	   al.custnb    AS custnb
	 , AL.call_dt_ymd	AS stat_date
	 , SI.custom_bizname  AS custom_bizname
	 , UKM.keyword_type	AS keyword_type
 	 , COALESCE(UKM.u_keyword,'N/A') AS u_keyword  
 	 , count(UKM.u_keyword) AS keyword_cnt
 	 , '1'			AS speaker
 	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb
	 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb
	, 'BAT'	AS reg_user
FROM ( SELECT 
			     UK.ucid 
			   , UK.custnb
			   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
			   		   ELSE UK.keyword  
			   		   END 
			   	 ) AS keyword
			   , UK.speaker 
			   , UK.count
			FROM (		
				SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
				FROM aicc_ta.tbta_aly_keyword A
				INNER JOIN public.tb_ca_api_log B 
				 ON A.ucid  = B.call_id 
				WHERE A.keyword NOT IN (
							SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
							WHERE C.custnb = B.custnb)
			) UK
			LEFT OUTER JOIN (
							SELECT a.custnb , a.std_keyword , b.synonym_keyword
							FROM tb_ca_user_stdkeyword_mgt A
			  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
							   ON  A.custnb = b.custnb 
							   AND a.seq  = b.std_keyword_seq
							WHERE 1=1
							AND a.use_yn  = 'Y'
							AND b.use_yn = 'Y'
		) SK
		ON UK.custnb = SK.custnb
		AND UK.keyword = SK.synonym_keyword 
		WHERE 1=1
	) AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
INNER JOIN tb_ca_user_key_mgt  UKM
   ON AL.custnb  = UKM.custnb 
   AND trim(AK.keyword) = trim(UKM.u_keyword) 
   AND ukm.use_yn  = 'Y'
INNER JOIN tb_ca_api_subinfo SI
   ON AL.call_id  = SI.call_id 
INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
--AND AL.call_dt_ymd = '20201001'
/* 유동조건절 */
--AND AL.custnb = '8232574125'   -- 로그인 업체식별번호
GROUP BY call_dt_ymd,  AL.custnb, SI.custom_bizname , UKM.keyword_type, UKM.u_keyword 
ORDER BY AL.custnb, stat_date, SI.custom_bizname , UKM.keyword_type, UKM.u_keyword


/* 3-1 콜건수 - 회선별*/
SELECT 
	   al.custnb    AS custnb
	 , AL.call_dt_ymd	AS stat_date
	 , AL.svcnb     AS svcnb 
	 , COUNT(AL.call_id)  AS call_cnt
 	 , '1'			AS speaker
 	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb
	 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb
	, 'BAT'	AS reg_user
FROM  public.tb_ca_api_log  AL 
INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
AND AL.call_dt_ymd = '20201110'		--당일 콜 대상 
/* 유동조건절 */
--AND AL.svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
--AND AL.svcnb  = '15882424'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
GROUP BY  AL.custnb, call_dt_ymd, al.svcnb	 
ORDER BY  AL.custnb, call_dt_ymd, al.svcnb
;


/* 3-2 콜건수 - 성별연령대*/
SELECT 
	   al.custnb    AS custnb
	 , AL.call_dt_ymd	AS stat_date
	 , SI.custom_gender     AS custom_gender
	 , SI.custom_age     AS custom_age
	 , COUNT(AL.call_id)  AS call_cnt
 	 , '1'			AS speaker
 	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb
	 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb
	, 'BAT'	AS reg_user
FROM  public.tb_ca_api_log  AL 
INNER JOIN tb_ca_api_subinfo SI
   ON AL.call_id  = SI.call_id 
INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
AND AL.call_dt_ymd = '20201110'		--당일 콜 대상 
/* 유동조건절 */
--AND AL.svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
--AND AL.svcnb  = '15882424'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
GROUP BY  AL.custnb, call_dt_ymd, SI.custom_gender, SI.custom_age
ORDER BY  AL.custnb, call_dt_ymd, SI.custom_gender, SI.custom_age
;

/* 3-3 지역별*/
SELECT 
	   al.custnb    AS custnb
	 , AL.call_dt_ymd	AS stat_date
	 , SI.zone_l1     AS zone_l1
	 , SI.zone_l2     AS zone_l2
	 , COUNT(AL.call_id)  AS call_cnt
 	 , '1'			AS speaker
 	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb
	 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb
	, 'BAT'	AS reg_user
FROM  public.tb_ca_api_log  AL 
INNER JOIN tb_ca_api_subinfo SI
   ON AL.call_id  = SI.call_id 
INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
AND AL.call_dt_ymd = '20201110'		--당일 콜 대상 
/* 유동조건절 */
--AND AL.svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
--AND AL.svcnb  = '15882424'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
GROUP BY  AL.custnb, call_dt_ymd, SI.zone_l1, SI.zone_l2
ORDER BY  AL.custnb, call_dt_ymd, SI.zone_l1, SI.zone_l2
;

/* 3-4 업종별*/
SELECT 
	   al.custnb    AS custnb
	 , AL.call_dt_ymd	AS stat_date
	 , SI.custom_bizname  AS custom_bizname
	 , COUNT(AL.call_id)  AS call_cnt
 	 , '1'			AS speaker
 	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb
	 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb
	, 'BAT'	AS reg_user
FROM  public.tb_ca_api_log  AL 
INNER JOIN tb_ca_api_subinfo SI
   ON AL.call_id  = SI.call_id 
INNER JOIN public.tb_ca_biz_master  BM 
   ON BM.custnb  = AL.custnb 
WHERE 1=1
AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
AND AL.call_dt_ymd = '20201110'		--당일 콜 대상 
/* 유동조건절 */
--AND AL.svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
--AND AL.svcnb  = '15882424'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
GROUP BY  AL.custnb, call_dt_ymd, SI.custom_bizname 
ORDER BY  AL.custnb, call_dt_ymd, SI.custom_bizname 
;


/*인기 키워드 테이블 확인 */
SELECT * 
FROM public.tb_ca_keyword_svcnb_day
WHERE 1=1
;


SELECT * 
FROM public.tb_ca_keyword_genage_day
WHERE 1=1
;

SELECT * 
FROM public.tb_ca_keyword_area_day
WHERE 1=1
;

SELECT * 
FROM public.tb_ca_keyword_biz_day
WHERE 1=1
;
/* 인기 키워드 테이블 확인 */

/* 불만,만족 테이블 확인 */
SELECT * 
FROM public.tb_ca_user_stat_keyword_svcnb_day
WHERE 1=1
;

SELECT * 
FROM public.tb_ca_user_stat_keyword_genage_day
WHERE 1=1
;

SELECT * 
FROM public.tb_ca_user_stat_keyword_area_day
WHERE 1=1
;

SELECT * 
FROM public.tb_ca_user_stat_keyword_biz_day
WHERE 1=1
;
/* 불만,만족 테이블 확인 */



--업체 bizmaster 정보 들어가 잇는지 확인하고 10/1 ~ 11/20까지 배치 돌리자...
--통계 null처리 ... 
--내일 배치 로그 에러 처리 
--통계 배







/* keyword filter */
			SELECT 
				 al.custnb    AS cubtnb		--업체식별번호
			 , AL.call_dt_ymd	AS stat_date      --배치일자
			 , al.svcnb 	AS svcnb
			 , AK.keyword  
			 , UKM.u_keyword   AS u_keyword 	
			 , UKM.keyword_type AS keyword_type --관심,불만구분
			 , '1'			AS speaker
--			 , count(AK.keyword)		AS keyword_cnt    --카운트(default '0')	
			, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
			, 'BAT'	 		AS reg_user       --등록자
			FROM 
				 (SELECT 
						/* 유의어 치환 */
					     UK.ucid 
					   , UK.custnb
					   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
					   		   ELSE UK.keyword  
					   		   END 
					   	 ) AS keyword
					   , UK.speaker 
					   , UK.count
					--count (*)
					FROM (
						/* 불용어 제거  */
						SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
						FROM aicc_ta.tbta_aly_keyword A
						INNER JOIN public.tb_ca_api_log B 
						 ON A.ucid  = B.call_id 
						WHERE A.keyword NOT IN (
									SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
									WHERE C.custnb = B.custnb)
					) UK
					LEFT OUTER JOIN (
									SELECT a.custnb , a.std_keyword , b.synonym_keyword
									FROM tb_ca_user_stdkeyword_mgt A
					  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
									   ON  A.custnb = b.custnb 
									   AND a.seq  = b.std_keyword_seq
									WHERE 1=1
									AND a.use_yn  = 'Y'
									AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN tb_ca_user_key_mgt  UKM
		   ON AL.custnb  = UKM.custnb 
		   AND trim(AK.keyword) = trim(UKM.u_keyword) 
		   AND ukm.use_yn  = 'Y'
		   ;







SELECT 
*
FROM tb_ca_biz_master
;

/* tb_biz_master => tb_ca_biz_master */
INSERT  INTO tb_ca_biz_master (
	  aicc_id       --AICC ID(서비스 플랫폼측 청약정보Key)
	, custnb       --고객식별번호
	, svcnb       --회선번호(가입자번호)
	, svc_status       --서비스 상태
	, cstmr_id       --고객ID
	, cstmr_nm       --고객명
	, svc_id       --서비스ID
	, svc_nm       --서비스명
	, cntrct_bgnde       --계약시작일
	, subscrpt_id       --청약ID
	, cmpnm       --상호명(회사명, 법인명)
	, cstmr_telno       --고객전화번호
	, cstmr_email_adres       --고객이메일주소
)
SELECT 
	'aicc_id_' || to_char(seq) 
	, custnb
	, svcnb
	, service_status  
	, 'b1234_' || to_char(seq)	--고객id
	, cmpnm	--고객명
	, 'gn_01' || to_char(seq)	--서비스id
	, '테스트서비스'     --서비스명
	, '2020-10-01'       --개통시작일
	, 'scid_gn' || to_char(seq)    --청약id
	, cmpnm       --상호명(회사명, 법인명) 
	, '02-111-123' || to_char(seq)       --고객 전화번호(D) 
	, mngr_email_adres       --고객이메일주소
FROM tb_biz_master
WHERE 1=1
AND custnb IN ('1234598765', '8232574125')
;

SELECT * FROM tb_ca_biz_master;

--TRUNCATE TABLE tb_ca_keyword_svcnb_day;

--  WHEN 1 THEN '15882424'
--	WHEN 2 THEN	'15882489'
--	WHEN 3 THEN	'15881124'
--	WHEN 4 THEN '15882425'	




/* keyword filter */
SELECT t.*
FROM (
		SELECT 
			/* 유의어 치환 */
		     UK.ucid 
		   , UK.custnb
		   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
		   		   ELSE UK.keyword  
		   		   END 
		   	 ) AS keyword
		   , UK.speaker 
		   , UK.count
		--count (*)
		FROM (
			/* 불용어 제거  */
			SELECT  A.ucid , A.keyword , A.speaker , A.count , al.custnb 
			FROM aicc_ta.tbta_aly_keyword A
			INNER JOIN public.tb_ca_api_log AL 
			 ON a.ucid  = al.call_id 
			WHERE a.keyword NOT IN (
						SELECT u_keyword FROM tb_ca_user_stopword_mgt B 
						WHERE B.custnb = al.custnb)
		) UK
		LEFT OUTER JOIN (
						SELECT a.custnb , a.std_keyword , b.synonym_keyword
						FROM tb_ca_user_stdkeyword_mgt A
		  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
						   ON  A.custnb = b.custnb 
						   AND a.seq  = b.std_keyword_seq
						WHERE 1=1
						AND a.use_yn  = 'Y'
						AND b.use_yn = 'Y'
		) SK
		ON UK.custnb = SK.custnb
		AND UK.keyword = SK.synonym_keyword 
		WHERE 1=1
) t 
WHERE 1=1
--AND t.keyword = '가공'
AND t.keyword = '혜란'
;

SELECT * FROM tb_ca_user_stopword_mgt
WHERE 1=1
AND u_keyword  = '가공'

--불용어 제거 테스트 위해 2개이상의 업에에 속해 있는 키워드 조회
SELECT 
	  a.ucid
	, a.keyword
	, b.custnb
FROM (
	SELECT *
	FROM aicc_ta.tbta_aly_keyword
	WHERE 1=1
	AND keyword IN (
		SELECT 
		--count(*) 
		keyword 
		FROM aicc_ta.tbta_aly_keyword 
		WHERE 1=1
		GROUP BY keyword 
		HAVING count(keyword)  > 1
	)
) a
 INNER JOIN tb_ca_api_log b 
 ON a.ucid = b.call_id
WHERE 1=1 
ORDER BY a.keyword , b.custnb
;

/* 불용어 제거  */
SELECT  
--A.ucid , A.keyword , A.speaker , A.count 
count(*)
FROM aicc_ta.tbta_aly_keyword A
WHERE a.keyword NOT IN (SELECT u_keyword FROM tb_ca_user_stopword_mgt)
;

/* 고객별 불용어 */
SELECT t.*
FROM (
	/* 업체별 불용어 제거 */
	SELECT  
	A.ucid , A.keyword , A.speaker , A.count , al.custnb 
	--count(*)
	FROM aicc_ta.tbta_aly_keyword A
	INNER JOIN public.tb_ca_api_log AL 
	 ON a.ucid  = al.call_id 
	WHERE a.keyword NOT IN (
				SELECT u_keyword FROM tb_ca_user_stopword_mgt B 
				WHERE B.reg_user = al.custnb
				)
) T 
WHERE 1=1
/* 1234598765 업체의 가공이 불용어다 */
--AND t.custnb = '1234598765'
--AND t.keyword  = '가공'
/* 8232574125 업체의 가공의 나오와 햔다. */
AND t.custnb = '8232574125'
AND t.keyword  = '가공'
;

SELECT * 
FROM tb_ca_user_stopword_mgt
WHERE 1=1
;

/* 유의어 조회 업체별 */
		SELECT 
--			STD.custnb , STD.std_keyword , SYNO.synonym_keyword , STD.use_yn AS std_yn, SYNO.use_yn AS sysno_yn
			STD.
		FROM tb_ca_user_stdkeyword_mgt STD
		 INNER JOIN tb_ca_user_synoymkeyword_mgt SYNO
 			ON STD.custnb = SYNO.custnb 
			AND STD.std_keyword  = SYNO.std_keyword
		WHERE 1=1
--			AND STD.custnb = '1234598765'
			AND STD.custnb = AL.custnb 
			AND STD.use_yn  = 'Y'
			AND SYNO.use_yn = 'Y'
			
/* 유의어 조회 모든업체 */
SELECT a.custnb , a.std_keyword , b.synonym_keyword
FROM tb_ca_user_stdkeyword_mgt A
INNER JOIN tb_ca_user_synoymkeyword_mgt B 
ON A.custnb = b.custnb 
AND a.std_keyword  = b.std_keyword
WHERE 1=1
AND a.use_yn  = 'Y'
AND b.use_yn = 'Y'
;

SELECT * FROM tb_ca_api_log 
WHERE 1=1
;

INSERT INTO tb_ca_user_stopword_mgt
(
	 u_keyword
	 , use_yn
	, reg_user
)VALUES ( '가공','Y','1234598765')
;

/* 유의어 insert */

SELECT * FROM tb_ca_user_stdkeyword_mgt;

INSERT INTO tb_ca_user_stdkeyword_mgt(
	 custnb       
	, std_keyword  
	, reg_user     
)values('1234598765', '가', '91270000')
	, ('1234598765', '콤머', '91270000')
	, ('1234598765', '상환', '91270000')
	, ('1234598765', '대출', '91270000')
	, ('1234598765', '표준', '91270000')
	, ('1234598765', '콜', '91270000' )
	, ('1234598765', '하하', '91270000')
;


INSERT INTO tb_ca_user_synoymkeyword_mgt (
	  custnb       --고객식별번호
	, std_keyword       --표준키워드
	, synonym_keyword       --유의어키워드
	, reg_user       --등록자
)values('1234598765', '가', '가1', '91270000')
	, ('1234598765', '콤머','콤머1', '91270000')
	, ('1234598765', '콤머','콤머2', '91270000')
	, ('1234598765', '콤머','콤머3', '91270000')
	, ('1234598765', '상환', '상황', '91270000')
	, ('1234598765', '상환', '송환','91270000')
	, ('1234598765', '상환', '성환','91270000')
	, ('1234598765', '대출', '디출','91270000')
	, ('1234598765', '표준','포준', '91270000')
	, ('1234598765', '콜','전화', '91270000' )
	, ('1234598765', '하하','호호', '91270000')
;





SELECT DISTINCT (week_nb)
FROM tb_ca_keyword_svcnb_day
;

SELECT * 
FROM public.tb_ca_user_key_mgt
WHERE 1=1
;

SELECT * 
FROM public.tb_ca_user_stopword_mgt
WHERE 1=1
;

SELECT * 
FROM public.tb_ca_user_synonym_mgt
WHERE 1=1
;



SELECT 
	*
--	count(*)
FROM tb_ca_keyword_svcnb_day
WHERE 1=1
AND stat_date  = '20201101'
AND custnb = '1234598765'
AND svcnb = '15882425'
;

SELECT  UNNEST(string_to_array('사과,배,딸기,수박', ',')); 

/* 유의어 치환 FILTER */
SELECT 
     UK.ucid 
   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.standard 
   		   ELSE UK.keyword  
   		   END 
   	 ) AS keyword
   , UK.speaker 
   , UK.count
--count (*)
FROM (
	/* 불용어 FILTER */
	SELECT  A.ucid , A.keyword , A.speaker , A.count 
	FROM aicc_ta.tbta_aly_keyword A
	WHERE a.keyword NOT IN (SELECT u_keyword FROM tb_ca_user_stopword_mgt )
) UK
LEFT OUTER JOIN tb_ca_user_synonym_mgt SK
ON UK.keyword = SK.synonym_keyword 
AND SK.use_yn = 'Y'
WHERE 1=1
-- 모두  11,427
--AND SK.synonym_keyword IS NOT NULL	--59개
--AND SK.synonym_keyword IS  NULL	 --11,368
;

-- 유의어 잘 교체 됐는지 확인 쿼리 
SELECT *
FROM (
				SELECT 
		     UK.ucid 
		   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.standard 
		   		   ELSE UK.keyword  
		   		   END 
		   	 ) AS keyword
		   , UK.speaker 
		   , UK.count
		--count (*)
		FROM (
			/* 불용어 FILTER */
			SELECT  A.ucid , A.keyword , A.speaker , A.count 
			FROM aicc_ta.tbta_aly_keyword A
			WHERE a.keyword NOT IN (SELECT u_keyword FROM tb_ca_user_stopword_mgt )
		) UK
		LEFT OUTER JOIN tb_ca_user_synonym_mgt SK
		ON UK.keyword = SK.synonym_keyword 
		AND SK.use_yn = 'Y'
		WHERE 1=1
		-- 모두  11,427
		--AND SK.synonym_keyword IS NOT NULL	--59개
		--AND SK.synonym_keyword IS  NULL	 --11,368
) kk
WHERE 1=1
AND kk.keyword = '콜'
;

/* 유의어 filter */
SELECT * 
FROM aicc_ta.tbta_aly_keyword UK
LEFT OUTER JOIN tb_ca_user_synonym_mgt SK
ON UK.keyword = SK.synonym_keyword 
AND SK.use_yn = 'Y'
WHERE 1=1
;

-- distinct 207개

--distinct(ucid)
FROM aicc_ta.tbta_aly_keyword
WHERE 1=1
AND ucid = '20200517135354337_116820984'
;

ORDER BY ucid
;

SELECT * FROM tb_ca_api_log 
WHERE 1=1
AND call_id  = '20200517161334285_116820984'
;

SELECT  * 
FROM tb_ca_api_log  
WHERE 1=1
AND voc_file_path = '/nas/src/enc'
;
--AND voc_file_nm  = 'CM12160099720318702095_20200925_102953_20200925_102958_44576.mp3'



/* 1-2 업체 

INSERT 
--1.일기준으로 해당 검색 필터의 대한 조회 
-- 2. 조회된 data기준 년, 월, 컬럼 data생성 
-- 2. 2020년 11월인 애들중
--   2.1 2020년 11월의 
--일
--주
--2주
--월

SELECT * FROM tb_ca_api_log
;

SELECT * FROM tb_ca_api_subinfo
;


SELECT *
FROM aicc_ta.tbta_aly_keyword
;





/*  주통계 키워드 배치 insert 
 * 
 */
INSERT INTO tb_ca_keyword_week (

)
;

SELECT DATE_PART('week', NOW()) AS stat_week ;      --배치 주



  	  DATE_PART('week', TIMESTAMP NOW()) AS stat_week       --배치 주
	, BM.subscrpt_id	AS subscrpt_id       --청약ID
	, count(ak.keyword)	AS keyword_cnt       --카운트--.default '0'
	, AK.keyword		AS keyword       --키워드 명
	, AK.rel_list		AS rel_list       --연관어리스트-->연관어 분석 결과 리스트{가입,요금,그때,정도,월정}
	, AL.ib_ob			AS speaker       --화자구분 -->default '1'  ( 1 = MixAS 2 = TxAS 4 = Rx)
	, 'BAT'				AS reg_user       --등록자
	, NOW()	 			AS reg_date       --등록일자-->now())

SELECT *
FROM aicc_ta.tbta_aly_keyword
WHERE 1=1
;
	
SELECT 
--  	  count(ak.keyword)	AS keyword_cnt       --카운트--.default '0'
	 ak.keyword    	AS keyword	
FROM aicc_ta.tbta_aly_keyword  AK
INNER JOIN public.tb_ca_api_log  AL 
 ON AK.ucid =  AL.call_id 
  INNER JOIN public.tb_ca_biz_master  BM 
    ON BM.subscrpt_id  = AL.subscrpt_id 
WHERE 1=1
AND AL.call_dt_ymd = '20201101'
GROUP BY ak.keyword 
--AND AL.csr_id  = ''
--AND AL.csr_nm  LIKE '%%'


SELECT EXTRACT(DOW FROM TIMESTAMP '2020-11-07 00:00:00');

SELECT EXTRACT(DOW FROM now());

SELECT EXTRACT(DOY FROM now());

SELECT EXTRACT(DAY FROM TIMESTAMP '2020-11-10 20:38:40');

SELECT EXTRACT(DAY FROM INTERVAL '40 days 1 minute');

SELECT EXTRACT(DECADE FROM TIMESTAMP '2020-02-16 20:38:40');

SELECT EXTRACT(ISODOW FROM TIMESTAMP '2020-11-12 13:30:15');

-- 주별 버리면 월요일 나옴...
-- 주별 통계는 월~일까지의 통계로 하자...
-- 11월 기준 월요일은 2, 9, 16, 23, 30 
SELECT DATE_TRUNC('week', now());

--11-02
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-02 13:30:15'); --월
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-03 13:30:15');  
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-04 13:30:15');  
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-05 13:30:15');  
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-06 13:30:15');  
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-07 13:30:15');
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-08 13:30:15'); --일

--11-09
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-09 13:30:15'); --월
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-10 13:30:15');  
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-11 13:30:15');  
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-12 13:30:15');  
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-13 13:30:15');  
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-14 13:30:15');
SELECT DATE_TRUNC('week', TIMESTAMP '2020-11-15 13:30:15'); --일


SELECT DATE_PART('month',TIMESTAMP '2020-11-13 13:30:15') 
	, DATE_PART('week', TIMESTAMP '2020-11-13 13:30:15');

SELECT DATE_PART('week', TIMESTAMP '2020-11-01 13:30:15') UNION ALL --일
SELECT DATE_PART('week', TIMESTAMP '2020-11-02 13:30:15') UNION ALL --월
SELECT DATE_PART('week', TIMESTAMP '2020-11-03 13:30:15') UNION ALL  
SELECT DATE_PART('week', TIMESTAMP '2020-11-04 13:30:15') UNION ALL  
SELECT DATE_PART('week', TIMESTAMP '2020-11-05 13:30:15') UNION ALL  
SELECT DATE_PART('week', TIMESTAMP '2020-11-06 13:30:15') UNION ALL  
SELECT DATE_PART('week', TIMESTAMP '2020-11-07 13:30:15') UNION ALL
SELECT DATE_PART('week', TIMESTAMP '2020-11-08 13:30:15') UNION ALL --일
--11-09
SELECT DATE_PART('week', TIMESTAMP '2020-11-09 13:30:15') UNION ALL
SELECT DATE_PART('week', TIMESTAMP '2020-11-10 13:30:15') UNION ALL  
SELECT DATE_PART('week', TIMESTAMP '2020-11-11 13:30:15') UNION ALL  
SELECT DATE_PART('week', TIMESTAMP '2020-11-12 13:30:15') UNION ALL  
SELECT DATE_PART('week', TIMESTAMP '2020-11-13 13:30:15') UNION ALL  
SELECT DATE_PART('week', TIMESTAMP '2020-11-14 13:30:15') UNION ALL
SELECT DATE_PART('week', TIMESTAMP '2020-11-15 13:30:15'); --일


-- 11/12일 현재 기준 +1 하면 다음주 월요일 11/16반환
--                     요번주 월요일  11/09
--               -1 하면 전주 월요일 11/02
SELECT date_trunc('week', now() + interval '1 weeks'); 

/* 주별 정의 필요 */
--현재 시점으로 부터 4주를?

/* 해당일 금주, 전주, 전전주, 전전전주 */
SELECT
  COUNT(case when date_trunc('week' , "createdAt") = date_trunc('week', now()) then 1 END ) as week1,						--금주
  COUNT(case when date_trunc('week' , "createdAt") = date_trunc('week', now() - interval '1 weeks') then 1 end) as week2,	--전주
  COUNT(case when date_trunc('week' , "createdAt") = date_trunc('week', now() - interval '2 weeks') then 1 end) as week3,	--전전주	
  COUNT(case when date_trunc('week' , "createdAt") = date_trunc('week', now() - interval '3 weeks') then 1 end) as week4	--전전전주
FROM "user";

/* 해당년에 월과 몇주인지를 작성* /
 *  해당년에 주넘버로 그룹핑
 *  -- 이경우 월을 필터로 설정하면 어떻게 주를 자를지 고민...11/01일 일요일이라 44주 가 되서 얘는 10월 마지막 주 애들이라 뭍인다. 
 *  -- 그런데 11월로 가져오면 44주인 11/01 data도 포함되는 문제가 생김...
 *  -- 그냥 그런데로 11월은  6주로 처리 하면 좋은데..11/1(일)1주, 2~8, 9~15, 16~22, 23~29 11/30(월) 이렇게 6주의 주 number 존재..
 *  -- 1) 시작일 ~ 종료일 까지 한주가 꽉 차지 않더라도 선택이 기간에 무조건 주number로 그룹해서 보여주는 방법
 *  -- 2) 이거 기획이 나와야 할듯 하다. 
 * 
 */ 
SELECT date_part('week',TIMESTAMP '2020-11-02');

SELECT TO_CHAR(NOW(), 'YYYY-MM-DD HH24:MI:SS.MS');
SELECT TO_CHAR(NOW(), 'YYYY-MM-DD');

--alter table tb_ca_api_log add column dec_flag int;



/* insert tb_ca_api_log */
insert into tb_ca_api_log(
	seq
	,  call_id
	, call_dt_ymd
	, call_dt_hms
	, csr_id
	, csr_nm
	, custom_id
	, ib_ob
	, duration_time
	, voc_file_path
	, voc_file_nm
	, enc_file_size
	, dec_file_size
	, enckey
	, enc_alg
	, subscrpt_id
	, goods_id
	, dec_flag
	, customer_number
)values( default, '10001', '20201110', '11:01', '102', '김길동', '1003', '3', 60, 'D:\\Gnew\\file\\enc', 'CM12159738097871957040_20200814_135707_20200814_135807_48605.mp3.enc'
, '120576', '120576' , 'VfVrb2ngvJy6vZdCxSeefA==', 'seed 128 cbc', 'aq111' , 'sku111' , 0, '1234567')
, ( default, '10002', '20201110', '11:01', '103', '고길동', '1003', '3', 113, 'D:\\Gnew\\file\\enc', 'CM12160067313918838600_20200921_162704_20200921_162857_04807.mp3.enc'
, '226704' , '226701', 'weC45xDdaV5kT1emBRut2Q==', 'seed 128 cbc', 'aq222', 'sku222', 0, '1234567')
, ( default, '10003', '20201110', '11:01', '104', '황길동', '1003', '3', 237, 'D:\\Gnew\\file\\enc', 'CM12160067424943959150_20200921_164532_20200921_164930_89363.mp3.enc'
, '474960' , '474957', 'weC45xDdaV5kT1emBRut2Q==', 'seed 128 cbc', 'aq333', 'sku3333', 0, '1234567')
, ( default, '10004', '20201110', '11:01', '105', '이길동', '1003', '3', 5, 'D:\\Gnew\\file\\enc', 'CM12160099720318702095_20200925_102953_20200925_102958_44576.mp3.enc'
, '11424' , '11424', 'NH0995TESxM9hadIj2XPVw==', 'seed 128 cbc', 'aq444', 'sku4444', 0, '1234567')
, ( default, '10005', '20201111', '10:01', '103', '고길동', '1004', '3', 483, 'D:\\Gnew\\file\\enc', '20200519103142_TEMP_20200519103142_1(DSP OFF).mp3.enc'
, '1935360' , '1935360', 'VfVrb2ngvJy6vZdCxSeefA==', 'seed 128 cbc', 'aq555', 'sku5555', 0, '987456')
;

--
--				'1', 
--			, current_date
--			, current_time
--			, '100'
--			, '이상담'
--			, '1000'		
--			,  '3' 			--1: r, 2:T , 3: mono
--			, 15
--			, 'D:\\Gnew\\file\\org'		-- 음원경로
--			, '40.mp5.enc'		--음원 파일명
--			, '48'		-- 암호화 파일 크기 
--			, '40' 		-- 복호화 파일 크기 
--			, 'aq123'		-- 청약 id
--			, 'sku1232' 		-- 상품id
--			, 0				-- 0: enc, 1: dec
--)
--;

select  'dkfajldsf', 12 , dkkd 

select current_date;
, current_time;


SELECT 
	*
FROM aicc_ta.tbta_aly_keyword
WHERE keyword IN (		SELECT keyword
		FROM aicc_ta.tbta_aly_keyword
		WHERE 1=1
		GROUP BY keyword
		HAVING count(keyword) >1
)
ORDER BY keyword 
		;

SELECT 
--  	  count(ak.keyword)	AS keyword_cnt       --카운트--.default '0'
	  ak.keyword    	AS keyword	
	, ak.rel_list   
	, count(ak.rel_list) AS cnt
FROM aicc_ta.tbta_aly_keyword  AK
WHERE 1=1
--AND AL.call_dt_ymd = '20201101'
GROUP BY ak.keyword , ak.rel_list
;

/* 랜덤 쿼리 */
SELECT  round(CAST(random() *1 AS numeric), 0);
			
SELECT  (CASE WHEN round(CAST(random() *1 AS numeric), 0) = 0
			THEN '1234598765'
			ELSE '8232574125' END ) 
SELECT to_char(timestamp '2020-10-01 00:01:00.000000' + random() * (timestamp '2020-11-18 23:59:59.999999' - timestamp '2020-10-01 00:01:00.000000'),'YYYYMMDD');


SELECT *
--encKey 
FROM tb_ca_api_log tcal s
where 1=1
--AND voc_file_nm  = 'CM12160099720318702095_20200925_102953_20200925_102958_44576.mp3.enc'
;


