-- 상담VOC 추이(차트)
        select call_dt_ymd,         -- call일자  
               count(*) call_cnt    -- call count
          from tb_ca_api_log
         where 1=1
           and custnb = '1234598765'
           and svcnb = '15882424'
           and call_dt_ymd between '20201112' and '20201125'    -- 기간(데이터가 없어서 일단 2주 조회, 차후 1주로 변경)
         group by call_dt_ymd
         order by call_dt_ymd
         
-- 상담VOC 추이(전체건수)
        select count(*) as total_voc_cnt, now()
          from tb_ca_api_log
         where 1=1
           and custnb = '1234598765'
           and svcnb = '15882424'
           and call_dt_ymd between '20201112' and '20201125'   -- 기간(데이터가 없어서 일단 2주 조회, 차후 1주로 변경)
           
-- 상담VOC 추이(전체건수)
        select (a.total_voc_cnt - b.total_voc_cnt) as comp_voc_cnt
          from (
                select count(*) as total_voc_cnt
                  from tb_ca_api_log
                 where 1=1
                   and custnb = '1234598765'
                   and svcnb = '15882424'
                   and call_dt_ymd = '20201107'
               ) b, 
               (
                select count(*) as total_voc_cnt
                  from tb_ca_api_log
                 where 1=1
                   and custnb = '1234598765'
                   and svcnb = '15882424'
                   and call_dt_ymd = '20201125'
               ) a
           
-- 상담VOC 추이(최고/평균/최소 통화시간)
        select max(duration_time) as max_duration_time, min(duration_time) as min_duration_time, avg(duration_time) as avg_duration_time
          from tb_ca_api_log
         where 1=1
           and custnb = '1234598765'
           and svcnb = '15882424'
           and call_dt_ymd between '20201112' and '20201125'
           
-- VOC 유형별 콜 점유율(회선별)
        select svcnb, svcnb_cnt, ROUND((svcnb_cnt / SUM(svcnb_cnt) OVER()::numeric) * 100.0) 
          from (
                select svcnb, count(*) as svcnb_cnt
                  from tb_ca_api_log
                 where 1=1
                   and custnb = '1234598765'
                   and call_dt_ymd between '20201112' and '20201125'
                 group by svcnb
         )
         order by svcnb_cnt desc
         
-- VOC 유형별 콜 점유율(성별별)      
        select custom_gender, gender_cnt, ROUND((gender_cnt / SUM(gender_cnt) OVER()::numeric) * 100.0) 
          from (
                select s.custom_gender, count(*) as gender_cnt
                  from tb_ca_api_log l 
                 inner join tb_ca_api_subinfo s on s.call_id = l.call_id
                 where 1=1
                   and l.custnb = '1234598765'
                   and l.call_dt_ymd between '20201112' and '20201125'
                 group by s.custom_gender 
         )
         order by gender_cnt desc
         
-- VOC 유형별 콜 점유율(연령별)      
        select custom_age, age_cnt, ROUND((age_cnt / SUM(age_cnt) OVER()::numeric) * 100.0) 
          from (
                select s.custom_age , count(*) as age_cnt
                  from tb_ca_api_log l 
                 inner join tb_ca_api_subinfo s on s.call_id = l.call_id
                 where 1=1
                   and l.custnb = '1234598765'
                   and l.call_dt_ymd between '20201112' and '20201125'
                 group by s.custom_age 
         )
         order by custom_age
       
-- 태그 클라우드(차트)
        select keyword, keyword_cnt 
          from tb_ca_keyword_svcnb_day
         where 1=1
           and svcnb = '15882424'
           and stat_date between '20201112' and '20201125'
         order by keyword_cnt desc
     
        
-- 태그 클라우드(테이블용 데이터)
        select keyword, keyword_cnt 
          from tb_ca_keyword_svcnb_day
         where 1=1
           and svcnb = '15882424'
           and stat_date between '20201112' and '20201125'
         order by keyword_cnt desc
        LIMIT 10         
 		
        
        
        
-- 인기키워드 
        select keyword, keyword_cnt, ROUND((keyword_cnt / max(keyword_cnt) OVER()::numeric) * 100.0) 
          from (
                select keyword, keyword_cnt
                  from tb_ca_keyword_svcnb_day
                 where 1=1
                   and svcnb = #{svcnb}
                   and stat_date between #{startDate} and #{endDate}
                 order by keyword_cnt desc
                 limit 10
                )
        
-- 불만키워드 
        select keyword, keyword_cnt, ROUND((keyword_cnt / max(keyword_cnt) OVER()::numeric) * 100.0) 
          from (
                select u_keyword as keyword, keyword_cnt
                  from tb_ca_user_stat_keyword_svcnb_day
                 where 1=1
                   and svcnb = '15882424'
                   and stat_date between '20201117' and '20201123'
                   and keyword_type = 0
                 order by keyword_cnt desc
                 limit 10
                )
       
        
-- 관심키워드 
        select keyword, keyword_cnt, ROUND((keyword_cnt / max(keyword_cnt) OVER()::numeric) * 100.0) 
          from (
                select u_keyword as keyword, keyword_cnt
                  from tb_ca_user_stat_keyword_svcnb_day
                 where 1=1
                   and svcnb = '15882425'
                   and stat_date between '20201117' and '20201123'
                   and keyword_type = 1
                 order by keyword_cnt desc
                 limit 10
                )
