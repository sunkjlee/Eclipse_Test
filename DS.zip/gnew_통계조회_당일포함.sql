
SELECT DATE_PART('week', TO_DATE('20201105'));

/* 최종 목적쿼리 조회 */

/* 1-1 인기 회선 */
SELECT 
	RST.custnb, RST.svcnb, RST.keyword
, sum(keyword_cnt) AS keyword_cnt
FROM (
		SELECT 
		     custnb 
		   , stat_date 
		   , svcnb 
   	       , keyword 
		   , keyword_cnt 
		   , speaker 
		   , mon_nb 
		   , week_nb 
		FROM tb_ca_keyword_svcnb_day
		WHERE 1=1
		--AND custnb = '8232574125'   -- 로그인 업체식별번호
		--AND svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
		AND custnb = '1234598765'   -- 로그인 업체식별번호 :
		--AND svcnb  = '15882489'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
		/* 기간 검색 조건*/
--		AND	stat_date BETWEEN '20201109' AND '20201109'	--검색 기간 조건
--		AND  	week_nb =  DATE_PART('week', TO_DATE('20201105'))	--2020-11-05일 선택 주 data 조회 시 
		AND  week_nb BETWEEN DATE_PART('week', TO_DATE('20201006')) AND DATE_PART('week', TO_DATE('20201016'))  -- 10월6일~ 10월16일 2주 선택시 
		--AND  mon_nb BETWEEN 10 AND 10
		UNION ALL 
		SELECT 
			   al.custnb    AS cubtnb
			 , AL.call_dt_ymd	AS stat_date
		  	 , al.svcnb 	AS svcnb
		  	 , COALESCE(AK.keyword,'N/A') AS keyword
			 , count(AK.keyword)		AS keyword_cnt	
			 , 1			AS speaker
			, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
		FROM ( /* keyword filter */
				 SELECT 
						 UK.ucid 
					   , UK.custnb
					   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
					   		   ELSE UK.keyword  
					   		   END 
					   	 ) AS keyword
					   , UK.speaker 
					   , UK.count
					FROM (
						SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
						FROM aicc_ta.tbta_aly_keyword A
						INNER JOIN public.tb_ca_api_log B 
						 ON A.ucid  = B.call_id 
						WHERE A.keyword NOT IN (
									SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
									WHERE C.custnb = B.custnb)
					) UK
					LEFT OUTER JOIN (
									SELECT a.custnb , a.std_keyword , b.synonym_keyword
									FROM tb_ca_user_stdkeyword_mgt A
					  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
									   ON  A.custnb = b.custnb 
									   AND a.seq  = b.std_keyword_seq
									WHERE 1=1
									AND a.use_yn  = 'Y'
									AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN public.tb_ca_biz_master  BM 
		   ON BM.custnb  = AL.custnb 
		WHERE 1=1
		AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND AL.call_dt_ymd = '20201110'		--당일 콜 대상 
		/* 유동조건절 */
		--AND AL.svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
		--AND AL.svcnb  = '15882424'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
		GROUP BY  AL.custnb, call_dt_ymd, al.svcnb, ak.keyword	 
	) RST
WHERE 1=1
GROUP BY  RST.custnb,  RST.svcnb, RST.keyword
ORDER BY  RST.custnb,  RST.svcnb, RST.keyword
;
 
 
/* 1-2 인기 성별 */
SELECT 
	RST.custnb,RST.custom_gender,RST.custom_age,
	RST.keyword
, sum(keyword_cnt) AS keyword_cnt
FROM (
		SELECT 
		     custnb 
		   , stat_date 
		   , custom_gender
		   , custom_age 
		   , speaker 
		   , keyword 
		   , keyword_cnt 
		   , mon_nb 
		   , week_nb 
		FROM tb_ca_keyword_genage_day 
		WHERE 1=1
		--AND custnb = '8232574125'   -- 로그인 업체식별번호
		AND custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND custom_gender  = 'M'
		AND custom_age  = '20'
		/* 기간 검색 조건*/
		AND	stat_date BETWEEN '20201017' AND '20201018'	--검색 기간 조건
--		AND  	week_nb =  DATE_PART('week', TO_DATE('20201105'))	--2020-11-05일 선택 주 data 조회 시 
--		AND  week_nb BETWEEN DATE_PART('week', TO_DATE('20201006')) AND DATE_PART('week', TO_DATE('20201016'))  -- 10월6일~ 10월16일 2주 선택시 
		--AND  mon_nb BETWEEN 10 AND 10
		UNION ALL 
		SELECT 
			   al.custnb    AS cubtnb
			 , AL.call_dt_ymd	AS stat_date
		  	 , SI.custom_gender AS custom_gender
			 , SI.custom_age    AS custom_age
		  	 , 1			AS speaker
		  	 , COALESCE(AK.keyword,'N/A') AS keyword
			 , count(AK.keyword)		AS keyword_cnt	
			, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
		FROM ( /* keyword filter */
				 SELECT 
						 UK.ucid 
					   , UK.custnb
					   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
					   		   ELSE UK.keyword  
					   		   END 
					   	 ) AS keyword
					   , UK.speaker 
					   , UK.count
					FROM (
						SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
						FROM aicc_ta.tbta_aly_keyword A
						INNER JOIN public.tb_ca_api_log B 
						 ON A.ucid  = B.call_id 
						WHERE A.keyword NOT IN (
									SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
									WHERE C.custnb = B.custnb)
					) UK
					LEFT OUTER JOIN (
									SELECT a.custnb , a.std_keyword , b.synonym_keyword
									FROM tb_ca_user_stdkeyword_mgt A
					  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
									   ON  A.custnb = b.custnb 
									   AND a.seq  = b.std_keyword_seq
									WHERE 1=1
									AND a.use_yn  = 'Y'
									AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN tb_ca_api_subinfo SI			--성별연령,지역,업종일 경우 JOIN
		   ON AL.call_id  = SI.call_id 
		 INNER JOIN public.tb_ca_biz_master  BM 
		   ON BM.custnb  = AL.custnb 
		WHERE 1=1
		AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND AL.call_dt_ymd = '20201019'		--당일 콜 대상 
		/* 유동조건절  */
		AND SI.custom_gender  = 'M'
		AND SI.custom_age  = '20'
		GROUP BY  AL.custnb, call_dt_ymd, SI.custom_gender, SI.custom_age, AK.keyword 
	) RST
WHERE 1=1
GROUP BY  RST.custnb, RST.custom_gender, RST.custom_age, RST.keyword
ORDER BY  RST.custnb, RST.custom_gender, RST.custom_age, RST.keyword
;



/* 1-3 지역별 */
SELECT 
	RST.custnb, RST.zone_l1, RST.zone_l2, RST.keyword
, sum(keyword_cnt) AS keyword_cnt
FROM (
		SELECT 
		     custnb 
		   , stat_date 
		   , zone_l1
		   , zone_l2 
		   , keyword 
		   , keyword_cnt 
		   , speaker
		   , mon_nb 
		   , week_nb 
		FROM tb_ca_keyword_area_day
		WHERE 1=1
		--AND custnb = '8232574125'   -- 로그인 업체식별번호
		AND custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND zone_l1  = 'EF3700'
--		AND zone_l2  = '20'
		/* 기간 검색 조건*/
		AND	stat_date BETWEEN '20201102' AND '20201102'	--검색 기간 조건
--		AND  	week_nb =  DATE_PART('week', TO_DATE('20201105'))	--2020-11-05일 선택 주 data 조회 시 
--		AND  week_nb BETWEEN DATE_PART('week', TO_DATE('20201006')) AND DATE_PART('week', TO_DATE('20201016'))  -- 10월6일~ 10월16일 2주 선택시 
		--AND  mon_nb BETWEEN 10 AND 10
		UNION ALL 
		SELECT 
			   al.custnb    AS cubtnb
			 , AL.call_dt_ymd	AS stat_date
		  	 , SI.zone_l1 AS zone_l1
			 , SI.zone_l2    AS zone_l2
		  	 , COALESCE(AK.keyword,'N/A') AS keyword
			 , count(AK.keyword)		AS keyword_cnt	
			 , 1			AS speaker
			, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
		FROM ( /* keyword filter */
				 SELECT 
						 UK.ucid 
					   , UK.custnb
					   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
					   		   ELSE UK.keyword  
					   		   END 
					   	 ) AS keyword
					   , UK.speaker 
					   , UK.count
					FROM (
						SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
						FROM aicc_ta.tbta_aly_keyword A
						INNER JOIN public.tb_ca_api_log B 
						 ON A.ucid  = B.call_id 
						WHERE A.keyword NOT IN (
									SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
									WHERE C.custnb = B.custnb)
					) UK
					LEFT OUTER JOIN (
									SELECT a.custnb , a.std_keyword , b.synonym_keyword
									FROM tb_ca_user_stdkeyword_mgt A
					  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
									   ON  A.custnb = b.custnb 
									   AND a.seq  = b.std_keyword_seq
									WHERE 1=1
									AND a.use_yn  = 'Y'
									AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN tb_ca_api_subinfo SI			--성별연령,지역,업종일 경우 JOIN
		   ON AL.call_id  = SI.call_id 
		 INNER JOIN public.tb_ca_biz_master  BM 
		   ON BM.custnb  = AL.custnb 
		WHERE 1=1
		AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND AL.call_dt_ymd = '20201103'		--당일 콜 대상 
		/* 유동조건절  */
		AND SI.zone_l1  = 'EF3700'
--		AND SI.zone_l2  = 'ES1234'
		GROUP BY  AL.custnb, call_dt_ymd, SI.zone_l1, SI.zone_l2, AK.keyword 
	) RST
WHERE 1=1
GROUP BY  RST.custnb, RST.zone_l1, RST.zone_l2, RST.keyword
ORDER BY  RST.custnb, RST.zone_l1, RST.zone_l2, RST.keyword
;



/* 1-4 업종별 */
SELECT 
	RST.custnb, RST.BIZ_NM, RST.keyword
, sum(keyword_cnt) AS keyword_cnt
FROM (
		SELECT 
		     custnb 
		   , stat_date 
		   , biz_nm
		   , keyword 
		   , keyword_cnt 
		   , speaker
		   , mon_nb 
		   , week_nb 
		FROM tb_ca_keyword_biz_day
		WHERE 1=1
		--AND custnb = '8232574125'   -- 로그인 업체식별번호
		AND custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND biz_nm  = '20'
		/* 기간 검색 조건*/
		AND	stat_date BETWEEN '20201101' AND '20201110'	--검색 기간 조건
--		AND  	week_nb =  DATE_PART('week', TO_DATE('20201105'))	--2020-11-05일 선택 주 data 조회 시 
--		AND  week_nb BETWEEN DATE_PART('week', TO_DATE('20201006')) AND DATE_PART('week', TO_DATE('20201016'))  -- 10월6일~ 10월16일 2주 선택시 
		--AND  mon_nb BETWEEN 10 AND 10
		UNION ALL 
		SELECT 
			   al.custnb    	AS cubtnb
			 , AL.call_dt_ymd	AS stat_date
		  	 , SI.custom_bizname 		AS biz_nm
		  	 , COALESCE(AK.keyword,'N/A') AS keyword
			 , count(AK.keyword)		AS keyword_cnt	
			 , 1			AS speaker
			, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
		FROM ( /* keyword filter */
				 SELECT 
						 UK.ucid 
					   , UK.custnb
					   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
					   		   ELSE UK.keyword  
					   		   END 
					   	 ) AS keyword
					   , UK.speaker 
					   , UK.count
					FROM (
						SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
						FROM aicc_ta.tbta_aly_keyword A
						INNER JOIN public.tb_ca_api_log B 
						 ON A.ucid  = B.call_id 
						WHERE A.keyword NOT IN (
									SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
									WHERE C.custnb = B.custnb)
					) UK
					LEFT OUTER JOIN (
									SELECT a.custnb , a.std_keyword , b.synonym_keyword
									FROM tb_ca_user_stdkeyword_mgt A
					  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
									   ON  A.custnb = b.custnb 
									   AND a.seq  = b.std_keyword_seq
									WHERE 1=1
									AND a.use_yn  = 'Y'
									AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN tb_ca_api_subinfo SI			--성별연령,지역,업종일 경우 JOIN
		   ON AL.call_id  = SI.call_id 
		 INNER JOIN public.tb_ca_biz_master  BM 
		   ON BM.custnb  = AL.custnb 
		WHERE 1=1
		AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND AL.call_dt_ymd = '20201111'		--당일 콜 대상 
		/* 유동조건절  */
		AND SI.custom_bizname  = '20'
--		AND SI.zone_l2  = 'ES1234'
		GROUP BY  AL.custnb, call_dt_ymd, SI.custom_bizname, AK.keyword 
	) RST
WHERE 1=1
GROUP BY  RST.custnb, RST.BIZ_NM, RST.keyword
ORDER BY  RST.custnb, RST.BIZ_NM, RST.keyword
;












/* 2-1 관심불만 회선 */
SELECT 
	RST.custnb, RST.svcnb, RST.u_keyword
, sum(keyword_cnt) AS keyword_cnt
FROM (
		SELECT 
		   custnb 
		   , stat_date 
		   , svcnb 
		   , keyword_type 
		   , u_keyword 
		   , keyword_cnt 
		   , speaker 
		   , mon_nb 
		   , week_nb 
		FROM tb_ca_user_stat_keyword_svcnb_day
		WHERE 1=1
		--AND custnb = '8232574125'   -- 로그인 업체식별번호
		--AND svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
		AND custnb = '1234598765'   -- 로그인 업체식별번호 :
		--AND svcnb  = '15882489'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
		/* 기간 검색 조건*/
--		AND	stat_date BETWEEN '20201109' AND '20201109'	--검색 기간 조건
--		AND  	week_nb =  DATE_PART('week', TO_DATE('20201105'))	--2020-11-05일 선택 주 data 조회 시 
		AND  week_nb BETWEEN DATE_PART('week', TO_DATE('20201006')) AND DATE_PART('week', TO_DATE('20201016'))  -- 10월6일~ 10월16일 2주 선택시 
		--AND  mon_nb BETWEEN 10 AND 10
		UNION ALL 
		SELECT 
			   al.custnb    AS cubtnb
			 , AL.call_dt_ymd	AS stat_date
		  	 , al.svcnb 	AS svcnb
		  	 , UKM.keyword_type	AS keyword_type
		 	 , COALESCE(UKM.u_keyword,'N/A') AS u_keyword  
		 	 , COUNT(UKM.u_keyword) AS keyword_cnt    
		 	 , 1			AS speaker
		  	 , DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			 , DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
		FROM ( /* keyword filter */
				 SELECT 
						 UK.ucid 
					   , UK.custnb
					   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
					   		   ELSE UK.keyword  
					   		   END 
					   	 ) AS keyword
					   , UK.speaker 
					   , UK.count
					FROM (
						SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
						FROM aicc_ta.tbta_aly_keyword A
						INNER JOIN public.tb_ca_api_log B 
						 ON A.ucid  = B.call_id 
						WHERE A.keyword NOT IN (
									SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
									WHERE C.custnb = B.custnb)
					) UK
					LEFT OUTER JOIN (
									SELECT a.custnb , a.std_keyword , b.synonym_keyword
									FROM tb_ca_user_stdkeyword_mgt A
					  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
									   ON  A.custnb = b.custnb 
									   AND a.seq  = b.std_keyword_seq
									WHERE 1=1
									AND a.use_yn  = 'Y'
									AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN tb_ca_user_key_mgt  UKM
		     ON AL.custnb  = UKM.custnb 
		      AND trim(AK.keyword) = trim(UKM.u_keyword) 
		      AND ukm.use_yn  = 'Y'
		 INNER JOIN public.tb_ca_biz_master  BM 
		   ON BM.custnb  = AL.custnb 
		WHERE 1=1
		AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND AL.call_dt_ymd = '20201110'		--당일 콜 대상 
		/* 유동조건절 */
		--AND AL.svcnb  = '15442424'		-- 가입회선번호	: 15442424,15442489,15441124,15442425
		--AND AL.svcnb  = '15882424'		-- 가입회선정보 : 15882424,15882489,15881124,15882425
	   GROUP BY AL.custnb, call_dt_ymd, al.svcnb, UKM.keyword_type, UKM.u_keyword 		 
	) RST
WHERE 1=1
GROUP BY  RST.custnb,  RST.svcnb, RST.u_keyword
ORDER BY  RST.custnb,  RST.svcnb, RST.u_keyword
;



 
 
/* 2-2 관심불만 성별 */
SELECT 
	RST.custnb,RST.custom_gender,RST.custom_age,
	RST.u_keyword
, sum(keyword_cnt) AS keyword_cnt
FROM (
		SELECT 
		     custnb 
		   , stat_date 
		   , custom_gender
		   , custom_age 
		   , keyword_type 
		   , u_keyword 
		   , keyword_cnt
		   , speaker 
		   , mon_nb 
		   , week_nb 
		FROM tb_ca_user_stat_keyword_genage_day
		WHERE 1=1
--		AND custnb = '8232574125'   -- 로그인 업체식별번호
		AND custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND custom_gender  = 'F'
		AND custom_age  = '40'
		/* 기간 검색 조건*/
		AND	stat_date BETWEEN '20201107' AND '20201115'	--검색 기간 조건
--		AND  	week_nb =  DATE_PART('week', TO_DATE('20201105'))	--2020-11-05일 선택 주 data 조회 시 
--		AND  week_nb BETWEEN DATE_PART('week', TO_DATE('20201006')) AND DATE_PART('week', TO_DATE('20201016'))  -- 10월6일~ 10월16일 2주 선택시 
--		AND  mon_nb BETWEEN 10 AND 10
		UNION ALL 
		SELECT 
			   al.custnb    AS cubtnb
			 , AL.call_dt_ymd	AS stat_date
			 , SI.custom_gender AS custom_gender
			 , SI.custom_age    AS custom_age
		  	 , UKM.keyword_type	AS keyword_type
	 	     , COALESCE(UKM.u_keyword,'N/A') AS u_keyword  
	 	     , COUNT(UKM.u_keyword) AS keyword_cnt    
	 	    , 1			AS speaker
			, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
		FROM ( /* keyword filter */
				 SELECT 
						 UK.ucid 
					   , UK.custnb
					   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
					   		   ELSE UK.keyword  
					   		   END 
					   	 ) AS keyword
					   , UK.speaker 
					   , UK.count
					FROM (
						SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
						FROM aicc_ta.tbta_aly_keyword A
						INNER JOIN public.tb_ca_api_log B 
						 ON A.ucid  = B.call_id 
						WHERE A.keyword NOT IN (
									SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
									WHERE C.custnb = B.custnb)
					) UK
					LEFT OUTER JOIN (
									SELECT a.custnb , a.std_keyword , b.synonym_keyword
									FROM tb_ca_user_stdkeyword_mgt A
					  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
									   ON  A.custnb = b.custnb 
									   AND a.seq  = b.std_keyword_seq
									WHERE 1=1
									AND a.use_yn  = 'Y'
									AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN tb_ca_user_key_mgt  UKM
		     ON AL.custnb  = UKM.custnb 
		      AND trim(AK.keyword) = trim(UKM.u_keyword) 
		      AND ukm.use_yn  = 'Y'
		 INNER JOIN tb_ca_api_subinfo SI			--성별연령,지역,업종일 경우 JOIN
		   ON AL.call_id  = SI.call_id 
		 INNER JOIN public.tb_ca_biz_master  BM 
		   ON BM.custnb  = AL.custnb 
		WHERE 1=1
		AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND AL.call_dt_ymd = '20201116'		--당일 콜 대상 
		/* 유동조건절  */
		AND SI.custom_gender  = 'F'
		AND SI.custom_age  = '40'
		GROUP BY AL.custnb, call_dt_ymd, SI.custom_gender, SI.custom_age,  UKM.keyword_type, UKM.u_keyword
	) RST
WHERE 1=1
GROUP BY  RST.custnb, RST.custom_gender, RST.custom_age, RST.keyword_type, RST.u_keyword
ORDER BY  RST.custnb, RST.custom_gender, RST.custom_age, RST.keyword_type, RST.u_keyword
;


/* 2-3 관심불만 지역  */
SELECT 
	RST.custnb, RST.zone_l1, RST.zone_l2, RST.keyword_type, RST.u_keyword 	
, sum(keyword_cnt) AS keyword_cnt
FROM (
		SELECT 
		     custnb 
		   , stat_date 
		   , zone_l1
		   , zone_l2 
		   , keyword_type 
		   , u_keyword 
		   , keyword_cnt
		   , speaker 
		   , mon_nb 
		   , week_nb 
		FROM tb_ca_user_stat_keyword_area_day
		WHERE 1=1
--		AND custnb = '8232574125'   -- 로그인 업체식별번호
		AND custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND zone_l1  = 'CF3700'
		/* 기간 검색 조건*/
		AND	stat_date BETWEEN '20201101' AND '20201115'	--검색 기간 조건
--		AND  	week_nb =  DATE_PART('week', TO_DATE('20201105'))	--2020-11-05일 선택 주 data 조회 시 
--		AND  week_nb BETWEEN DATE_PART('week', TO_DATE('20201006')) AND DATE_PART('week', TO_DATE('20201016'))  -- 10월6일~ 10월16일 2주 선택시 
--		AND  mon_nb BETWEEN 10 AND 10
		UNION ALL 
		SELECT 
			   al.custnb    AS cubtnb
			 , AL.call_dt_ymd	AS stat_date
			 , SI.zone_l1	 AS zone_l1
			 , SI.zone_l2    AS zone_l2
		  	 , UKM.keyword_type	AS keyword_type
	 	     , COALESCE(UKM.u_keyword,'N/A') AS u_keyword  
	 	     , COUNT(UKM.u_keyword) AS keyword_cnt    
	 	    , 1			AS speaker
			, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
		FROM ( /* keyword filter */
				 SELECT 
						 UK.ucid 
					   , UK.custnb
					   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
					   		   ELSE UK.keyword  
					   		   END 
					   	 ) AS keyword
					   , UK.speaker 
					   , UK.count
					FROM (
						SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
						FROM aicc_ta.tbta_aly_keyword A
						INNER JOIN public.tb_ca_api_log B 
						 ON A.ucid  = B.call_id 
						WHERE A.keyword NOT IN (
									SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
									WHERE C.custnb = B.custnb)
					) UK
					LEFT OUTER JOIN (
									SELECT a.custnb , a.std_keyword , b.synonym_keyword
									FROM tb_ca_user_stdkeyword_mgt A
					  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
									   ON  A.custnb = b.custnb 
									   AND a.seq  = b.std_keyword_seq
									WHERE 1=1
									AND a.use_yn  = 'Y'
									AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN tb_ca_user_key_mgt  UKM
		     ON AL.custnb  = UKM.custnb 
		      AND trim(AK.keyword) = trim(UKM.u_keyword) 
		      AND ukm.use_yn  = 'Y'
		 INNER JOIN tb_ca_api_subinfo SI			--성별연령,지역,업종일 경우 JOIN
		   ON AL.call_id  = SI.call_id 
		 INNER JOIN public.tb_ca_biz_master  BM 
		   ON BM.custnb  = AL.custnb 
		WHERE 1=1
		AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND AL.call_dt_ymd = '20201116'		--당일 콜 대상 
		/* 유동조건절  */
		AND SI.zone_l1  = 'CF3700'
--		AND SI.zone_l2  = 'CS1234'
		GROUP BY AL.custnb, call_dt_ymd, SI.zone_l1, SI.zone_l2,  UKM.keyword_type, UKM.u_keyword
	) RST
WHERE 1=1
GROUP BY  RST.custnb, RST.zone_l1, RST.zone_l2, RST.keyword_type, RST.u_keyword
ORDER BY  RST.custnb, RST.zone_l1, RST.zone_l2, RST.keyword_type, RST.u_keyword
;



/* 2-4 관심불만 업종  */
SELECT 
	RST.custnb
	, RST.biz_nm
	, RST.keyword_type
	, RST.u_keyword
	, RST.keyword_cnt
--	, sum(keyword_cnt)
	, sum(keyword_cnt) OVER(PARTITION BY (RST.custnb, RST.biz_nm, RST.keyword_type, RST.u_keyword)) AS keyword_cnt
FROM (
		SELECT 
		     custnb 
		   , stat_date 
		   , biz_nm		  
		   , keyword_type 
		   , u_keyword 
		   , keyword_cnt
		   , speaker 
		   , mon_nb 
		   , week_nb 
		FROM tb_ca_user_stat_keyword_biz_day
		WHERE 1=1
--		AND custnb = '8232574125'   -- 로그인 업체식별번호
		AND custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND biz_nm  = '30'
		/* 기간 검색 조건*/
		AND	stat_date BETWEEN '20201101' AND '20201112'	--검색 기간 조건
--		AND  	week_nb =  DATE_PART('week', TO_DATE('20201105'))	--2020-11-05일 선택 주 data 조회 시 
--		AND  week_nb BETWEEN DATE_PART('week', TO_DATE('20201006')) AND DATE_PART('week', TO_DATE('20201016'))  -- 10월6일~ 10월16일 2주 선택시 
--		AND  mon_nb BETWEEN 10 AND 10
		UNION ALL 
		SELECT 
			   al.custnb    AS cubtnb
			 , AL.call_dt_ymd	AS stat_date
			 , SI.custom_bizname	 AS zone_l1
		  	 , UKM.keyword_type	AS keyword_type
	 	     , COALESCE(UKM.u_keyword,'N/A') AS u_keyword  
	 	     , COUNT(UKM.u_keyword) AS keyword_cnt    
	 	    , 1			AS speaker
			, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
		FROM ( /* keyword filter */
				 SELECT 
						 UK.ucid 
					   , UK.custnb
					   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
					   		   ELSE UK.keyword  
					   		   END 
					   	 ) AS keyword
					   , UK.speaker 
					   , UK.count
					FROM (
						SELECT  A.ucid , A.keyword , A.speaker , A.count , B.custnb 
						FROM aicc_ta.tbta_aly_keyword A
						INNER JOIN public.tb_ca_api_log B 
						 ON A.ucid  = B.call_id 
						WHERE A.keyword NOT IN (
									SELECT u_keyword FROM tb_ca_user_stopword_mgt C 
									WHERE C.custnb = B.custnb)
					) UK
					LEFT OUTER JOIN (
									SELECT a.custnb , a.std_keyword , b.synonym_keyword
									FROM tb_ca_user_stdkeyword_mgt A
					  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
									   ON  A.custnb = b.custnb 
									   AND a.seq  = b.std_keyword_seq
									WHERE 1=1
									AND a.use_yn  = 'Y'
									AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN tb_ca_user_key_mgt  UKM
		     ON AL.custnb  = UKM.custnb 
		      AND trim(AK.keyword) = trim(UKM.u_keyword) 
		      AND ukm.use_yn  = 'Y'
		 INNER JOIN tb_ca_api_subinfo SI			--성별연령,지역,업종일 경우 JOIN
		   ON AL.call_id  = SI.call_id 
		 INNER JOIN public.tb_ca_biz_master  BM 
		   ON BM.custnb  = AL.custnb 
		WHERE 1=1
		AND AL.custnb = '1234598765'   -- 로그인 업체식별번호 :
		AND AL.call_dt_ymd = '20201113'		--당일 콜 대상 
		/* 유동조건절  */
		AND SI.custom_bizname  = '30'
		GROUP BY AL.custnb, call_dt_ymd, SI.custom_bizname, UKM.keyword_type, UKM.u_keyword
	) RST
WHERE 1=1
--GROUP BY  RST.custnb, RST.biz_nm, RST.keyword_type, RST.u_keyword
--ORDER BY  RST.custnb, RST.biz_nm, RST.keyword_type, RST.u_keyword
--;





