
SELECT *
FROM tb_ca_api_subinfo 
;
	
/* 일통계 - 업체-성별,연령대별-
 *  tb_ca_api_subinfo shrcnl 녹취_메타_subInfo 정보 저장
 * tb_ca_api_subinfo - 업종명 생성 
 * 
 *  */
CREATE OR REPLACE FUNCTION  public.fn_temp_updateCaApiSubInfo3
(	 
) RETURN VOID 
--LANGUAGE plpgsql
AS $$
DECLARE
	  curs1 refcursor;
      cur_cid public.tb_ca_api_log.call_id%TYPE;
BEGIN 
	OPEN curs1 
		FOR 
			SELECT DISTINCT (CA.call_id) 
			FROM tb_ca_api_log CA
			LEFT OUTER JOIN  tb_ca_api_subinfo CAS
			ON ca.call_id  = CAS.call_id 
			WHERE 1=1
			AND cas.custom_bizname IS NULL
			;
	LOOP 
		FETCH FROM curs1 INTO cur_cid;
		EXIT WHEN curs1%NOTFOUND;
	  
		UPDATE tb_ca_api_subinfo
		SET  custom_bizname =  (CASE  MOD(round(CAST(random() * 1000 AS numeric), 0), 5)
							  				WHEN 0 THEN '20'
							  				WHEN 1 THEN '30'
							  				WHEN 2 THEN '40'
							  				WHEN 3 THEN '50'
							  				ELSE '60' END )
		WHERE 1=1
		AND call_id  = cur_cid
		;
	END LOOP;
	CLOSE curs1;
END; $$;
--LANGUAGE plpgsql;
SELECT  fn_temp_updateCaApiSubInfo3();


/* 일통계 - 업체-성별,연령대별-
 *  tb_ca_api_subinfo shrcnl 녹취_메타_subInfo 정보 저장
 * tb_ca_api_subinfo(지역생성2)
 * 
 *  */
CREATE OR REPLACE FUNCTION  public.fn_temp_updateCaApiSubInfo2
(	 
) RETURN VOID 
--LANGUAGE plpgsql
AS $$
DECLARE
	  curs1 refcursor;
      cur_cid public.tb_ca_api_log.call_id%TYPE;
BEGIN 
	OPEN curs1 
		FOR 
			SELECT DISTINCT (CA.call_id) 
			FROM tb_ca_api_log CA
			LEFT OUTER JOIN  tb_ca_api_subinfo CAS
			ON ca.call_id  = CAS.call_id 
			WHERE 1=1
			AND cas.zone_l2 IS NULL
			;
	LOOP 
		FETCH FROM curs1 INTO cur_cid;
		EXIT WHEN curs1%NOTFOUND;
	  
		UPDATE tb_ca_api_subinfo
		SET  zone_l2 = (CASE zone_l1  
							WHEN 'AF3700' 
								THEN (CASE  MOD(round(CAST(random() * 1000 AS numeric), 0), 3)
							  				WHEN 0 THEN 'AS1234'
							  				WHEN 1 THEN 'AS9876'
							  				ELSE 'AS4567' END )
							WHEN 'BF3700' 
								THEN (CASE  MOD(round(CAST(random() * 1000 AS numeric), 0), 3)
							  				WHEN 0 THEN 'BS1234'
							  				WHEN 1 THEN 'BS9876'
							  				ELSE 'BS4567' END )
							WHEN 'CF3700' 
								THEN (CASE  MOD(round(CAST(random() * 1000 AS numeric), 0), 2)
							  				WHEN 0 THEN 'CS1234'
							  				ELSE 'CS9876' END )
							WHEN 'DF3700' 
								THEN (CASE  MOD(round(CAST(random() * 1000 AS numeric), 0), 2)
							  				WHEN 0 THEN 'DS1234'
							  				ELSE 'DS9876' END )
							WHEN 'EF3700' 
								THEN (CASE  MOD(round(CAST(random() * 1000 AS numeric), 0), 2)
							  				WHEN 0 THEN 'ES1234'
							  				ELSE 'ES9876' END )
							WHEN 'FF3700'  
								THEN (CASE  MOD(round(CAST(random() * 1000 AS numeric), 0), 3)
							  				WHEN 0 THEN 'FS1234'
							  				WHEN 1 THEN 'FS9876'
							  				ELSE 'FS4563' END )
							ELSE (CASE  MOD(round(CAST(random() * 1000 AS numeric), 0), 2)
							  				WHEN 0 THEN 'GS1234'
							  				ELSE 'GS9876' END )
							 END )
		WHERE 1=1
		AND call_id  = cur_cid
		;
	END LOOP;
	CLOSE curs1;
END; $$;
--LANGUAGE plpgsql;

SELECT fn_temp_updateCaApiSubInfo2();

/* 일통계 - 업체-성별,연령대별-
 *  tb_ca_api_subinfo shrcnl 녹취_메타_subInfo 정보 저장
 * tb_ca_api_subinfo(지역 생성 ) 
 * 
 *  */
CREATE OR REPLACE FUNCTION public.fn_temp_updatecaapisubinfo()
 RETURNS void
 LANGUAGE edbspl
 SECURITY DEFINER
AS $$
DECLARE
	  curs1 refcursor;
      cur_cid public.tb_ca_api_log.call_id%TYPE;
BEGIN 
	OPEN curs1 
		FOR 
			SELECT DISTINCT (CA.call_id)
			FROM tb_ca_api_log CA
			LEFT OUTER JOIN  tb_ca_api_subinfo CAS
			ON ca.call_id  = CAS.call_id 
			WHERE 1=1
			AND cas.zone_l1 IS NULL OR cas.zone_l2 IS NULL
			;
	LOOP 
		FETCH FROM curs1 INTO cur_cid;
		EXIT WHEN curs1%NOTFOUND;
	  
		UPDATE tb_ca_api_subinfo
		SET  zone_l1 = (CASE  MOD(round(CAST(random() * 1000 AS numeric), 0), 7)
				  				WHEN 0 THEN 'AF3700'
				  				WHEN 1 THEN 'BF3700'
				  				WHEN 2 THEN 'CF3700'
				  				WHEN 3 THEN 'DF3700'
				  				WHEN 4 THEN 'EF3700'
				  				WHEN 5 THEN 'FF3700'
				  				ELSE 'GF3700' END )
		WHERE 1=1
		AND call_id  = cur_cid
		;
	END LOOP;

	CLOSE curs1;
END; $$
;
SELECT fn_temp_updateCaApiSubInfo();

SELECT * FROM tb_ca_api_subinfo
;



/* 일통계 - 업체-성별,연령대별-  
 *  tb_ca_api_subinfo shrcnl 녹취_메타_subInfo 정보 저장
 * tb_ca_api_subinfo(성별,연령대 생성_)
 * 
 *  * */
CREATE OR REPLACE FUNCTION  public.fn_temp_insertCaApiSubInfo
(	 
) RETURN VOID 
--LANGUAGE plpgsql
AS $$
DECLARE
	  curs1 refcursor;
      cur_cid public.tb_ca_api_log.call_id%TYPE;
BEGIN 
	OPEN curs1 
		FOR SELECT 
			DISTINCT (CA.call_id)
		FROM tb_ca_api_log CA
		LEFT OUTER JOIN  tb_ca_api_subinfo CAS
		ON ca.call_id  = CAS.call_id 
		WHERE 1=1
		--AND cas.call_id IS NOT NULL
		AND cas.call_id IS NULL;
	
	LOOP 
		FETCH FROM curs1 INTO cur_cid;
		EXIT WHEN curs1%NOTFOUND;
	  
	    INSERT INTO tb_ca_api_subinfo
	    (	 call_id       
			, custom_gender       --성별(default : 'M',  ( ‘F’,’M’))
			, custom_age       --연령대
	    ) values(
	    	 cur_cid
			,  (CASE  MOD(round(CAST(random() * 1 AS numeric), 0), 2)
		  				WHEN 0 THEN 'M'
		  				ELSE 'F' END )
		  	,  (CASE  MOD(round(CAST(random() *1000 AS numeric), 0), 11)
		  				WHEN 0 THEN '0'
		  				WHEN 1 THEN '10'
		  				WHEN 2 THEN '20'
		  				WHEN 3 THEN '30'
		  				WHEN 4 THEN '40'
		  				WHEN 5 THEN '50'
		  				WHEN 6 THEN '60'
		  				WHEN 7 THEN '70'
		  				WHEN 8 THEN '80'
		  				WHEN 9 THEN '90'
		  				ELSE '100' END )
		);
	END LOOP;

	CLOSE curs1;
END; $$;
--LANGUAGE plpgsql;

SELECT MOD(round(CAST(random() * 1000 AS numeric), 0), 11) ;

SELECT round(CAST(random() * 100 AS numeric), 0) ;

SELECT fn_temp_insertCaApiSubInfo();


SELECT round(CAST(random() *1 AS numeric), 0);







CREATE OR REPLACE FUNCTION  public.fn_temp_updateCallDtCustnb2
(	 
) RETURN VOID 
--LANGUAGE plpgsql
AS $$
DECLARE
	  curs1 refcursor;
      cur_record public.tb_ca_api_log%ROWTYPE;
BEGIN 
	OPEN curs1 FOR SELECT * FROM public.tb_ca_api_log WHERE custnb = '8232574125';
    
  	/* CUURSOR  UPDATE */
	LOOP 
		FETCH FROM curs1 INTO cur_record;
		EXIT WHEN curs1%NOTFOUND;
		
		UPDATE public.tb_ca_api_log
		SET  
		  svcnb = (CASE  round(CAST(random() *3 AS numeric), 0)
		  				WHEN 0 THEN '15442424'
		  				WHEN 1 THEN '15442489'
		  				WHEN 2 THEN '15441124'
		  				ELSE '15442425' END )
		WHERE call_id = cur_record.call_id;
	END LOOP;
	CLOSE curs1;
END; $$;

SELECT fn_temp_updateCallDtCustnb2();

/*kjkljlk*/
CREATE OR REPLACE FUNCTION  public.fn_temp_updateCallDtCustnb
(	 
) RETURN VOID 
--LANGUAGE plpgsql
AS $$
DECLARE
	  curs1 refcursor;
      cur_record public.tb_ca_api_log%ROWTYPE;
BEGIN 
	OPEN curs1 FOR SELECT * FROM public.tb_ca_api_log;
    
  	/* CUURSOR  UPDATE */
	LOOP 
		FETCH FROM curs1 INTO cur_record;
		EXIT WHEN curs1%NOTFOUND;
		
		UPDATE public.tb_ca_api_log
		SET  
		  call_dt_ymd = to_char(timestamp '2020-10-01 00:01:00.000000' + random() * (timestamp '2020-11-18 23:59:59.999999' - timestamp '2020-10-01 00:01:00.000000'),'YYYYMMDD')
		, custnb  = (CASE WHEN round(CAST(random() *1 AS numeric), 0) = 0
			THEN '1234598765'
			ELSE '8232574125' END )
		WHERE call_id = cur_record.call_id;
	END LOOP;
	CLOSE curs1;
END; $$;

SELECT fn_temp_updateCallDtCustnb();


/* 일통계 - 업체-회선별 - 집계 data 배치 함수 (일별 생성) 
 * 추후에 이게 업체별로 돌는 함수를 따로 작성 해야 할듯 하다. 
 *  * */
CREATE OR REPLACE FUNCTION  public.fn_temp_insertKeywordSvncbDay
(	  in_startDt varchar(8)
	, in_maxCnt integer
) RETURN VOID 
--LANGUAGE plpgsql
AS $$
DECLARE
		 statDate  varchar(8);
		nCnt 	int;
BEGIN 
	statDate := in_startDt;
	nCnt := 0;
	WHILE (nCnt < in_maxCnt) LOOP
		-- 기존 배치 data 있으면 삭제 ..
		DELETE FROM tb_ca_keyword_svcnb_day WHERE stat_date = statDate;
	
		INSERT INTO tb_ca_keyword_svcnb_day (
			  custnb       --고객식별번호
			, stat_date       --배치일자
			, svcnb       --가입자번호(회선번호)
			, speaker       --화자구분:default: 3   ( Rx:1, Tx:2, Mono:3 )
			, keyword       --키워드
			, keyword_cnt       --키워드카운트
			, mon_nb
			, week_nb
			, reg_user       --등록자
		)
		SELECT 
			/* 업체-회선별-키워드  일통계 insert용 data */
			   al.custnb    AS subtnb		--업체식별번호
			 , AL.call_dt_ymd	AS stat_date      --배치일자
		--	   TO_CHAR(NOW(), 'YYYY-MM-DD') AS stat_date
		  	 , al.svcnb 	AS svcnb
		  	 , '1'			AS speaker
		--	 , '15882424'   AS svcnb 		--동적 --- 회선가입번호
		--     , AL.ib_ob		AS speaker       --화자구분 -->mono=3
			 , AK.keyword	AS keyword       --키워드 명
			 , count(AK.keyword)		AS keyword_cnt    --카운트(default '0')	
		--	 , sum(ak.count)  AS keyword_cnt
		--	, AL.custnb		AS custnb       --고객별 번호
		--	, AL.svcnb		AS svcnb		-- 가입자번호(회선번호)
			, DATE_PART('month', TO_DATE(AL.call_dt_ymd))	AS mon_nb     --통계월
			, DATE_PART('week',  TO_DATE(AL.call_dt_ymd))	AS weej_nb      --통계월
			, 'BAT'	 		AS reg_user       --등록자
		FROM ( SELECT 
					/* 유의어 치환 */
				     UK.ucid 
				   , UK.custnb
				   , (CASE WHEN UK.keyword = SK.synonym_keyword THEN SK.std_keyword 
				   		   ELSE UK.keyword  
				   		   END 
				   	 ) AS keyword
				   , UK.speaker 
				   , UK.count
				--count (*)
				FROM (
					/* 불용어 제거  */
					SELECT  A.ucid , A.keyword , A.speaker , A.count , al.custnb 
					FROM aicc_ta.tbta_aly_keyword A
					INNER JOIN public.tb_ca_api_log AL 
					 ON a.ucid  = al.call_id 
					WHERE a.keyword NOT IN (
								SELECT u_keyword FROM tb_ca_user_stopword_mgt B 
								WHERE B.custnb = al.custnb)
				) UK
				LEFT OUTER JOIN (
								SELECT a.custnb , a.std_keyword , b.synonym_keyword
								FROM tb_ca_user_stdkeyword_mgt A
				  				 INNER JOIN tb_ca_user_synoymkeyword_mgt B 
								   ON  A.custnb = b.custnb 
								   AND a.seq  = b.std_keyword_seq
								WHERE 1=1
								AND a.use_yn  = 'Y'
								AND b.use_yn = 'Y'
				) SK
				ON UK.custnb = SK.custnb
				AND UK.keyword = SK.synonym_keyword 
				WHERE 1=1
			) AK
		INNER JOIN public.tb_ca_api_log  AL 
		 ON AK.ucid =  AL.call_id 
		 INNER JOIN public.tb_ca_biz_master  BM 
		   ON BM.custnb  = AL.custnb 
		WHERE 1=1
		AND AL.call_dt_ymd = statDate	-- 통계 일자
		/* 유동조건절 */
		--AND AL.custnb = '1231231'   -- 로그인 업체식별번호
		--AND AL.svcnb  = '15882424'		-- 가입회선번호
		GROUP BY 
			call_dt_ymd
		  ,  al.custnb
		 /* 동적 groub by */
		 , al.svcnb		--동적
		-- , al.ib_ob 	--고민???
		 , ak.keyword	--필수 
		ORDER BY stat_date
			, subtnb 
			, svcnb
			, keyword
		;
		statDate := TO_CHAR(TO_DATE(statDate, 'YYYYMMDD') +1, 'YYYYMMDD');
		nCnt := nCnt+1;
	END LOOP;
END; $$;
--LANGUAGE plpgsql;


SELECT fn_temp_insertKeywordSvncbDay('20201001', 61);

SELECT DATE_PART('week', TO_DATE('20201113'));

--DROP FUNCTION fn_temp_statInsert;
CREATE OR REPLACE FUNCTION  public.fn_temp_statInsert2
(	  in_startDt   varchar(10)
	, in_bizCnt    varchar(20)
	, in_maxCnt    integer
) RETURN VOID 
--LANGUAGE plpgsql
AS $$
DECLARE
		 svcnbCnt	int;
  		 nCnt		int;
  		 statDate  varchar(10);
  		 svcNb		varchar(255);
  		 bizCnt    int;
  		 maxBizCnt  int;
BEGIN 
	
--	
	maxBizCnt := in_bizCnt;
	bizCnt := 0;

	WHILE ( bizCnt < maxBizCnt) LOOP
		svcnbCnt := 0;
		IF (bizCnt = 0) THEN 
			svcNb := '15882424';
		ELSE
			svcNb := '15442424';
		END IF;
		
		WHILE (svcnbCnt < 4) LOOP
			nCnt := 0;
			statDate := in_startDt;
		
			WHILE (nCnt < in_maxCnt) LOOP
				INSERT INTO tb_ca_keyword_svcnb_day 
				(	  custnb       --고객식별번호
					, stat_date     --배치일자
					, svcnb       --가입자번호(회선번호)
					, keyword       --키워드
					, keyword_cnt       --키워드카운트
					, reg_user       --등록자
				)VALUES ( in_custnb
						, statDate
						, svcNb
						, '개통'
						, round(CAST(random() *100 AS numeric), 0)
						, 'BAT'
					);
				INSERT INTO tb_ca_keyword_svcnb_day 
				( custnb , stat_date, svcnb, keyword, keyword_cnt, reg_user)
				VALUES(in_custnb, statDate, svcNb, '회원가입', round(CAST(random() *100 AS numeric), 0), 'BAT');
			
				INSERT INTO tb_ca_keyword_svcnb_day 
					( custnb , stat_date, svcnb, keyword, keyword_cnt, reg_user)
					VALUES(in_custnb, statDate, svcNb, '휴대폰', round(CAST(random() *100 AS numeric), 0), 'BAT');
				
				INSERT INTO tb_ca_keyword_svcnb_day 
					( custnb , stat_date, svcnb, keyword, keyword_cnt, reg_user)
					VALUES(in_custnb, statDate, svcNb, '무료', round(CAST(random() *100 AS numeric), 0), 'BAT');
				
				INSERT INTO tb_ca_keyword_svcnb_day 
					( custnb , stat_date, svcnb, keyword, keyword_cnt, reg_user)
					VALUES(in_custnb, statDate, svcNb, '불만', round(CAST(random() *100 AS numeric), 0), 'BAT');
	
				INSERT INTO tb_ca_keyword_svcnb_day 
					( custnb , stat_date, svcnb, keyword, keyword_cnt, reg_user)
					VALUES(in_custnb, statDate, svcNb, '고장', round(CAST(random() *100 AS numeric), 0), 'BAT');
	
				INSERT INTO tb_ca_keyword_svcnb_day 
					( custnb , stat_date, svcnb, keyword, keyword_cnt, reg_user)
					VALUES(in_custnb, statDate, svcNb, '액정', round(CAST(random() *100 AS numeric), 0), 'BAT');
	
				--하루씩 증가
				statDate := TO_CHAR(TO_DATE(statDate, 'YYYY-MM-DD') +1, 'YYYY-MM-DD');		
				nCnt := nCnt +1;
			END LOOP ;
			 
		   svcnbCnt := svcnbCnt +1;
		   IF (bizCnt = 0) THEN 
				CASE svcnbCnt WHEN 1 THEN 
					svcNb := '15882425';
			 	 WHEN 2 THEN
			 	 	svcNb := '15881124';
				 WHEN 3 THEN 
				 	svcNb := '15882489';
				 ELSE 	
				 END CASE;
			ELSE
				CASE svcnbCnt WHEN 1 THEN 
					svcNb := '15442489';
			 	 WHEN 2 THEN
			 	 	svcNb := '15441124';
				 WHEN 3 THEN 
				 	svcNb := '15442425';
				 ELSE 	
				 END CASE;
			END IF;
		  	
		END LOOP;
		bizCnt = bizCnt +1;
	END LOOP;

	
END; $$;
--LANGUAGE plpgsql;
	
SELECT fn_temp_statInsert('20201001', 61)

CREATE OR REPLACE FUNCTION  public.fn_temp_caApiLogInsert
(	  in_curtnb   varchar
) RETURN VOID 
--LANGUAGE plpgsql
AS $$
DECLARE
	  curs1 refcursor;
      sUcid aicc_ta.tbta_aly_keyword.ucid%TYPE;
BEGIN 
	
	OPEN curs1 FOR SELECT DISTINCT(ucid) FROM aicc_ta.tbta_aly_keyword;
    
  	/* CUURSOR  INSERT */
	LOOP 
		FETCH FROM curs1 INTO sUcid;
		EXIT WHEN curs1%NOTFOUND;
	
		/* INSERT CA_API_LOG */
		INSERT INTO public.tb_ca_api_log (
			  call_id       --녹취 콜 ID - 업체코드_날짜 조합   ( 타 업체 코드와 중복 불가)
			, call_dt_ymd       --녹취 생성 일자 - yyyyMMDD
			, call_dt_hms       --녹취 생성시간 - HHmmsss
			, csr_id       --상담원 ID - Default = Y
			, csr_nm       --상담사 명
			, custom_id       --고객 ID
			, ib_ob       --콜타입 정보 - default: 3   ( Rx:1, Tx:2, Mono:3 )
			, duration_time       --녹취 시간(sec)
			, voc_file_path       --음원 경로 - /NAS/SRC/${청약ID}/yyyyMMDD/
			, voc_file_nm       --음원 파일명 - 암호화된_파일명.mp3
			, enc_file_size       --암호화 파일 크기 - 원본 파일 체크용 byte
			, dec_file_size       --복호화 파일 크기 - 복호화시 체크용 byte
			, enckey       -- 암호화 키 
			, enc_alg       --암호 알고리즘 - default : 'SEED 128 CBC'
			, custnb_type       --고객식별번호 타입( 'A' : 사업자번호 'B' : 법인번호  'C' : 가상주민번호 'D' : 전화번호 )
			, custnb       --고객식별번호
			, dec_flag       --복호와여부
			, svcnb       --가입자번호(회선번호)
		)values(
			  sUcid
			, '2020' || '11' || TRIM(REPLACE(TO_CHAR(round(CAST(random() * 5 AS numeric), 0), '00'), '00', '01'))
			, '111111'
			, '101'
			, '홍길동'
			, '1004'
			, '3'
			, 100
			, '/root/Gnew/file/encvoc_file_path'
			, sUcid || '.enc'
			, '12345'
			, '12345'
			, 'PvPq9ZVlHaBrcK7RPcdj5g=='
			, 'seed128'
			, 'A'		--사업자번호
			, in_curtnb
			, 0
			, (CASE round(CAST(random() * 4 AS numeric), 0)
					WHEN 1 THEN '15882424'
					WHEN 2 THEN	'15882489'
					WHEN 3 THEN	'15881124'
					WHEN 4 THEN '15882425'	
					ELSE '15882424'
					END )
		);
	END LOOP;
	CLOSE curs1;
END; $$;


INSERT INTO tb_biz_master(
	  custnb 
	, custnb_type 
	, svcnb 
	, cmpnm   
	, mngr_email_adres 
	, service_status
)VALUES(
	'1234598765', 'A', '15882424,15882489,15881124,15882425','지뉴소프트', 'test@test.com','S'
);

INSERT INTO tb_biz_master(
	  custnb 
	, custnb_type 
	, svcnb 
	, cmpnm   
	, mngr_email_adres 
	, service_status
)VALUES(
	'8232574125', 'A', '15442424,15442489,15441124,15442425','올드소프트', 'test@old.com','S'
);


 

SELECT fn_temp_caApiLogInsert('1234598765');

SELECT * FROM tb_ca_api_log;

SELECT * FROM tb_ca_keyword_svcnb_day;

SELECT (CASE round(CAST(random() * 4 AS numeric), 0)
			WHEN 1 THEN '15882424'
			WHEN 1 THEN	'15882489'
			WHEN 1 THEN	'15881124'
			WHEN 4 THEN '15882425'	
			ELSE '15882424'
			END ) AS 번호 ;

SELECT DISTINCT(svcnb) FROM tb_ca_keyword_svcnb_day;


SELECT  '2020' || '-11-' || TRIM(REPLACE(TO_CHAR(round(CAST(random() * 5 AS numeric), 0), '00'), '00', '01'));
SELECT REPLACE(TO_CHAR(round(CAST(random() * 5 AS numeric), 0), '00'), '00', '01') ;


SELECT round(CAST(random() * 5 AS numeric), 0) ;


SELECT TO_CHAR(TO_DATE('2020-11-01', 'YYYY-MM-DD') +1, 'YYYY-MM-DD'); 
SELECT TO_DATE('2020-11-01', 'YYYY-MM-DD')-1;

SELECT fn_temp_statInsert('2020-11-01', '1234598765', 5);
	
SELECT * FROM tb_ca_keyword_svcnb_day
;

SELECT funTest();
SELECT round(CAST(random() *100 AS numeric), 0);

SELECT min(random), max(random) FROM (
    SELECT trunc(random() * 11) AS random FROM generate_series(1,1000000)
) AS test;


SELECT 1 AS resutl;
RAISE NOTICE  'startDateTime[%]endDateTime[%]', in_startdt,  in_enddt;

EXCEPTION 
	WHEN SQLSTATE '50001' THEN
		RAISE NOTICE  'The range cannot exceed 60 minutes.';
	WHEN SQLSTATE '50002' THEN
		RAISE NOTICE  'In put Hour Error 0 ~ 23';
	WHEN SQLSTATE '50003' THEN
		RAISE NOTICE  'In put minutes Error 0 ~ 59';
	

CREATE OR REPLACE FUNCTION public.func_inst_stt_recog()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$ 
    begin 
		insert into tb_stt_recog_history (call_id, trans, recog_rate, input_len, right_len, wrong_len, insert_len, delete_len, replace_len, check_start_dt,check_end_dt, channel, check_user_id )
		values
		(new.call_id, new.trans, new.recog_rate, new.input_len, new.right_len, new.wrong_len, new.insert_len, new.delete_len, new.replace_len, new.check_start_dt,new.check_end_dt, new.channel, new.check_user_id);
	return null;
	end;
  $function$
;


SELECT TO_CHAR(TO_DATE('2020-11-18', 'YYYY-MM-DD')-1, 'YYYY-MM-DD');