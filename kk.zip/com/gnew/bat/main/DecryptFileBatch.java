package com.gnew.bat.main;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gnew.bat.conf.Conf;
import com.gnew.bat.crypto.kisa.file.DecryptFile;
import com.gnew.bat.dbms.EncDecFileDbProc;
import com.gnew.bat.log.Loger;

public class DecryptFileBatch {

	/**
	 * @param args
	 */

	String strExit;
	boolean endflag = false;
	
	private static long   waitMilliSec = 0;
	private static final String DEFAULT_CONF_FILE = "./conf/conf.properties";
	private static final int ENC = 0;
	private static final int DEC_ING = 1;
	private static final int DEC_COMPLATE = 2;
	private static final int DEC_FAILED = 3;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String confFile =  null;
		
		try {
//			System.out.println("<<< ENC/DEC BATCH START >>>>>>>>>>>>\n");
			
			// 1.>>>>> start load config 
			if (args.length < 2) {
				confFile = DEFAULT_CONF_FILE;
			}else {
				confFile = args[1];
			}
			Conf.init(confFile);
			if (Conf.confValidCheck() == false) {
				System.exit(0);
			}
			// 1. >>>> End load Config 
			
			// 2. >>>> logger init
			Loger.init();
			
			Loger.info("<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>");
			Loger.info("<<<<<<<<<< (ENC)DECRYPT BATCH START >>>>>>>>>>>>");
			Loger.info("<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>");
			
//			if (Integer.parseInt(Conf.rtyPeriodMin) >= 0) {
//				waitMilliSec = (long)Integer.parseInt(Conf.rtyPeriodMin) * 60 * 1000;
//			}
			
			DecryptFile decryptFile = new DecryptFile();
			
			// 2.>>>>> start db Select
			Map<String,Object> mDbInfo = new HashMap<String, Object>();
			mDbInfo.put("jdbcUrl", Conf.url);
			mDbInfo.put("dbId", Conf.dbId);
			mDbInfo.put("dbPwd", Conf.dbPwd);
			
			// db처리 instance 생성 : main 함수 에서 처리 (멀티 프로세스만 가능) 쓰레드 처리시 내부로..			
			EncDecFileDbProc encDecFileDbProc = new EncDecFileDbProc();
			encDecFileDbProc.dbConn(mDbInfo);
			
			/*
			 * 1. get 암호화 대상 : 암호화 대상 조회
			 */
			//search fillter....
			Map<String, Object> params = new HashMap<String, Object>();
			// 날짜 시간 검색 조건은 없는지...
			params.put("callId", "10001");
//			params.put("callId", "dsakfjakldfj");
//			params.put("callId", "dsakfjakldfj");
//			params.put("callId", "dsakfjakldfj");
			
			List<Map<String, Object>> rstList = encDecFileDbProc.getToDecryptFile(params);
			
			updateDecFlag(encDecFileDbProc, rstList, DEC_ING);		// update flag DEC_ING
			
			// decrypt target loop 
			for (Map<String, Object> tMap : rstList ) {
				String fileKey 		= (String)tMap.get("encKey");
				String encFilePath 	= (String)tMap.get("vocFilePath");
				String encFileNm 	= (String)tMap.get("vocFileNm");
//				String encFileSize 	= (String)tMap.get("encFileSize");
				int iDecFileSize 	= Integer.parseInt((String)tMap.get("decFileSize"));
				String decFilePath 	= Conf.decFilePath;
				String decFileNm 	= encFileNm.replace(".enc","");
				
				if (decryptFile.funFileDecrypt(fileKey, encFilePath, encFileNm, decFilePath, decFileNm, iDecFileSize) == true) {
					updateDecFlag(encDecFileDbProc, tMap, DEC_COMPLATE);		// update flag DEC_COMPLATE 
					insertSttMaster(encDecFileDbProc, tMap);					// insert tb_stt_master
					
				}else {
					// DEC_FAILED				 
					updateDecFlag(encDecFileDbProc, tMap, DEC_FAILED);		// update flag DEC_FAILED
				}
			}
			
			encDecFileDbProc.dbConnClose(EncDecFileDbProc.conn);
			// 2.>>>>> End db Select
				
			// test용 암호화/복호화 수행 (디렉터리)( 
//			String fileKey1 = "VfVrb2ngvJy6vZdCxSeefA==";
//			DecryptFile decryptFile = new DecryptFile();
//			decryptFile.funFileEnDecrypt(fileKey1, Conf.orgFilePath, Conf.decFilePath);
			// x. >>>>>>> End 암/복호화 처리
			
		} catch (Exception ex) {
			// 각 프로세스 별로 exception code 정리 필요 ..
			//ex.printStackTrace();
			
			if (Loger.isErrorable()) {
				//ERR_TYPE별 처리
				Loger.error("main - ", ex);
			}else {
				// conf.path err.. log file err
				System.out.println("[Exception]Config File not Founded~~~\n");
				System.out.println("[Exception]Config File path : "+ confFile + "\n");
			}
		} 
		
		System.out.println("<<<<<<<<<< ENC/DEC BATCH END >>>>>>>>>>>>\n");
		Loger.info("<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>");
		Loger.info("<<<<<<<<<<< (ENC)DECRYPT BATCH END >>>>>>>>>>>>>");
		Loger.info("<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>");
	}

	private static void updateDecFlag (EncDecFileDbProc encDecFileDbProc, List<Map<String, Object>> paramList, int decFlag) {
		Map<String, Object> updateParams = new HashMap<String, Object>();
		boolean rVal = false;
		
		// decryp file target dec_flag(0:enc, 1:decypting.. 2:decrypted ) update (1:decrypting..)
		for ( Map<String, Object> tMap : paramList ) {
			updateParams.put("seq",  (int)tMap.get("seq"));
			updateParams.put("callId", (String)tMap.get("callId"));
			updateParams.put("decFlag", decFlag);		// (1:decrypting..)
			
			rVal = encDecFileDbProc.updateDecFlag(updateParams);
			updateParams.clear();
		} 
	  
	}	
	
	private static boolean updateDecFlag (EncDecFileDbProc encDecFileDbProc, Map<String, Object> param, int decFlag) {
		Map<String, Object> updateParams = new HashMap<String, Object>();
		boolean rVal = false;
		
		// decryp file target dec_flag(0:enc, 1:decypting.. 2:decrypted ) update (1:decrypting..)
		updateParams.put("seq",  (int)param.get("seq"));
		updateParams.put("callId", (String)param.get("callId"));
		updateParams.put("decFlag", decFlag);		
		
		rVal = encDecFileDbProc.updateDecFlag(updateParams);
		return rVal;
	}	
	
	private static boolean insertSttMaster (EncDecFileDbProc encDecFileDbProc, Map<String, Object> param) {
		Map<String, Object> insertParams = new HashMap<String, Object>();
		boolean rVal = false;

		insertParams.putAll(param);
		// stt_master only param ...
		insertParams.put("systemId",	"1231321");		// 시스템 id ????? not null ...kj
		
		insertParams.put("crsNm", 		"");		// 고객명
		insertParams.put("sttStartDt",	"");
		insertParams.put("sttEndDt",	"");
		insertParams.put("sttStatus",	"");
		insertParams.put("systemId",	"");		// 시스템 id ????? not null ...kj 
		insertParams.put("systemNm",	"");		// 시스템 Nm
		insertParams.put("recogCheckYn","");
		insertParams.put("sttType",	 0);
		insertParams.put("instDtYmd",	"");
		insertParams.put("intDtHms",	"");
		insertParams.put("sttGetFlag",	0);
	
		rVal = encDecFileDbProc.insertSttMaster(insertParams);
		return rVal; 
	}
	
	
}
