package com.gnew.bat.dbms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.gnew.bat.log.Loger;

public class EncDecFileDbProc {
	
	public static Connection conn = null;
	public static PreparedStatement	pstmt = null;
	//CallableStatement	caDBO = null;	

	// 접속 conn
	public boolean dbConn( String jdbcUrl, String dbId, String dbPwd){
		boolean rVal = false;
		try{
			
//			String url = "jdbc:postgresql://210.179.173.99:5444/lightTA";
//			Properties props = new Properties();
//			props.setProperty("user","lightta");
//			props.setProperty("password","new1234!");
////			props.setProperty("ssl","true");
//			conn = DriverManager.getConnection(url, props);
//			
//			String url = "jdbc:postgresql://localhost/test?user=fred&password=secret&ssl=true";
//			Connection conn = DriverManager.getConnection(url);
			
//			String url = "jdbc:postgresql://210.179.173.99:5444/lightTA?user=lightta&password=new1234!&ssl=false";
//			conn =DriverManager.getConnection(url);
//			
			conn =DriverManager.getConnection(jdbcUrl,dbId,dbPwd);
			
			
		    conn.setAutoCommit(true);
			Loger.info(">>>> Connected DB!");
			rVal = true;
			
		}catch (SQLException e){
			Loger.error("[DB_Failed]Connection Failed!", e);
			rVal = false;
		}
		
		return rVal;
	}
	
	public boolean dbConn( Map<String, Object> dbInfo) {
		boolean rVal = false;
		
		try{
			String jdbcUrl = (String)dbInfo.get("jdbcUrl");
		    
			Properties props = new Properties();
			props.setProperty("user", (String)dbInfo.get("dbId"));
			props.setProperty("password",(String)dbInfo.get("dbPwd"));
//			props.setProperty("ssl","true");
			conn =DriverManager.getConnection(jdbcUrl, props);
		    conn.setAutoCommit(true);
		    Loger.info(">>>> Connected DB!");
		    rVal = true;
		    
		}catch (SQLException e){
			Loger.error("[DB_Failed]Connection Failed!", e);
		}
		return rVal; 
	}
	
	
	// 암호화 대상 조회 (return map<List> : 
	public List<Map<String, Object>> getToDecryptFile( Map<String, Object> params ) throws Exception{
		
		ResultSet 	rs = null;
		List<Map<String, Object>> rstList = new ArrayList<Map<String, Object>>();
		
		try {
				/* 여기서 *로 가져 오던지 아니면 정하자..*/
				String sql = "SELECT call_id "			//callID
									+ ", seq "			// seq
									+ ", call_dt_ymd "	// 녹취생성 일자
									+ ", call_dt_hms "	// 녹취생성 시간
									+ ", csr_id "		// 상담사id
									+ ", csr_nm	"		// 상담사명
									+ ", custom_id "	// 고객 id
									+ ", ib_ob "		// 콜타입 정보 
									+ ", duration_time"	// 녹취 시간
									+ ", voc_file_path " //음원경로
									+ ", voc_file_nm "  //음원 파일명
									+ ", enc_file_size"	//암호화 파일 크기 
									+ ", dec_file_size"	//복호화 파일 크기
									+ ", enckey"		//파일 암화화 키 
									+ ", subscrpt_id "	//청약id
									+ ", goods_id"		//상품ID
									+ ", dec_flag"		//복호화 상태
									+ ", customer_number"	//가입자번호
						+ "  FROM tb_ca_api_log "
						+ "  WHERE 1=1 "
//						+ "  AND call_dt_ymd = ?"
//						+ "  AND call_dt_hms = ?"
						+ "  AND dec_flag = 0"			
						;
				
				pstmt = conn.prepareStatement(sql);
				
				// search fillter  
//				pstmt.setString(1, (String) params.get("callId"));		// call_id
//				pstmt.setString(2, (String) params.get("callId"));		// call_id
//				pstmt.setString(3, (String) params.get("callId"));		// call_id
//				pstmt.setString(3, (String) params.get("callId"));		// call_id
				
				
				rs = pstmt.executeQuery();
				// resutSet 처리 
				int i = 0;
				while (rs.next ()){
					Map<String, Object> mRst = new HashMap<String, Object>();

					mRst.put("callId", 		rs.getString("call_id"));		// callID
					mRst.put("seq", 		rs.getInt("seq"));				// seq
					mRst.put("callDtYmd", 	rs.getString("call_dt_ymd"));		// 녹취 생성 일자
					mRst.put("callDtHms", 	rs.getString("call_dt_hms"));		// 녹취 생성 시간
					mRst.put("csrId", 		rs.getString("csr_id"));			// 상담원ID
					mRst.put("crsNm", 		rs.getString("csr_nm"));			// 상담원 명
					mRst.put("customId", 	rs.getString("custom_id"));		// 고객ID
					mRst.put("ibOb", 		rs.getString("ib_ob"));			// 콜타입정보 (Rx:1, Tx:2, Mono:3)
					mRst.put("durationTime",rs.getInt("duration_time"));	// 녹취시간 (sec)
					mRst.put("vocFilePath", rs.getString("voc_file_path"));	// enc file Path 
					mRst.put("vocFileNm", 	rs.getString("voc_file_nm"));	// enc file name
					mRst.put("encFileSize", rs.getString("enc_file_size"));	// enc file siz
					mRst.put("decFileSize", rs.getString("dec_file_size"));	// dec file size
					mRst.put("encKey", rs.getString("enckey"));				// file enc key
					mRst.put("subscrptId",  rs.getString("subscrpt_id"));	// 청약ID
					mRst.put("goodsId", 	rs.getString("goods_id"));		// 상품ID
					mRst.put("decFlag", 	rs.getInt("dec_flag"));		// 복호화 상태 
					mRst.put("customerNumber", 	rs.getString("customer_number"));		// 가입자번호
					
					Loger.info("[Decryt target select restut NO." + i + "]\n"  
							+ "\tcallId : "    + rs.getString("call_id") + "\n"
							+ "\tseq : "       + rs.getInt("seq") + "\n"
							+ "\tcallDtYmd : " + rs.getString("call_dt_ymd") + "\n"			// 녹취 생성 일자"									
							+ "\tcallDtHms : " + rs.getString("call_dt_hms") + "\n"			// 녹취 생성 시간
							+ "\tcsrId : " + rs.getString("csr_id") + "\n"						// 상담원ID
							+ "\tcrsNm : " + rs.getString("csr_nm") + "\n"						// 상담원 명
							+ "\tcustomId : " + rs.getString("custom_id") + "\n"				// 고객ID
							+ "\tibOb : " + rs.getString("ib_ob") + "\n"						// 콜타입정보 (Rx:1, Tx:2, Mono:3)
							+ "\tdurationTime : " + rs.getInt("duration_time") + "\n"		// 녹취시간 
							+ "\tvocFilePath : " + rs.getString("voc_file_path") + "\n"		// enc file Path 
							+ "\tvocFileNm : " + rs.getString("voc_file_nm") + "\n"			// enc file name
							+ "\tencFileSize : " + rs.getString("enc_file_size") + "\n"		// enc file siz
							+ "\tdecFileSize : " + rs.getString("dec_file_size") + "\n"		// dec file size
							+ "\tencKey : " + rs.getString("enckey") + "\n"		// enc file key
							+ "\tsubscrptId : " + rs.getString("subscrpt_id") + "\n"		// 청약ID
							+ "\tgoodsId : " + rs.getString("goods_id") + "\n"				// 상품ID
							+ "\tdecFlag : " + rs.getInt("dec_flag") + "\n" 				// 복호화 상태 
							+ "\tcustomerNumber : " + rs.getString("customer_number") + "\n");				// 가입자번호
					rstList.add(mRst);
				}
		}catch(SQLException e){
			Loger.error("getToDecryptFile - Select Query Error!", e);
		}finally{
			if(rs != null) try{rs.close();}catch(SQLException e){e.printStackTrace();}
		}

		return rstList; 
	}
	
	// 암호화 처리 상태 갱신
	public boolean updateDecFlag( Map<String, Object> params ){
		// conn 연결시  commit option values check
		try{
			// 1. UPDATAE tb_ca_api_log decrypt status  
			String sql = "UPDATE tb_ca_api_log "
					+ "  SET dec_flag = ? "
					+ "  WHERE 1=1 "
					+ "  AND call_id = ?"
					+ "  AND seq = ? "
					;
			//sql += " values(?,?,?,?)";       
		  	pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, (int)params.get("decFlag"));
			pstmt.setString(2, (String)params.get("callId"));
	        pstmt.setInt(3, (int)params.get("seq"));
	        
	        pstmt.executeUpdate();
	        
	        Loger.info("[updateDecFlag]update decflag success(callId: " + params.get("callId")+ ")");
			return true;
			
	    }catch(SQLException e){
//			e.printStackTrace();
//			System.out.println("DB Insert failed");
	    	Loger.error("[updateDecFlag] update decflag failed (callID: "+ params.get("callId") + ")", e);
			return false;
		}
		
	}
	
	// Insert Stt Master
	public boolean insertSttMaster( Map<String, Object> params ){
		// conn 연결시  commit option values check
		try{
			// 1. INSERT STT_MASTER - 개발기 접속 되면 stt_master 컬럼명 조회 해서 tb_ca_api_log 테이블과 mapping 해야 할듯...  
			String sql = "INSERT INTO "
	        		+ " tb_stt_master("
					+ "    call_id "
	        		+ ",   csr_id "
	        		+ ",   csr_nm "
	        		+ ",   custom_id "
	        		+ ",   custom_nm "
	        		+ ",   stt_start_dt "
	        		+ ",   stt_end_dt "
	        		+ ",   duration_time "
	        		+ ",   stt_status "
	        		+ ",   system_id "
	        		+ ",   system_nm "
	        		+ ",   ib_ob "
	        		+ ",   voc_file_nm "
	        		+ ",   voc_file_path "
	        		+ ",   recog_check_yn "
	        		+ ",   call_dt_ymd "
	        		+ ",   call_dt_hms "
	        		+ ",   stt_type "
	        		+ ",   inst_dt_ymd "
	        		+ ",   inst_dt_hms "
	        		+ ",   stt_get_flag "
	        		+ ") values(?,?,?,?,?"
	        		+ ",?,?,?,?,?"
	        		+ ",?,?,?,?,?"
	        		+ ",?,?,?,?,?"
	        		+ ",?)";
			       
		  	pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, (String)params.get("callId"));
			pstmt.setString(2, (String)params.get("csrId"));
	        pstmt.setString(3, (String)params.get("csrNm"));
	        pstmt.setString(4, (String)params.get("customId"));
	        pstmt.setString(5, (String)params.get("customNm"));
	        pstmt.setString(6, (String)params.get("sttStartDt"));
	        pstmt.setString(7, (String)params.get("sttEndDt"));
	        pstmt.setInt(8, (int)params.get("durationTime"));
	        pstmt.setString(9, (String)params.get("sttStatus"));
	        pstmt.setString(10, (String)params.get("systemId"));
	        pstmt.setString(11, (String)params.get("systemNm"));
	        
	        pstmt.setString(12, (String)params.get("ibOb"));
	        pstmt.setString(13, (String)params.get("vocFileNm"));
	        pstmt.setString(14, (String)params.get("vocFilePath"));
	        pstmt.setString(15, (String)params.get("recogCheckYn"));
	        pstmt.setString(16, (String)params.get("callDtYmd"));
	        pstmt.setString(17, (String)params.get("callDtHms"));
	        pstmt.setInt(18, (int)params.get("sttType"));
	        pstmt.setString(19, (String)params.get("instDtYmd"));
	        pstmt.setString(20, (String)params.get("instDtHms"));
	        pstmt.setInt(21, (int)params.get("sttGetFlag"));
	        
	        pstmt.executeUpdate();		        
	        
	    	Loger.info("[insertSttMaster]insert success (callId: " + params.get("callId")+ ")");
			return true;

		}catch(SQLException e){
			Loger.error("[insertSttMaster] Insert failed (callID: "+ params.get("callId") + ")", e);
//			e.printStackTrace();
//			System.out.println("DB Insert failed");
			return false;
		}
	
	}
	
	// 접속 종료 
	public void dbConnClose( Connection con ){
		try {
			conn.close();
		
		}catch(SQLException e){
			e.printStackTrace();
			System.out.println("DB Conn Close failed");
			Loger.error("DB Conn Close failed!!!!", e);
		}
		
	}
	
}
