package com.gnew.bat.log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import com.gnew.bat.conf.Conf;
import com.gnew.bat.util.Util;

public class Loger{
	
	public static final String  NOLOG = "0";
	public static final String ERR_MODE = "1";
	public static final String INFO_MODE = "2";
	public static final String DEBUG_MODE = "3";
	
	private static boolean isError = false;
	private static boolean isInformation = false;
	private static boolean isDebug = false;
	private static String currentDate = "";
	private static PrintWriter log_print = null;

	//  private static SDBDomainQuery domainQuery = null;
	public static void init()throws IOException{
		try{
			switch(Conf.logLevel){
			  case NOLOG:  	// none
				  isError = false;
				  isInformation = false;
				  isDebug = false;
				  break;
			  case ERR_MODE: 	// err only
				  isError = true;
				  isInformation = false;
				  isDebug = false;
				  break;
			  case INFO_MODE: // err + info 
				  isError = true;
				  isInformation = true;
				  isDebug = false;
				  break;
			  case DEBUG_MODE :  //err + info + debug
				  isError = true;
				  isInformation = true;
				  isDebug = true;
			      break;
			  default :// err only
				  isError = true;
				  isInformation = false;
				  isDebug = false;
				  break;
			}
	  
			rollingLogFile();
			
			if (log_print == null) {
			  System.out.println("[log_print]Log File : " + Conf.logFile);	
			  log_print = new PrintWriter(new FileOutputStream(Conf.logFile, true), true);
			}
			
			Conf.printProperty();
			
		}catch(Exception e){
			System.out.println("Failed to create Log File : " + Conf.logFile);
			e.printStackTrace();
		}
	}

	public static void rollingLogFile(){
		try {
			currentDate = Util.getCurrentDate();
			
			File f = new File(Conf.logFile);
			long lastModified = f.lastModified();
			if (lastModified == 0L) {
				return;
			}
			String lastLogDate = Util.getDateFormat(lastModified);
		
			if (!lastLogDate.equals(currentDate)) {
				String newFileName = Conf.logFile + "." + lastLogDate;
			File renameFile = new File(newFileName);
			f.renameTo(renameFile);
			System.out.println("log file renameed to " + newFileName);
			}
		}catch(Exception e){
			System.out.println(e);
		}
	}

	public static boolean isErrorable() {
		return isError;
	}

	public static boolean isDebugable(){
		return isDebug;
	}

	public static boolean isInfoable(){
		return isInformation;
	}

	public static void logPrint(String msg){
		log(msg, null);
	}

	public static void error(String msg){
		if (!isError) {
			return;
		}
		error(msg, null);
	}

	public static void error(String msg, Throwable e) {
		if (!isError) {
			return;
		}
		String message = "  ERROR  " + msg;
		log(message, e);
	}

	public static void info(String msg){
		if (!isInformation) {
			return;
		}
		info(msg, null);
	}
	
	public static void info(String msg, Throwable e) {
		if (!isInformation) {
		return;
		}
		String message = "  INFO  " + msg;
		
		log(message, e);
	}

	public static void debug(String msg) {
		if (!isDebug) {
			return;
		}
		debug(msg, null);
	}

	public static void debug(String msg, Throwable e) {
		if (!isDebug) {
		  return;
		}
		String message = "  DEBUG  " + msg;
		
		log(message, e);
	}

	private static synchronized boolean log(String msg, Throwable t) {
		try{
			if (t != null) {
				msg = msg + throwableToString(t);
			}
		
			log_print.println(Util.getCurrentDateHMS() + msg);
			return true;
		}catch(Exception ex){
			System.out.println("Failed to write log");
		}
		return false;
	}

	private static String throwableToString(Throwable t) {
		StringWriter sw = new StringWriter();
		PrintWriter w = new PrintWriter(sw);
		
		if (t != null) {
			t.printStackTrace(w);
		}
		sw.flush();
		w.flush();
		return sw.toString();
	}

	public String getStatus() {
		StringBuffer sb = new StringBuffer();
		sb.append("\nLog File Path: " + Conf.logFile);
		sb.append("\nLog Level: ");
		
		switch(Conf.logLevel){
				case NOLOG:		// none
					sb.append("NONE");
					break;
				case ERR_MODE: 	// err only
					sb.append("ERR");
						break;
				case INFO_MODE: // err + info 
					sb.append("INFO");
						break;
				case DEBUG_MODE :  //err + info + debug
					sb.append("DEBUG");
					break;
				default :// err only
					sb.append("ERR");
					break;
		}
		
		sb.append("\n");
		
		return sb.toString();
	}

//	public static void logToDB(String msg) {
//		try{
//			if (domainQuery == null) {
//				domainQuery = new SDBDomainQuery();
//				domainQuery.connect();
//			}
//		
//			domainQuery.logToDB(msg);
//		}catch (Exception e){
//			e.printStackTrace();
//		}
//	}
}