package com.gnew.bat.conf;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import com.gnew.bat.crypto.kisa.file.DecryptFile;
import com.gnew.bat.log.Loger;

// singlton(static) config class
public class Conf {
	
	//key-values define
	public static String orgFilePath = "";
	public static String encFilePath= "";
	public static String decFilePath= "";
	
	public static String encExt= "";
	public static String[] encExtArr;
	
	public static String driver= "";
	public static String url= "";
	public static String dbId= "";
	public static String dbPwd= "";
	public static String dbPwdEnc= "";
	
	public static String logLevel= "";
	public static String logFile= "";
	public static String rtyPeriodMin= "";
	
	public static Properties  prop = null;

	private static Conf conf = new Conf();
	
	private Conf() {};
	
	//init 
	public static Conf init(String sFile) throws Exception {
		File profile = null;
		FileInputStream  fis = null;

		profile = new File(sFile);
		prop = new Properties();
		
		try{
			//파일없는경우 빈파일 생성
			if (!profile.exists()) profile.createNewFile();
			fis = new FileInputStream(profile);
			
			prop.load(fis);
			
			getProperties();
			printProperty();
		}catch(Exception e){
			e.printStackTrace();
			throw new Exception();
		}
		return conf;
	}
	
	//get Property
	private static void getProperties() {
		driver = prop.getProperty("driver"); 
		dbId = prop.getProperty("dbId"); 
		url = prop.getProperty("url");
		orgFilePath = prop.getProperty("orgFilePath");
		encFilePath = prop.getProperty("encFilePath");		
		decFilePath = prop.getProperty("decFilePath");		
		encExt = prop.getProperty("encExt");
		encExtArr = encExt.split(",");
		logLevel = prop.getProperty("logLevel");
		logFile = prop.getProperty("logFile");
		rtyPeriodMin = prop.getProperty("rtyPeriodMin");
		
		DecryptFile decryptFile = new DecryptFile();
		
		dbPwdEnc = prop.getProperty("dbPwd");
		String decData = decryptFile.decryptBase64ToText(dbPwdEnc);
		dbPwd = decData;
	}
	
	//set property
	
	//store property
	
	
	//string token print 
	public static void printProperty() {
		Loger.info("<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>");
		Loger.info("<<<<<<<<<< DECRYPT BATCH CONFIG VALUE >>>>>>>>>>>>");
		Loger.info("<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>");
		Loger.info("[dbId]\t : " + dbId);
		Loger.info("[dbPwd]\t : " + dbPwdEnc);
		Loger.info("[url]\t : " + url);
		Loger.info("[orgFilePath] : " + orgFilePath);
		Loger.info("[encFilePath] : " + encFilePath);
		Loger.info("[decFilePath] : " + decFilePath);
		Loger.info("[encExt]\t : " + encExt);
		Loger.info("[logLevel]\t : " + logLevel);		
		Loger.info("[logFile] : " + logFile);
		Loger.info("[rtyPeriodMin]: " + rtyPeriodMin);
		Loger.info("<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>");
		Loger.info("<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>");
	}
	
	public static boolean confValidCheck() {
		boolean rVal = true;
		
		if (orgFilePath == null || decFilePath == null) {
			Loger.error("confValidCheck - filePath Err");
			rVal = false;
		}
		
		//.. 다른것도 여기에 추가...
		return rVal;
	}
}
