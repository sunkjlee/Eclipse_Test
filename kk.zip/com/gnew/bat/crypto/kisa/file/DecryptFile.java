package com.gnew.bat.crypto.kisa.file;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

import com.gnew.bat.conf.Conf;
import com.gnew.bat.log.Loger;

public class DecryptFile {

	private static final int DEC_ONLY  = 1;
	
	private static final byte[] byTextKey = {(byte)0x3E, (byte)0xFD, (byte)0xFD, (byte)0xFD,(byte)0xFD, (byte)0x65, (byte)0x1D, (byte)0xFD,(byte)0x68, (byte)0x70, (byte)0xFD, (byte)0xFD,(byte)0x3D, (byte)0xFD, (byte)0x63, (byte)0xFD};
	
	static int   nCnt = 0;
	
	public boolean fileExtCheck (String ext) {
		String sExt = ext.toUpperCase();
		Loger.info("--[ExtCheck] : inputExt( " + sExt + ")");
		
		int len = Conf.encExtArr.length;
		boolean rVal = false;
		
		for (int i=0; i<len; i++) {
			String tExt = Conf.encExtArr[i].trim().toUpperCase();
			if (sExt.equals(tExt)) {
				rVal = true;
				break;
			}
		}
		
		return rVal; 
	}
	
	// Decrypt Only  
	public boolean funFileDecrypt (String key, String sOrgPath, String sOrgFileNm, String sDecPath, String decFileNm, int decFileSize){
		boolean rVal = false;
		String encFile = sOrgPath + File.separator + sOrgFileNm;
		String plainFileNm = decFileNm;	
		File fEncFile = new File(encFile); 
		
		if (fEncFile.exists() && fEncFile.isFile()){	//file
			String sExt = fEncFile.getName().substring(fEncFile.getName().lastIndexOf(".")+1);
			//파일지정 암호화 시 확장자를 체크할지 말지 결정 필요..
			if  (fileExtCheck(sExt) == true) {
				if (this.encDecMakeFile(key, fEncFile, sDecPath, plainFileNm, decFileSize, DEC_ONLY) == true) {
					rVal = true;
				}
			}else{
				//skip-- targer file valid but target Ext invalid(conf.encExt)
				// 대상 db에 들어가 있다는 거니까..(폴더블이 아님 개별 처리에서는 error 로그로 출력)  
				Loger.error("[skip-FileName] - " + fEncFile.getName());
			}
		}else if(fEncFile.isDirectory()){		//directory.
			// 대상 db에 들어가 있다는 거니까..폴더블이 아님 개별 처리에서는 error 로그로 출력) 
			Loger.error("[skip-DirName] - " + fEncFile.getName());
			//not file Type ..(sub Diretory...):
		}else {
			Loger.error("funFileDecrypt-EncFile not Founded : " + encFile);
		}
		
		return rVal; 
	}
	
	//start funfileEncrypt : 해당 폴더의 파일을 암호화 하는 함수 
	public void funFileEnDecrypt (String sKey, String sOrgPath, String sDecPath){
		File 	fDir = new File(sOrgPath);
		File[]  fFileList = fDir.listFiles();
		
		long startTm = System.currentTimeMillis();
		
		for(int i = 0; i<fFileList.length; i++){
			File fFile = fFileList[i];
			
			if (fFile.isFile()){	//file
				//파일 확장자 체크  
				String sExt = fFile.getName().substring(fFile.getName().lastIndexOf(".")+1);
				
				if  (fileExtCheck(sExt) == true) {
					if (this.encDecMakeFile(sKey, fFile, sDecPath, fFile.getName(),0, 0) == false) {
						// 에러 메시지는 encDecMakeFile 처리 했고 별도 할일이...
					}
				}else{
					//skip 
					Loger.info("[skip-FileName] - " + fFile.getName());
				}
			}else if(fFile.isDirectory()){		//directory.
				Loger.info("[skip-DirName] - " + fFile.getName());
				//not file Type ..(sub Diretory...):
			}
			Loger.info("[EncDec Processing] NO." + String.format("%,d", nCnt)+ "....\n");
			nCnt = nCnt +1;
		} //end for
		
		long endTm = System.currentTimeMillis();
		long diffTm =  endTm - startTm;
		
		long tSec = diffTm/1000 ;
		Loger.info("Run Time(sec) : " + tSec + "(s)");
		System.out.println("Run Time(sec) : " + tSec + "(s)");
		
		int  min = 0;
		int  sec = 0;
		
		if (tSec > 60 ) {
			min = (int) sec/60;
			sec = (int) sec%60;
			System.out.println("Run Time : " + min + "(m) " +sec + "(s)");
			Loger.info("Run Time : " + min + "(m) " +sec + "(s)");
		}
		
	}//end funfileEncrypt
	
	// start encDecMakeFile 
	private boolean encDecMakeFile(String key, File sourceFile, String outPath, String outFileNm, int decFileSize, int decMode ){
		
		FileInputStream 	fis = null;
		BufferedInputStream bis = null;
		String 				sOutFilePath = null;
		String 				sOutFileName = null;
		
		boolean 			rVal = false; 	
		
		try{
			File fFile = sourceFile;
			Loger.info("[1.fileName] : " + fFile.getName());
			
			//1. file open
			fis = new FileInputStream (fFile);	
			bis = new  BufferedInputStream(fis);
			
			byte[]  byInBuf = new byte[bis.available()];		
			
			int len =0;
			// file read : 
			while ((len = bis.read(byInBuf)) != -1) {
			}
			
			if (Loger.isInfoable()) {
				Loger.info("[2.Ok-Read] : " + fFile.getName() + "/" + String.format("%,d",byInBuf.length) + "byte");
			}
			
			int encFileLen = 0;
			sOutFilePath = outPath;
			sOutFileName = outFileNm;
			
			byte[] bFileKey = base64Decode(key);
			
			if (decMode == DEC_ONLY) {
				encFileLen = byInBuf.length;
				
				//base64 decode  - kj ....
				byte[] byPlainFile = KISA_SEED_CBC.funSeedCbcDecrypt(bFileKey, byInBuf, encFileLen);
				
				//7-2. Make file 
				if (this.makeFile(sOutFilePath, sOutFileName, byPlainFile)){
//					System.out.println("[OK!!]Make Dec File : " + fFile.getName());
					// dec file size check 
////					if (decFileSize != byPlainFile.length){
//						Loger.error("[fail!!] Make Dec File- dec file size Err : " + fFile.getName() +":size(decsize/byLenth)"+ decFileSize +"/"+byPlainFile.length);
//					}else {
						Loger.info("[OK!!]Make Dec File : " + fFile.getName());
						rVal = true;
//					}
				}else{
//					System.out.println("[Fail!!]Make Dec File : " + fFile.getName());
					Loger.info("[Fail!!]Make Dec File : " + fFile.getName());
				}
			}else {
				// 2. Encrypt => Decrypt
				//2-1 Encrypt
				int plainFileLen = byInBuf.length;
				byte[] byEncFile = KISA_SEED_CBC.funSeedCbcEncrypt(bFileKey, byInBuf, plainFileLen);
				
				//7-1.Enc Make file : test용 (enc not used) 
				sOutFilePath = Conf.encFilePath;
				sOutFileName = fFile.getName() + ".enc";
				if (this.makeFile(sOutFilePath, sOutFileName, byEncFile)){
					Loger.info("[3.Ok-Encrypt] Make Enc File : " + fFile.getName() + ".enc");
					rVal = true;
				}else{
					Loger.info("[3.Fail-Encrypt] Make Enc File : " + fFile.getName() + ".enc");
				}
				
				//2-2. Decrypt
				encFileLen = byEncFile.length;
				sOutFilePath = outPath;
				sOutFileName = fFile.getName();
				byte[] byPlainFileE = KISA_SEED_CBC.funSeedCbcDecrypt(bFileKey, byEncFile, encFileLen);
				//7-2. Make file
				if (this.makeFile(sOutFilePath, sOutFileName, byPlainFileE)){
					Loger.info("[4.OK-Decrypt] Make Dec File : " + fFile.getName());
					rVal = true;
				}else{
					Loger.info("[4.Fail-Decrypt] Make Dec File : " + fFile.getName());
				} 
			}
			fis.close();
			bis.close();
			
		}catch(IOException ioe){
			Loger.error("--encDecMakeFile(file:" + sourceFile.getName() + ")", ioe);
			rVal = false;
		}catch(Exception e){
			Loger.error("--encDecMakeFile(file:" + sourceFile.getName() + ")", e);
			rVal = false;
		}
		return rVal;
	}	// end encDecMakeFile
	
	
	//start makeFile
	private boolean makeFile(String path, String fNm, byte[] byData) {
		FileOutputStream  		fos  = null;
		boolean  				rVal = false;
		String 					sfn = null;
				
		try{
			File Folder = new File(path);		
			
			if (!Folder.exists()) {
				Folder.mkdir(); 
				Loger.info("makeFile - create folder : " + path);
			}
			sfn =  path + File.separator + fNm;
			fos = new FileOutputStream(sfn);
			fos.write(byData);
			if (fos !=null )
				fos.close();
			rVal = true;
		}catch(IOException e){
			Loger.error("--- makeFile(file:"+ sfn + ")", e);
		}

		return rVal;
	} //end makeFile 
	

	private byte[] base64Decode(String pText) {
		
		String testStr = pText;
		try {
			byte[]  testbyte = testStr.getBytes("UTF-8");
			String pTextStr = "";
		
			Loger.debug("[base64Decode-pText]\t\t: ");
			for (int i=0; i<testbyte.length; i++)
				pTextStr = pTextStr + (Integer.toHexString(0xff&testbyte[i])+", ");
				Loger.debug(pTextStr);
			// Base64 디코딩 ///////////////////////////////////////////////////
			Decoder decoder = Base64.getDecoder();
			
			// Decoder#decode(bytes[] src) 
			byte[] decodedBytes1 = decoder.decode(testbyte);
			
//			System.out.print("[base64Decode]\t\t\t: ");
			Loger.info("[base64Decode]\t\t\t: ");
			
			String hexStr = "";
			for (int i=0; i<decodedBytes1.length; i++) {
//				System.out.print(Integer.toHexString(0xff&decodedBytes1[i])+", ");
				hexStr = hexStr + (Integer.toHexString(0xff&decodedBytes1[i])+", ");
			}
			Loger.info(hexStr);
//			System.out.print(hexStr + "\n");
			 		
			return decodedBytes1;
			
		}catch (UnsupportedEncodingException  e) {
			Loger.error("--- base64Decode getBytes Err", e);
			return null;
		}
	
	}
	
	public String encryptTextToBase64 (String pText) {
		try {
			byte[]  bySourceText = pText.getBytes("UTF-8");
//			for (int i=0; i<bySourceText.length; i++)
//			    	System.out.print(Integer.toHexString(0xff&bySourceText[i])+", ");
//			System.out.print("\n\n");
			 
			int plainFileLen = bySourceText.length;
			byte[] byEncText = KISA_SEED_CBC.funSeedCbcEncrypt(byTextKey, bySourceText, plainFileLen);
	
			// Base64 인코딩 ///////////////////////////////////////////////////
			Encoder encoder = Base64.getEncoder();
			
			// Encoder#encode(byte[] src) :: 바이트배열로 반환
			byte[] byEncodedBytes = encoder.encode(byEncText);
			
			String resutlStr = new String(byEncodedBytes);
//			System.out.println(resutlStr + "\n");
			return resutlStr;
		}catch (UnsupportedEncodingException  e) {
			Loger.error("--encryptTextToBase64(Text:" + pText + ")", e);
			return null;
		}
	}
	
	public String decryptBase64ToText (String pBase64Text) {
		String resutlStr = null;
		try {
		    Decoder decoder = Base64.getDecoder();
	        byte[] byDecodedBytes = decoder.decode(pBase64Text);
	        
	        // 디코딩한 문자열을 표시
//	       	System.out.print("[string]decPlainText\t\t\t: ");
//			for (int i=0; i<byDecodedBytes.length; i++)
//		    	System.out.print(Integer.toHexString(0xff&byDecodedBytes[i])+", ");
//			System.out.print("\n\n");
	    
			int encFileLen = byDecodedBytes.length;
			byte[] byPlainFile = KISA_SEED_CBC.funSeedCbcDecrypt(byTextKey, byDecodedBytes, encFileLen);
			
			resutlStr = new String(byPlainFile, "UTF-8");
		}catch(IOException ioe){
			Loger.error("--decryptBase64ToText(Text:" + pBase64Text + ")", ioe);
		}catch(Exception e){
			Loger.error("--decryptBase64ToText(Text:" + pBase64Text + ")", e);
		}
		return resutlStr;
	}
	
}
