#!/bin/sh
if [[ $1 == "start" ]]
 then
  startPid=""
  startPid=$(ps -ef | grep 'bat_start.sh' | grep -v grep | awk '{print $2}')
  if [[ $startPid != "" ]]
    then
     echo "[[ already started bat_start.sh - PID : ${startPid}]]"
     exit 0
  else
    echo "[!!Statistics  Batch Start!!]"
    nohup sh ./bin/bat_start.sh 0 1 1>/dev/null 2>&1 &
    exit 0
  fi
fi

if [[ $1 == "stop" ]] 
 then
  echo "[!!Statistics Batch Stop!!]"
  sh ./bin/bat_stop.sh
  exit 0
fi

echo "Error dbBat.sh {start|stop} parameter empty"
exit 0
